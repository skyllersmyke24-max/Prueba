import tkinter as tk
import pandas as pd
import os
import pyautogui as py
import ProcesoTP1 as TP1
import openpyxl
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from tkinter import PhotoImage
from PIL import Image,ImageTk
#==============================================================================
#Parametros de Iniciio
#Funcion que obtiene datos de parametros de inicio
#==============================================================================
def ParametrosInicio():
    global varInicial
    varInicial =[['Ruta del Aplicativo'],['']]
    varInicial[1][0]=os.getcwd() #Ruta del aplicativo
    i=1
    j=0
    while i>0:
        i=varInicial[1][0].find("\\",i)
        #print (i)
        if i!=-1:
            j=i
        i=i+1
    print(j)
    varInicial[1][0]=varInicial[1][0][0:j]
    path_varini=varInicial[1][0]+ '\\VariablesInicio.txt'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    abspath_usuario=os.path.abspath(path_varini)#Ruta del archivo txt   
    with open (abspath_usuario) as Usuario: # Variables Iniciales   
        for a,line in enumerate(Usuario):  #Leyedo usuario intranet
            valoresAux= line[0:len(line)-1].split('|')
            varInicial[0].append(valoresAux[0]) #Ingreso de nombre
            varInicial[1].append(valoresAux[1]) #Ingreso de valor
    
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos(arch):
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    #archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    #for arch in archivosT01:
    if arch[len(arch)-5:].lower()=='.xlsx':
        excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
        hojaB=excel_of.parse(0,dtype =str)
        hojaB.fillna("", inplace = True)
        baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
        excel_of.close()
    elif arch[len(arch)-4:].lower()=='.txt':
        df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                         ,dtype =str)
        baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos_1():
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    for arch in archivosT01:
        if arch[len(arch)-5:].lower()=='.xlsx':
            excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
            hojaB=excel_of.parse(0,dtype =str)
            hojaB.fillna("", inplace = True)
            baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
            excel_of.close()
        elif arch[len(arch)-4:].lower()=='.txt':
            df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                             ,dtype =str)
            baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#==============================================================================
def PBusquedaP(areaR1):
    nombreBL='Base_Busqueda.xlsx'
    nombreHB='Base'
    nombreCBD='Base_Busqueda'
    nombreR="_R"
    areaR=areaR1
    if areaR!=0:
        resultadosB=LeerResultados(nombreBL,nombreHB)
        if areaR==1:
            basetB=leerBaseDatos('1_BANCOS_VEND_INMUEB_CREDHIP_2020.xlsx')
            BusquedaBProc(basetB,resultadosB,['ape_pat','ape_mat','nombre','razon',''])
            BusquedaBRUC(basetB,resultadosB,'nro_doc')
            nombreR="_R_BANCOS_VEND_INMUEB_CREDHIP_2020"
        elif areaR==2:
            basetB=leerBaseDatos('2_BANCOS_CAJAS_CREDDESEMBOLSADOS_2020.txt')
            BusquedaBProc(basetB,resultadosB,['nom_aplpatpre','nom_aplmatpre','nm_razom_pre','nopre','nopre'])
            #BusquedaBRUC(basetB,resultadosB,'num_rucinf')#No tiene columna de numero de documento
            nombreR="_R_BANCOS_CAJAS_CREDDESEMBOLSADOS_2020"
        elif areaR==3:
            basetB=leerBaseDatos('3_TBL_MUNI_PREDIOS_2020.txt')
            BusquedaBProc2(basetB,resultadosB,['nombre'])
            BusquedaBRUC(basetB,resultadosB,'nro_doc')
            nombreR="_R_TBL_MUNI_PREDIOS_2020"
        try: 
            excel_document_c = openpyxl.load_workbook(varInicial [1][0] + '\\' + nombreBL)
            sheetc = excel_document_c[nombreHB]#excel_document_c.get_sheet_by_name(nombreHB)
            j=2
            for i in resultadosB.index: 
                print("Guardar-->" + str(i))
                sheetc.cell(j, 6).value=resultadosB['Porcentaje'][i]
                print(len(resultadosB['Libro'][i]))
                if len(resultadosB['Libro'][i])<= 320000:
                    sheetc.cell(j, 7).value=resultadosB['Libro'][i]
                else:
                    sheetc.cell(j, 7).value=resultadosB['Libro'][i][0:320000]
                print(len(resultadosB['Hoja'][i])<= 32000)
                if len(resultadosB['Hoja'][i])<= 320000:
                    sheetc.cell(j, 8).value=resultadosB['Hoja'][i]
                else:
                    sheetc.cell(j, 8).value=resultadosB['Hoja'][i][0:320000]
                if len(resultadosB['Fila'][i])<= 320000:
                    sheetc.cell(j, 9).value=resultadosB['Fila'][i]
                else:
                    sheetc.cell(j, 9).value=resultadosB['Fila'][i][0:320000]
                if len(resultadosB['Columna'][i])<= 320000:
                    sheetc.cell(j, 10).value=resultadosB['Columna'][i]
                else:
                    sheetc.cell(j, 10).value=resultadosB['Columna'][i][0:320000]
                    
                auxValorR=resultadosB['Valor'][i]
                if len(auxValorR)> 320000 :
                    auxValorR=auxValorR[0:320000]
                    
                auxValorR=ILLEGAL_CHARACTERS_RE.sub(r'',auxValorR)
                sheetc.cell(j, 11).value=str(auxValorR).encode("ascii",errors="ignore")
                j+=1
            excel_document_c.save(varInicial [1][0]+ '\\'+nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx') #('Base_Contribuyente_Resultado.xlsx')
            excel_document_c.close()
        except Exception as e:
            print("Se produjo un error")
            print(e)
            excel_document_c.save(varInicial [1][0]+ '\\'+nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx') #('Base_Contribuyente_Resultado.xlsx')
            excel_document_c.close()
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc(basetB,resultadosB,Ffinal):
    try: 
        for fbasetB in basetB:
            for columna in fbasetB[2]:
                fbasetB[2][columna].fillna("", inplace = True) #nopre
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=nBuscar.strip()
                    if len(nBuscar)>0:
                        if len(resultadosB['RUC'][b])==11 and resultadosB['RUC'][b][0:1]=='2':
                            nombreP[0][0]=nBuscar
                            idB=1
                            colB1=Ffinal[3]
                            colB2=''
                            colB3=''
                            a=6
                        else:
                           nombreP[0]=nBuscar.split('|')
                           idB=0
                           a=4
                           colB1=Ffinal[0]
                           colB2=Ffinal[1]
                           colB3=Ffinal[2]
                        apellidoC=nombreP[0][0] #+ ' ' + nombreP[0][1]
                        nombreC=nombreP[0][2].split(' ')
                        nombreCC= apellidoC +' ' + nombreP[0][2]
                        longitudN=len(nombreP[0][2])
                        longitudAp=len(apellidoC)
                        print('Proceso_BusquedaBProc_P_1_1' + '-->'+str(b))
                        valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)]#,regex=False)] # 
                        print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                        if len(valoresAux)>0: 
                            print('Proceso_BusquedaBProc_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                            if idB==0:
                                print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                valoresV=valoresAux
                                valoresAux1= valoresAux[valoresAux[colB2].str.contains(nombreP[0][1],case=False)]#,regex=False)]
                                auxP=0
                                if len(valoresAux1)>0:
                                    print('Proceso_BusquedaBProc_P_1_1_3' + '-->')
                                    valoresV=valoresAux1
                                    auxP=40
                                    valoresAux2= valoresAux1[valoresAux1[colB3].str.contains(nombreP[0][2],case=False)]#,regex=False)]
                                    if len(valoresAux2)>0:
                                        print('Proceso_BusquedaBProc_P_1_1_4' + '-->')
                                        valoresV=valoresAux2
                                        auxP=60
                                        for filB, apP,apM,nombC in zip(valoresAux2.index,valoresAux2[colB1],
                                                                       valoresAux2[colB2],valoresAux2[colB3]):
                                            if apP.upper()==nombreP[0][0].upper() and apM.upper()==nombreP[0][1].upper() and nombC.upper()==nombreP[0][2].upper():
                                                auxP=100
                                                LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                                  valoresV, a,idB,colB2,colB3,Ffinal[4])
                                                break
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                              valoresV, a,idB,colB2,colB3,Ffinal[4])
                                    else:
                                        LlenarResultados1(auxP,resultadosB,b,fbasetB[1],valoresV.index[0],colB1,
                                              valoresV, a,idB,colB2,colB3,Ffinal[4])
                                    
                            else:
                                print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                valoresV=valoresAux
                                auxP=60
                                for filB, apP in zip(valoresAux.index,valoresAux[colB1]):
                                    if apP.upper()==nombreP[0][0].upper():
                                        auxP=100
                                        LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                              valoresV, a,idB,colB2,colB3,Ffinal[4])
                                        break
                                    LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                              valoresV, a,idB,colB2,colB3,Ffinal[4])
                            
                                      
                        else:
                            auxP=0
                            if resultadosB['Porcentaje'][b]=="":
                                resultadosB['Porcentaje'][b]=str(auxP)
                    else:
                        auxP=0
                        if resultadosB['Porcentaje'][b]=="":
                            resultadosB['Porcentaje'][b]=str(auxP)
                except Exception as e:
                    resultadosB['Libro'][b]="Error-Verificar" + str(e)
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc2(basetB,resultadosB,Ffinal):
    try: 
        for fbasetB in basetB:
            for columna in fbasetB[2]:
                fbasetB[2][columna].fillna("", inplace = True)
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=nBuscar.strip()
                    if len(nBuscar)>0:
                        if len(resultadosB['RUC'][b])==11 and resultadosB['RUC'][b][0:1]=='2':
                            nombreP[0][0]=nBuscar
                            idB=1
                            colB1=Ffinal[0]
                            a=6
                        else:
                           nombreP[0]=nBuscar.split('|')
                           idB=0
                           a=4
                           colB1=Ffinal[0]
                           
                        apellidoC=nombreP[0][0] + ' ' + nombreP[0][1]
                        nombreC=nombreP[0][2].split(' ')
                        nombreCC= apellidoC +' ' + nombreP[0][2]
                        longitudN=len(nombreP[0][2])
                        longitudAp=len(apellidoC)
                        print('Proceso_BusquedaBProc_P_1_1' + '-->'+str(b))
                        valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)] # 
                        print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                        if len(valoresAux)>0: 
                            print('Proceso_BusquedaBProc_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                            if idB==0:
                                print('Proceso_BusquedaBProc_P_1_1_1' + '_'+str(a))
                                apellidoC1=apellidoC.upper()
                                nombreC1=nombreP[0][2].upper()
                                for a1,nrevisar in zip(valoresAux.index,valoresAux[colB1]):
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '_'+str(a1))
                                    auxP=50
                                    nrevisar.upper()
                                    posap=nrevisar.find(apellidoC1)
                                    posnc=nrevisar.find(nombreC1)
                                    if posnc>=0:
                                        print('Proceso_BusquedaBProc_P_1_1_3' + '_'+str(a1))
                                        if posnc<posap:
                                            if posap-posnc-longitudN<=3:
                                                auxP=100
                                
                                            else:
                                                auxP=95
                                        elif posnc>posap:
                                            if posnc-posap-longitudAp<=3:
                                                auxP=100
                                            else:
                                                auxP=95
                                    else:
                                        print('Proceso_BusquedaBProc_P_1_1_4' + '_'+str(a1))
                                        for nauxiN in  nombreC:
                                            nauxiN.upper()
                                            posnc=nrevisar.find(nombreC1)
                                            if posnc>=0:
                                                if posnc<posap:
                                                     if posap-posnc-longitudN<=3:
                                                         auxP=90
                                                         break
                                                     else:
                                                         auxP=60
                                                elif posnc>posap:
                                                     if posnc-posap-longitudAp<=3:
                                                         auxP=90
                                                         break
                                                     else:
                                                         auxP=60
                                    
                                    LlenarResultados(auxP, resultadosB,b,fbasetB[1],a1,colB1,
                                                     valoresAux, a)
                                    
                            else:
                                valoresV=valoresAux
                                auxP=60
                                for filB, apP in zip(valoresAux.index,valoresAux[colB1]):
                                    if apP.upper()==nombreP[0][0].upper():
                                        auxP=100
                                        break
                                
                                LlenarResultados(auxP, resultadosB,b,fbasetB[1],filB,
                                                 colB1,valoresV, a)
                        else:
                            auxP=0
                            if resultadosB['Porcentaje'][b]=="":
                                resultadosB['Porcentaje'][b]=str(auxP)
                    else:
                        auxP=0
                        if resultadosB['Porcentaje'][b]=="":
                            resultadosB['Porcentaje'][b]=str(auxP)
                except Exception as e:
                    resultadosB['Libro'][b]="Error-Verificar" + str(e)
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBRUC(basetB,resultadosB,colRUC):
    try: 
        for fbasetB in basetB:
            for columna in fbasetB[2]:
                fbasetB[2][columna].fillna("", inplace = True)
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('BusquedaBRUC_P_1_0')
            for b,nBuscar in enumerate(resultadosB['RUC']):
                nBuscar=nBuscar.strip()
                if len(nBuscar)>0:
                    if len(resultadosB['RUC'][b])==11 and resultadosB['RUC'][b][0:1]=='2':
                        nombreP[0][0]=nBuscar
                        idB=1
                        colB1=colRUC
                        a=1
                    else:
                        nombreP[0]=nBuscar.split('|')
                        idB=0
                        a=1
                        colB1=colRUC
                    apellidoC=nombreP[0][0]  #+ ' ' + nombreP[0][1]
                    if apellidoC!='SN' and apellidoC!='-':
                        print('PBusquedaBRUC_P_1_1' + '-->'+str(b))
                        valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)] # 
                        print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                        if len(valoresAux)>0: 
                            print('BusquedaBRUC_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                            if idB==0:
                                valoresV=valoresAux
                                auxP=60
                                for a1,nrevisar in zip(valoresAux.index,valoresAux[colB1]):
                                    print('BusquedaBRUC_P_1_1_2' + '_'+str(a1))
                                    filaE=a1
                                    if nrevisar.upper()==apellidoC.upper():
                                        auxP=100
                                        LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                             filaE,colB1,valoresV, a)
                                        break
                                    else:
                                        LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                             filaE,colB1,valoresV, a)
                                    
                            else:
                                valoresV=valoresAux
                                auxP=100
                                filaE=valoresV.index[0]
                                LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                             filaE,colB1,valoresV,a)
                                
                            
                else:
                    auxP=0
                    if resultadosB['Porcentaje'][b]=="":
                        resultadosB['Porcentaje'][b]=str(auxP)
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================

#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados(porcentaje, resultadosB,fila,libro,filaE,colB1,valoresAux, colI):
    auxP=porcentaje
    b=fila
    a=colI
    #a=filab
    if auxP>=60:
        print('LlenarResultados_P_1_1' + '-->' + str(b))
        if int(resultadosB['Porcentaje'][b])<60:
            resultadosB['Libro'][b]=""
            resultadosB['Hoja'][b]=""
            resultadosB['Fila'][b]=""
            resultadosB['Columna'][b]=""
            resultadosB['Valor'][b]=""
        if resultadosB['Libro'][b]=="":
            resultadosB['Libro'][b]=libro
            resultadosB['Hoja'][b]=libro
            resultadosB['Fila'][b]=str(filaE+2)
            resultadosB['Columna'][b]=str(a+1)
            resultadosB['Valor'][b]=valoresAux[colB1][filaE]
        else:
            resultadosB['Libro'][b]=resultadosB['Libro'][b] + '|' + libro
            resultadosB['Hoja'][b]=resultadosB['Hoja'][b] + '|' + libro
            resultadosB['Fila'][b]=resultadosB['Fila'][b] + '|' + str(filaE+2)
            resultadosB['Columna'][b]=resultadosB['Columna'][b] + '|' + str(a+1)
            resultadosB['Valor'][b]= resultadosB['Valor'][b] + '|' + valoresAux[colB1][filaE]
        if auxP>int(resultadosB['Porcentaje'][b]):
            resultadosB['Porcentaje'][b]=str(auxP)
    else:
        print('LlenarResultados_P_1_2'  + '-->' + str(b))
        if auxP>int(resultadosB['Porcentaje'][b]):
            resultadosB['Porcentaje'][b]=str(auxP)
            if resultadosB['Libro'][b]=="":
                resultadosB['Libro'][b]=libro #fbasetB[0]
                resultadosB['Hoja'][b]=libro
                resultadosB['Fila'][b]=filaE
                resultadosB['Columna'][b]=str(a+1)
                resultadosB['Valor'][b]= valoresAux[colB1][filaE]
            else:
                resultadosB['Libro'][b]=resultadosB['Libro'][b] + '|' + libro
                resultadosB['Hoja'][b]=resultadosB['Hoja'][b] + '|' + libro
                resultadosB['Fila'][b]=resultadosB['Fila'][b] + '|' + + filaE
                resultadosB['Columna'][b]=resultadosB['Columna'][b] + '|' + str(a+1)
                resultadosB['Valor'][b]= resultadosB['Valor'][b] + '|' + valoresAux[colB1][filaE]
        else:
            pass
                                
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados1(porcentaje, resultadosB,fila,libro,filaE,colB1,
                      valoresV, colI,idB,colB2,colB3,colND):
    auxP=porcentaje
    b=fila
    a=colI
    if auxP>=40:
        print('LlenarResultados1_P_1_1' + '-->'+str(fila))
        if int(resultadosB['Porcentaje'][b])<40:
            resultadosB['Libro'][b]=""
            resultadosB['Hoja'][b]=""
            resultadosB['Fila'][b]=""
            resultadosB['Columna'][b]=""
            resultadosB['Valor'][b]=""
        if resultadosB['Libro'][b]=="":
            resultadosB['Libro'][b]=libro
            resultadosB['Hoja'][b]=libro
            resultadosB['Fila'][b]=str(filaE+2) #str(a+1)
            resultadosB['Columna'][b]=str(a+1)
            if idB==1:
                resultadosB['Valor'][b]=valoresV[colB1][filaE] 
            else:
                resultadosB['Valor'][b]=(valoresV[colB1][filaE] + ' ' + 
                                         valoresV[colB2][filaE] + ' ' +
                                         valoresV[colB3][filaE] )
            if colND!='':
                resultadosB['Valor'][b]=resultadosB['Valor'][b]+';'+valoresV[colND][filaE] 
        else:
            resultadosB['Libro'][b]=resultadosB['Libro'][b] + '|' + libro
            resultadosB['Hoja'][b]=resultadosB['Hoja'][b] + '|' + libro
            resultadosB['Fila'][b]=resultadosB['Fila'][b] + '|' + str(filaE+2) #str(a+1)
            resultadosB['Columna'][b]=resultadosB['Columna'][b] + '|' + str(a+1)
            if idB==1:
                resultadosB['Valor'][b]=resultadosB['Valor'][b] + '|' + valoresV[colB1][filaE] 
            else:
                resultadosB['Valor'][b]=(resultadosB['Valor'][b] + '|' + valoresV[colB1][filaE] + ' ' + 
                                         valoresV[colB2][filaE] + ' ' +
                                         valoresV[colB3][filaE] )
            if colND!='':
                resultadosB['Valor'][b]=resultadosB['Valor'][b]+';'+valoresV[colND][filaE] 
        if auxP>int(resultadosB['Porcentaje'][b]):
            resultadosB['Porcentaje'][b]=str(auxP)
    else:
        print('LlenarResultados1_P_1_2_2' + '_'+str(fila))
        if auxP>int(resultadosB['Porcentaje'][b]):
            resultadosB['Porcentaje'][b]=str(auxP)
            if resultadosB['Libro'][b]=="":
                resultadosB['Libro'][b]=libro#fbasetB[0]
                resultadosB['Hoja'][b]=libro
                resultadosB['Fila'][b]=str(valoresV.index[0]+2) #str(a+1)
                resultadosB['Columna'][b]=str(a+1)
                resultadosB['Valor'][b]= valoresV[colB1][filaE]
            else:
                resultadosB['Libro'][b]=resultadosB['Libro'][b] + '|' + libro
                resultadosB['Hoja'][b]=resultadosB['Hoja'][b] + '|' + libro
                resultadosB['Fila'][b]=resultadosB['Fila'][b] + '|' + str(valoresV.index[0]+2)
                resultadosB['Columna'][b]=resultadosB['Columna'][b] + '|' + str(a+1)
                resultadosB['Valor'][b]= resultadosB['Valor'][b] + '|' + valoresV[colB1][filaE]
            if colND!='':
                resultadosB['Valor'][b]=resultadosB['Valor'][b]+';'+valoresV[colND][filaE] 
        else:
            pass
                    
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#==============================================================================
def LeerResultados(narchivo, nhoja):
    rutaOrig=varInicial [1][0]
    excel_of=pd.ExcelFile(rutaOrig +'\\' + narchivo) #Lee archivo excel
    hojaB=excel_of.parse(nhoja,usecols =[0,1,2,3,4,5,6,7,8,9,10,11,12],dtype =str)#Observacion cuando coloco una lista me retorna un dicionario [0]
    hojaB.fillna("", inplace = True)
    excel_of.close()
    return hojaB
#==============================================================================
#==============================================================================
#Proceso que crea variable de Area Registral
#==============================================================================
def MenuP():
    global root
    root = tk.Tk()  #tkinter.Tk()  
    root.title('Menú Principal')
    root.geometry("850x300")
    
#     logo = Image.open(r'./Imagenes/iconos/Logo_Robot.png')
#     logo = logo.resize((840, 200), Image.ANTIALIAS) # Redimension (Alto, An•cho)
#     logo = ImageTk.PhotoImage(logo)
    
#     root.labelAreaR = tk.Label(root, justify=tk.LEFT, image=logo, fg = "blue",
# 		                      font = "Times")
#     root.labelAreaR.grid(row=0, column=1,columnspan = 5,sticky="nsew", pady=10)
    
    #Opcion 1 --- Cargar Data    
    img1 = Image.open(r'./Imagenes/iconos/Cargar_Info.png')
    img1 = img1.resize((100, 60), Image.ANTIALIAS) # Redimension (Alto, An•cho)
    img1 = ImageTk.PhotoImage(img1)
    botonNuevo1 = tk.Button(root, image=img1, text="Convertir Data " +'\n' + "de Busqueda", compound="top",fg = "white",
                            bg="dark red",command= Close_Window_1)
    botonNuevo1.grid(row=1, column=1,padx = 2, sticky="nsew", pady=1)

    #Opcion 2 --- Busqueda de coincidencias SUNARP
    img2 = Image.open(r'./Imagenes/iconos/IniciarB.png')
    img2 = img2.resize((100, 60), Image.ANTIALIAS) # Redimension (Alto, Ancho)
    img2 = ImageTk.PhotoImage(img2)
    botonNuevo2 = tk.Button(root, image=img2, text="Iniciar Busqueda en :" +'\n' + "BANCOS_VEND_INMUEB" +
                            '\n' + "_CREDHIP_2020.xlsx", compound="top",fg = "white", bg="dark green"
                            ,command= Close_Window_2)
    botonNuevo2.grid(row=1, column=2, padx = 2, sticky="nsew", pady=1)
    
    #Opcion 3 --- Descarga de Partida
    img3 = Image.open(r'./Imagenes/iconos/IniciarB.png')
    img3 = img3.resize((100, 60), Image.ANTIALIAS) # Redimension (Alto, Ancho)
    img3 = ImageTk.PhotoImage(img3)
    botonNuevo3 = tk.Button(root, image=img3, text="Iniciar Busqueda en :" +'\n' + "BANCOS_CAJAS_" +
                            '\n' + "CREDDESEMBOLSADOS_2020.xlsx", compound="top",fg = "white", bg="dark blue"
                            ,command= Close_Window_3)
    botonNuevo3.grid(row=1, column=3, padx = 2, sticky="nsew", pady=1)
    
    #Opcion 4 --- Descarga de Partida
    img4 = Image.open(r'./Imagenes/iconos/IniciarB.png')
    img4 = img4.resize((100, 60), Image.ANTIALIAS) # Redimension (Alto, Ancho)
    img4 = ImageTk.PhotoImage(img4)
    botonNuevo4 = tk.Button(root, image=img4, text="Iniciar Busqueda en :" +'\n' + "TBL_MUNI_PREDIOS" +
                            '\n' + "_2020.xlsx", compound="top",fg = "white", bg="light blue"
                            ,command= Close_Window_4)
    botonNuevo4.grid(row=1, column=4, padx = 2, sticky="nsew", pady=1)
    
    # Firma
    firma = Image.open(r'./Imagenes/iconos/Firma_Pg.png')
    firma = firma.resize((840, 100), Image.ANTIALIAS) # Redimension (Alto, An•cho)
    firma = ImageTk.PhotoImage(firma)
    
    root.labelAreaR1 = tk.Label(root, justify=tk.LEFT, image=firma, fg = "blue",
		                      font = "Times")
    root.labelAreaR1.grid(row=3, column=1,columnspan = 5,sticky="nsew", pady=20)
    root.mainloop()
#==============================================================================
#Procesos de Menú:
#Opciones del Menu Principal
#==============================================================================
def Close_Window_1 ():
    root.destroy()
    procesoP1()
    print("Proceso Finalizo con exito ==> se completo la columna de Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_2 ():
    root.destroy()
    PBusquedaP(1)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_3 ():
    root.destroy()
    PBusquedaP(2)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_4 ():
    root.destroy()
    PBusquedaP(3)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
# Procedimiento para ejecutar la funcion de completar columna de busuqeda
# 
#==============================================================================   
def procesoP1():
    #baseData=leerBaseDatos
    TP1.completar_NB1(1,varInicial[1][0])

        
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def busquedaPrincipal():
    #baseData=leerBaseDatos
    PBusquedaP()
        
#==============================================================================
#==============================================================================
# Funcion principal que llama a las diversas funciones para la ejecucion de los 
# procesos
#==============================================================================
def main():
     try:
         py.alert("Ejecutando ROBOT SSUNARP ",timeout=800)#Mensaje de incio de asignacion
         ParametrosInicio()
         MenuP()
         # busquedaPrincipal()
         print(varInicial)
         print("Finalizo con exito")
     except Exception as e:
         print("Se produjo un error")
         print(e)
         SystemExit()
         
if __name__ == "__main__":
    main()