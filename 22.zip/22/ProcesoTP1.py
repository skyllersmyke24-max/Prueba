import openpyxl
import pandas as pd 
from win32com.client import Dispatch

#=============================================================================
# Funcion auxiliar que verifica si los componentes del nombre son parte de un 
# apellido compuesto
#=============================================================================
def NACompuesto(texto):
    rpt_nacompuesto=[]
    try:
        arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "KU", "MC", "R", "XU", 
               "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
               "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
               "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        # arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "SU", "KU", "MC", "R", "XU", 
        #        "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
        #        "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
        #        "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        arr1=["DE","VDA"]
        resultadol=arr.index(texto)
        rpt_nacompuesto.append(bool(1))
        try:
            resultadol=arr1.index(texto)
            rpt_nacompuesto.append(bool(1))
            return rpt_nacompuesto
        except:
            rpt_nacompuesto.append(bool(0))
            return rpt_nacompuesto
    except:
        rpt_nacompuesto.append(bool(0))
        rpt_nacompuesto.append(bool(0))
        return rpt_nacompuesto

#==============================================================================
#=============================================================================
# Proceso para separar nombre de personas en en una lista de 3 columnas
#
#=============================================================================
def nombrePropio(valornommbre):
    aN1=[]
    apNombre=[["","",""],[0]]
    i=0
    valornommbre=valornommbre.strip()
    valornommbre = valornommbre.replace(".", " ")
    valornommbre = valornommbre.replace("  ", " ")
    aN1 = valornommbre.split(" ")
    l1 = len(aN1)
    j = 0
    k=0
    if l1 >3: # Se Cambia l1 > 2 por l1>3:
        while i<l1:
            if j==2:
                k=k+1
            if NACompuesto(aN1[i])[0]:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
            else:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j==1 and i < l1: #se agrego "and i<l1" para evitar desbordamiento
                        if NACompuesto(aN1[i + 1])[0]:
                            j=j
                            if NACompuesto(aN1[i+1])[1]:
                                apNombre[1][0]=1
                        else:
                            j = j + 1
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j == 1:
                        if i+1<l1:
                            if NACompuesto(aN1[i + 1])[0]:
                                j=j
                                if NACompuesto(aN1[i])[1]:
                                    apNombre[1][0]=1
                            else:
                                j = j + 1
            i=i+1
        if k>1:
            apNombre[1][0]=1
    elif l1 == 2:
        apNombre[0][0] = aN1[0]
        apNombre[0][2] = aN1[1]
        
    elif l1 == 3:
        apNombre[0][0] = aN1[0]
        apNombre[0][1] = aN1[1]  
        apNombre[0][2] = aN1[2] 
    return apNombre
#=============================================================================
#==============================================================================
# Generar Nombre de Busqueda:
# Completa Nombre de busqueda en Base_Contribuyente.xlsx
#==============================================================================
def completar_NB(areaR1,rutaCP,nombreA):
    nombreA=nombreA[0:len(nombreA)-5]
    excel_document_c = openpyxl.load_workbook(rutaCP +'\\'+ nombreA +'.xlsx')
    sheetc = excel_document_c.get_sheet_by_name('Base')
    excel_document1_c = pd.ExcelFile(rutaCP +'\\'+'Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheetD1_c=excel_document1_c.parse('Relacion_C') #Leer relaciones
    i=2
    band=0
    valor=sheetc.cell(i, 2).value
    valor=valor.strip()
    sheetc.cell(i, 2).value=valor
    revisarnp=[[],[]]
    while valor != None:
        separador=sheetD1_c[sheetD1_c.Tipo_Contribuyente==sheetc.cell(i, 4).value]
        separador1=separador[separador.Tipo_S==1].Valor_Referencia
        separador0=separador[separador.Tipo_S==0].Valor_Referencia
        nombreB=sheetc.cell(i, 2).value
        if (sheetc.cell(i, 4).value =="PERSONA NATURAL CON NEGOCIO" or sheetc.cell(i, 
            4).value =="PERSONA NATURAL SIN NEGOCIO" or sheetc.cell(i, 4).value ==
           "SUCESION INDIVISA SIN NEGOCIO"):
            if str(areaR1)=='1':
                nombreB=nombreB.replace("SUCESION INDIVISA ","")
                nombreB=nombreB.replace("SUCESION INDIVISA DE ","")
                nombre=nombrePropio(nombreB)
                sheetc.cell(i, 3).value=nombre[0][0]+"|"+nombre[0][1]+"|"+nombre[0][2]
                if nombre[1][0]==1:
                    revisarnp[0].append(i)
                    revisarnp[1].append(sheetc.cell(i, 3).value)
                    
        else:
            a=len(valor)
            for separa in separador1: #separa variable de typo serie
                if nombreB.find(separa)>=0:
                   b=nombreB.index(separa)
                   sheetc.cell(i, 3).value=valor[0:b].strip()
                   band=1
                   break
            if band != 1:
                for separa in separador0: #separa variable de typo serie
                    if nombreB.find(separa)>=0:
                       b=nombreB.index(separa)
                       c= len(separa)
                       if a-(b+c)<2:
                           sheetc.cell(i, 3).value=valor[0:b].strip()
                           band=1
                           break  
                if band != 1:
                    sheetc.cell(i, 3).value=valor  
        i=i+1
        band=0
        valor=sheetc.cell(i, 2).value
        if valor  != None:
            valor=valor.strip()
        sheetc.cell(i, 2).value=valor
        #if i==3039:
        print (i)
    excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    for fila in revisarnp[0]:
        nombrea=revisarnp[1][revisarnp[0].index(fila)]
        nombrea=nombrea.split('|')
        nombrea1=nombrea[0]
        nombrea2=nombrea[1].split()
        nombreaa2=""
        nombrea3=nombrea[2].split()
        for n2 in range(len(nombrea2)):
            nombreaa2= nombreaa2 + " " + nombrea2[n2]
            nombreaa2=nombreaa2.strip()
            nombreaa3=""
            for n3 in range(len(nombrea3)):
                if n2!= len(nombrea2)-1 or n3!=len(nombrea3)-1:
                    nombreaa3= nombreaa3 + " " + nombrea3[n3]
                    nombreaa3=nombreaa3.strip()
                    sheetc.cell(i, 1).value=sheetc.cell(fila, 1).value
                    sheetc.cell(i, 2).value= nombrea1 + " " + nombreaa2 + " " + nombreaa3
                    sheetc.cell(i, 3).value= nombrea1 + "|" + nombreaa2 + "|" + nombreaa3
                    sheetc.cell(i, 4).value=sheetc.cell(fila, 4).value
                    i=i+1
    print(revisarnp)
    excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    excel_document_c.close()
    #py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================
#==============================================================================
# Generar Nombre de Busqueda:
# Completa Nombre de busqueda en Base_Contribuyente.xlsx
#==============================================================================
def completar_NB1(areaR1,rutaCP):
    diccionario={'1':['Base_Busqueda.xlsx'],'2':[''],'3':[''],
             '4':[''],'6':[''],'10':[''],
             '11':[''],'12':[''],'13':[''],'21':[''],'31':['']}
    nombreA=diccionario[str(areaR1)][0]
    nombreA=nombreA[0:len(nombreA)-5]
    xlApp = Dispatch("Excel.Application")
    xlApp.Visible = 0 # 1Indica visible, 0 No visible
    xlAppL=xlApp.Workbooks.Open(rutaCP +'\\'+ nombreA +'.xlsx')
    hojap=xlAppL.Sheets('Base')
    tablaP=hojap.ListObjects(1)
    excel_document1_c = pd.ExcelFile(rutaCP +'\\'+'Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheetD1_c=excel_document1_c.parse('Relacion_C') #Leer relaciones
    i=1
    band=0
    valor=tablaP.DataBodyRange.Rows(i).Columns(3).value #sheetc.cell(i, 2).value
    valor=valor.strip()
    tablaP.DataBodyRange.Rows(i).Columns(3).value=valor
    revisarnp=[[],[]]
    while valor != None:
        print('--->Transformar nombre fila ' + str(i))
        separador=sheetD1_c[sheetD1_c.Tipo_Contribuyente==tablaP.DataBodyRange.Rows(i).Columns(4).value]
        separador1=separador[separador.Tipo_S==1].Valor_Referencia
        separador0=separador[separador.Tipo_S==0].Valor_Referencia
        nombreB=tablaP.DataBodyRange.Rows(i).Columns(3).value
        if (tablaP.DataBodyRange.Rows(i).Columns(4).value =="PERSONA NATURAL CON NEGOCIO" or 
            tablaP.DataBodyRange.Rows(i).Columns(4).value =="PERSONA NATURAL SIN NEGOCIO" or 
            tablaP.DataBodyRange.Rows(i).Columns(4).value =="SOCIEDAD CONYUGAL SIN NEGOCIO" or 
            tablaP.DataBodyRange.Rows(i).Columns(4).value =="SOCIEDAD CONYUGAL CON NEGOCIO" or 
            tablaP.DataBodyRange.Rows(i).Columns(4).value == "SUCESION INDIVISA SIN NEGOCIO" or
            tablaP.DataBodyRange.Rows(i).Columns(4).value == "SUCESION INDIVISA CON NEGOCIO"):
            if str(areaR1)=='1':
                if(tablaP.DataBodyRange.Rows(i).Columns(4).value == "SUCESION INDIVISA SIN NEGOCIO" or
                   tablaP.DataBodyRange.Rows(i).Columns(4).value == "SUCESION INDIVISA CON NEGOCIO"):
                    nombreB=nombreB.replace("SUCESION INDIVISA ","")
                    nombreB=nombreB.replace("SUCESION INDIVISA DE ","")
                    nombreB=nombreB.replace("SUCESION ","")
                nombre=nombrePropio(nombreB)
                tablaP.DataBodyRange.Rows(i).Columns(5).value=nombre[0][0]+"|"+nombre[0][1]+"|"+nombre[0][2]
                # if nombre[1][0]==1:
                #     revisarnp[0].append(i)
                #     revisarnp[1].append(tablaP.DataBodyRange.Rows(i).Columns(5).value)
                    
        else:
            a=len(valor)
            for separa in separador1: #separa variable de typo serie
                if nombreB.find(separa)>=0:
                   b=nombreB.index(separa)
                   tablaP.DataBodyRange.Rows(i).Columns(5).value=valor[0:b].strip()
                   band=1
                   break
            if band != 1:
                for separa in separador0: #separa variable de typo serie
                    if nombreB.find(separa)>=0:
                       b=nombreB.index(separa)
                       c= len(separa)
                       if a-(b+c)<2:
                           tablaP.DataBodyRange.Rows(i).Columns(5).value=valor[0:b].strip()
                           band=1
                           break  
                if band != 1:
                    tablaP.DataBodyRange.Rows(i).Columns(5).value=valor  
        i=i+1
        band=0
        valor=tablaP.DataBodyRange.Rows(i).Columns(3).value
        if valor  != None:
            valor=valor.strip()
        tablaP.DataBodyRange.Rows(i).Columns(3).value=valor
        if i==201:
            i=i
        print (i)
    #excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    #xlApp.SaveChanges("rutaCP +'\\'+ nombreA +'_T.xlsx'")
    xlAppL.Save() #ActiveWorkbook
    # for fila in revisarnp[0]:
    #     nombrea=revisarnp[1][revisarnp[0].index(fila)]
    #     nombrea=nombrea.split('|')
    #     nombrea1=nombrea[0]
    #     nombrea2=nombrea[1].split()
    #     nombreaa2=""
    #     nombrea3=nombrea[2].split()
    #     for n2 in range(len(nombrea2)):
    #         nombreaa2= nombreaa2 + " " + nombrea2[n2]
    #         nombreaa2=nombreaa2.strip()
    #         nombreaa3=""
    #         for n3 in range(len(nombrea3)):
    #             if n2!= len(nombrea2)-1 or n3!=len(nombrea3)-1:
    #                 nombreaa3= nombreaa3 + " " + nombrea3[n3]
    #                 nombreaa3=nombreaa3.strip()
    #                 tablaP.DataBodyRange.Rows(i).Columns(1).NumberFormat='@'
    #                 tablaP.DataBodyRange.Rows(i).Columns(1).value=str(tablaP.DataBodyRange.Rows(fila).Columns(1).value)
    #                 tablaP.DataBodyRange.Rows(i).Columns(2).value= nombrea1 + " " + nombreaa2 + " " + nombreaa3
    #                 tablaP.DataBodyRange.Rows(i).Columns(3).value= nombrea1 + "|" + nombreaa2 + "|" + nombreaa3
    #                 tablaP.DataBodyRange.Rows(i).Columns(4).value=tablaP.DataBodyRange.Rows(fila).Columns(4).value
    #                 i=i+1
    #print(revisarnp)
    # excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    # excel_document_c.close()
    xlApp.DisplayAlerts = False
    #xlAppL.SaveAs(rutaCP +'\\'+ nombreA +'_T.xlsx')
    xlAppL.Save()
    xlApp.DisplayAlerts = True
    xlApp.ActiveWorkbook.Close(SaveChanges=1) # see note 1
    #xlApp.Quit()
    #py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================

