
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#idDiligenciaDiv').show();
        $('#idDiligencia').prop('disabled', false);
        $('#idTomaDichoDiv').show();
        $('#idTomaDicho').prop('disabled', false);
        $('#fecDiligenciaDiv').hide();
        $('#fecDiligenciaRangoDiv').show();
        $('#resultadoDiv').show();
        $('#subResultadoDiv').hide();
        $('#observacionDiv').hide();
        $('#mtoInformadoDiv').hide();
        $('#nombreEncargadoTerDiv').hide();        
        $('#telefonoEncargadoTerDiv').hide();
        $('#correoEncargadoTerDiv').hide(); 
        $('#regResponsableDiligenciaDiv').hide();
        $('#usuRegDiv').hide();
        $('#fecRegDiv').hide();
        $('#fecRegRangoDiv').show();
        $('#usuModDiv').hide();
        $('#fecModDiv').hide();
        $('#estadoDiv').hide(); 

        $('#idDiligencia').focus();        

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }
        
        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#idDiligenciaDiv').hide();
        $('#idDiligencia').prop('disabled', true);
        $('#idTomaDichoDiv').show();
        $('#idTomaDicho').prop('disabled', true);
        $('#fecDiligenciaDiv').show();
        $('#fecDiligenciaRangoDiv').hide();
        $('#resultadoDiv').show();
        $('#subResultadoDiv').hide();
        $('#observacionDiv').show();
        $('#mtoInformadoDiv').show();
        $('#nombreEncargadoTerDiv').show();        
        $('#telefonoEncargadoTerDiv').show();
        $('#correoEncargadoTerDiv').show(); 
        $('#regResponsableDiligenciaDiv').show();
        $('#usuRegDiv').hide();
        $('#fecRegDiv').hide();
        $('#fecRegRangoDiv').hide();
        $('#usuModDiv').hide();
        $('#fecModDiv').hide();
        $('#estadoDiv').hide(); 

        $('#resultado').val('4');
        $('#regResponsableDiligencia').val($('#idUsuario').val());

        $('#idDiligencia').focus();
        
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getDiligencias",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"id"},                        
                        {"data":"fecDiligencia"},
                        {"data":"resultadoDesc"},
                        {"data":"subResultadoDesc"},
                        {"data":"mtoInformado"},
                        {"data":"nombreEncargadoTer"},
                        {"data":"telefonoEncargadoTer"},      
                        {"data":"correoEncargadoTer"},
                        {"data":"regResponsableDiligencia"},

                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if ($('#shape').val()=='1'){
                                if ($('#estado2').val()=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }
                            else if ($('#shape').val()=='2'){
                                if ($('#estado2').val()=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>"); 
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }
                            else if ($('#shape').val()=='3'){
                                if ($('#estado2').val()=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                        </div>\
                                    </div>");
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idDiligencia='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });

                if ($('#shape').val()=='1' || $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                        buttons: [
                           { 
                                extend: 'excel', 
                                text: 'Descargar Excel', 
                                className:'buttonDataTable', 
                                type:'button'
                            }
                        ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){

                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idDiligenciaDiv').show();
                    $('#idDiligencia').prop('disabled', true);
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#fecDiligenciaDiv').show();
                    $('#fecDiligenciaRangoDiv').hide();
                    $('#resultadoDiv').show();
                    $('#subResultadoDiv').hide();
                    $('#observacionDiv').show();
                    $('#mtoInformadoDiv').show();
                    $('#nombreEncargadoTerDiv').show();        
                    $('#telefonoEncargadoTerDiv').show();
                    $('#correoEncargadoTerDiv').show(); 
                    $('#regResponsableDiligenciaDiv').show();
                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').hide();
                    $('#fecModDiv').hide();
                    $('#estadoDiv').show(); 

                    $('#idDiligencia').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idDiligencia'));     

                    $('#modalCrud').modal('show');
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $('#btnAceptModalCrud').attr('accion','upd');
                    $('#btnAceptModalCrud').text('Guardar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idDiligenciaDiv').show();
                    $('#idDiligencia').prop('disabled', true);
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#fecDiligenciaDiv').show();
                    $('#fecDiligenciaRangoDiv').hide();
                    $('#resultadoDiv').show();
                    $('#subResultadoDiv').show();
                    $('#observacionDiv').show();
                    $('#mtoInformadoDiv').show();
                    $('#nombreEncargadoTerDiv').show();        
                    $('#telefonoEncargadoTerDiv').show();
                    $('#correoEncargadoTerDiv').show(); 
                    $('#regResponsableDiligenciaDiv').hide();
                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').hide();
                    $('#fecModDiv').hide();
                    $('#estadoDiv').hide(); 

                    $('#idDiligencia').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idDiligencia'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#idDiligenciaDiv').show();
                    $('#idDiligencia').prop('disabled', true);
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#fecDiligenciaDiv').show();
                    $('#fecDiligenciaRangoDiv').hide();
                    $('#resultadoDiv').show();
                    $('#subResultadoDiv').hide();
                    $('#observacionDiv').show();
                    $('#mtoInformadoDiv').show();
                    $('#nombreEncargadoTerDiv').hide();        
                    $('#telefonoEncargadoTerDiv').hide();
                    $('#correoEncargadoTerDiv').hide(); 
                    $('#regResponsableDiligenciaDiv').hide();
                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').hide();
                    $('#fecModDiv').hide();
                    $('#estadoDiv').hide(); 

                    $('#idDiligencia').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('idDiligencia'));

                    $('#modalCrud').modal('show');
                })

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if ((($('#resultado').val() =='0' ) &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#subResultado').val() != '' && $('#subResultado').val() != null))
                ||
                (($('#resultado').val() =='2' || $('#resultado').val() =='3') &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#subResultado').val() != '' && $('#subResultado').val() != null) &&
                ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
                ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))
                ||
                (($('#resultado').val() =='4') &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#mtoInformado').val() != '' && $('#mtoInformado').val() != null) &&
                ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
                ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updDiligencia",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);
                            getDatosGenerales(row.idTomaDicho);
                        }
                        catch(e) {
                           messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
            }
        }

        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();            
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delDiligencia",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.id + ' ';
                        }   
                        messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                        getDatosGenerales(row.idTomaDicho);
                    }
                    catch(e) {
                       messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if ( (($('#resultado').val() =='0' ) &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#subResultado').val() != '' && $('#subResultado').val() != null))
                ||
                (($('#resultado').val() =='2' || $('#resultado').val() =='3') &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#subResultado').val() != '' && $('#subResultado').val() != null) &&
                ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
                ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))
                ||
                (($('#resultado').val() =='4') &&
                ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
                ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
                ($('#mtoInformado').val() != '' && $('#mtoInformado').val() != null) &&
                ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
                ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null)) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insDiligencia", 
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                            getDatosGenerales(row.idTomaDicho);
                        }
                        catch(e) {
                           messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Reportar a: "+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
            }

        }
    });   
        
    //Consulta
    $("#btnAceptModalCrud").attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');    
        
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getDiligencias',
        data: {
            "idDiligencia":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                
                $('#idDiligencia').val(row.id);
                $('#idTomaDicho').val(row.idTomaDicho);
                
                if(row.fecDiligencia != null){
                    $('#fecDiligencia').val(moment(row.fecDiligencia, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }     
                
                $('#resultado').val(row.resultado);
                

                $('#resultado').trigger('change');

                $('#subResultado').val(row.subResultado);

                $('#observacion').val(row.observacion);
                $('#mtoInformado').val(row.mtoInformado);
                $('#nombreEncargadoTer').val(row.nombreEncargadoTer);

                $('#telefonoEncargadoTer').val(row.telefonoEncargadoTer);
                $('#correoEncargadoTer').val(row.correoEncargadoTer);
                $('#regResponsableDiligencia').val(row.regResponsableDiligencia);
                $('#estado').val(row.estado);
             

            
                
            }

        }
    });
}

function getDatosGenerales(id){

    $.ajax({
        method:"POST",
        url : './getTomaDichos',
        data: {
            "idTomaDicho":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#idTomaDicho2').val(row.id);
                

                $('#rc').val(row.rc);
                $('#rucContribuyente').val(row.rucContribuyente);
               
                
                //$("#codTercero").val(row.codTercero);

                getListaTerceros(row.rc);                           
                $('#codTercero').append($("<option selected='selected'></option>").val(row.codTercero).text(row.rucTerceroDesc)).trigger('change');

                $('#estado2').val(row.estado);

                if(row.estado=='02'){
                    $('#mostrarModalIns').hide();
                }
                
                
            }
        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#idTomaDicho').val(row.idTomaDicho);
        $('#rc').val(row.rc);
        $('#rucContribuyente').val(row.rucContribuyente);
        $('#rucTercero').val(row.rucTercero);
        $('#fecTomaDichoIni').val(row.fecTomaDichoIni);
        $('#fecTomaDichoFin').val(row.fecTomaDichoFin);
        $('#regResponsableDiligencia').val(row.regResponsableDiligencia);
        $('#resultado').val(row.resultado);

        $('#codAuxRc').val(row.codAuxRc);
        $('#codEjeRc').val(row.codEjeRc);
        $('#fecRegIni').val(row.fecRegIni);
        $('#fecRegFin').val(row.fecRegFin);        
        $('#estado').val(row.estado);
        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();


    //$("#idUsuario").val("");
    //$("#idUsuario").text("");

    

    $('#codTercero').empty();
    $("#codTercero").val("");
    $("#codTercero").text("");



    //$("#tipoFrecuencia").val("");
    
    

    /*$("#numOrdFis").val("");
    $("#numOrdFis").text("");*/


    

    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General        
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
    }
    if($('#shape').val()=='2'){
        //Consulta por id Toma Dicho
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').show();
    }
    if($('#shape').val()=='3'){
        //Consulta por id Mis Asigndos
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').show();
    }

    if($('#estado2').val()=='02'){
        $('#mostrarModalIns').hide();
    }

   
    var feriadosArray = new Array();
    
    /*$.ajax({
        'url' : '../aplicacion/getFeriados',
        'type' : 'POST',
        'success' : function(data) {
            var a=JSON.parse(data);
            for(i=0; i<=a.data.length-1; i++){
                feriadosArray.push(a.data[i].fecha);
            }
        }
    });*/
    
    $('#resultado').append($('<option></option>').val('').html('Seleccionar'));
    $('#resultado').append($('<option></option>').val('0').html('0 - FRUSTADO'));
    //$('#resultado').append($('<option></option>').val('1').html('1 - NO HA PRESENTADO ESCRITO'));
    $('#resultado').append($('<option></option>').val('2').html('2 - NO ES CLIENTE DEL EJECUTADO'));
    $('#resultado').append($('<option></option>').val('3').html('3 - ES CLIENTE DEL EJECUTADO, SIN MONTO A RETENER'));
    $('#resultado').append($('<option></option>').val('4').html('4 - ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'));

  

    $('#estado').append($('<option></option>').val('').html('Seleccionar'));
    $('#estado').append($('<option></option>').val('00').html('01 - ACTIVO'));


    $('#resultado').change(function(){
        
        if($(this).val() == '0'){
            $('#subResultadoDiv').show();
            $('#mtoInformadoDiv').hide();
            $('#nombreEncargadoTerDiv').hide();
            $('#telefonoEncargadoTerDiv').hide();
            $('#correoEncargadoTerDiv').hide();
            $('#regResponsableDiligenciaDiv').show();



            $('#subResultado').empty();
            $('#subResultado').append($('<option></option>').val('').html('Seleccionar'));
            $('#subResultado').append($('<option></option>').val('01').html('01 - NO SE UBICA DIRECCIÓN'));
            $('#subResultado').append($('<option></option>').val('02').html('02 - DOMICILIO CERRADO'));
            $('#subResultado').append($('<option></option>').val('03').html('03 - DIRECCIÓN INCORRECTA'));
            $('#subResultado').append($('<option></option>').val('04').html('04 - SIN ACCESO AL DOMICILIO'));
            $('#subResultado').append($('<option></option>').val('05').html('05 - ACTITUD INDIFERENTE'));
            $('#subResultado').append($('<option></option>').val('06').html('06 - ENCARGADO SIN AUTORIDAD'));
            $('#subResultado').append($('<option></option>').val('07').html('07 - TELEFONO APAGADO'));
            $('#subResultado').append($('<option></option>').val('08').html('08 - TELEFONO INCORRECTO'));

        }
        if($(this).val() == '1'){
            $('#subResultadoDiv').hide();
            $('#mtoInformadoDiv').hide();
            $('#nombreEncargadoTerDiv').hide();
            $('#telefonoEncargadoTerDiv').hide();
            $('#correoEncargadoTerDiv').hide();
            $('#regResponsableDiligenciaDiv').show();

            
        }
        if($(this).val() == '2'){
            $('#subResultadoDiv').show();
            $('#mtoInformadoDiv').hide();
            $('#nombreEncargadoTerDiv').show();
            $('#telefonoEncargadoTerDiv').show();
            $('#correoEncargadoTerDiv').hide();
            $('#regResponsableDiligenciaDiv').show();

            $('#subResultado').empty();
            $('#subResultado').append($('<option></option>').val('').html('Seleccionar'));
            $('#subResultado').append($('<option></option>').val('21').html('21 - FINALIZACIÓN DE CONTRADO'));
            $('#subResultado').append($('<option></option>').val('22').html('22 - NUNCA FUE CLIENTE'));

        }
        if($(this).val() == '3'){
            $('#subResultadoDiv').show();
            $('#mtoInformadoDiv').hide();
            $('#nombreEncargadoTerDiv').show();
            $('#telefonoEncargadoTerDiv').show();
            $('#correoEncargadoTerDiv').show();
            $('#regResponsableDiligenciaDiv').show();

            $('#subResultado').empty();
            $('#subResultado').append($('<option></option>').val('').html('Seleccionar'));
            $('#subResultado').append($('<option></option>').val('31').html('31 - PAGÓ AL DEUDOR'));
            $('#subResultado').append($('<option></option>').val('32').html('32 - PAGO A FUTURO'));
            $('#subResultado').append($('<option></option>').val('33').html('33 - SIN LIQUIDEZ'));
            $('#subResultado').append($('<option></option>').val('34').html('34 - FIDEICOMISO'));
            $('#subResultado').append($('<option></option>').val('35').html('35 - FACTORING'));
            $('#subResultado').append($('<option></option>').val('36').html('36 - FACTURA CON ERROR'));
            $('#subResultado').append($('<option></option>').val('37').html('37 - TRUEQUE'));
        }
        if($(this).val() == '4'){
            $('#subResultadoDiv').hide();
            $('#mtoInformadoDiv').show();
            $('#nombreEncargadoTerDiv').show();
            $('#telefonoEncargadoTerDiv').show();
            $('#correoEncargadoTerDiv').show();
            $('#regResponsableDiligenciaDiv').show();
        }

    });  
    
    getDatosGenerales($("#idTomaDicho2").val());

    //var dt = moment(myDate.date, "YYYY-MM-DD HH:mm:ss")


    
    
    $('#mtoInformado').keyup(function(){

        if($(this).val() != ""){
            $(this).val(Number($(this).val()));

            //if(Number.isInteger(parseInt($(this).val())) == false ) {
            //if(isNumeric($(this).val())==false){
             
            if(Number.isInteger(parseFloat($(this).val()))==false){
                
                alert("Sólo números enteros");  
                $(this).val("");     
            }
        }
       
    }); 



    



    setInterval(timer, 10000);


    $('#fecDiligencia').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecDiligenciaContainer'
    });

    $('#fecDiligenciaIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecDiligenciaIniContainer'
    });

    $('#fecDiligenciaFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecDiligenciaFinContainer'
    });
    



    $('#fecRegIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegIniContainer'
    });

    $('#fecRegFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegFinContainer'
    });



    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });
    

    $('#rc').change(function(){
        
        

        if($(this).val().length == 13){
            $.ajax({
                'url' : './getDatosRC',                
                data: {
                    "rc":$(this).val()
                },
                'type' : 'POST',
                'success' : function(data) {
                    
                    var jsonData = JSON.parse(data);
                    //var regUsuario;
                    //$('#codTercero').empty();
                    for (var i = 0; i < jsonData.data.length; i++) {
                        var row = jsonData.data[i];

                        $('#rucContribuyente').val(row.ruc);
                        
                        
                    }
                }
            });


            
            getListaTerceros($(this).val());
            



        }
    });   



    
    
}



function getListaTerceros(rc){

    $('#codTercero').empty();
    $('#codTercero').val('');
    $('#codTercero').text('');

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}



// function esDiaHabil(fechaString,feriadosArray){
    
//     //*****Formato: 'DD/MM/YYYY' ********/

//     //convirtiendo a YYYY-MM-DD
//     fechaString=moment(fechaString, 'DD/MM/YYYY').format('YYYY-MM-DD');

//     fechaDate = new Date(fechaString);
    
//     fechaDate.setTime(fechaDate.getTime() + 24*60*60*1000);

//     var anio = fechaDate.getFullYear();
//     var mes = (fechaDate.getMonth() + 1) < 10 ? "0" + (fechaDate.getMonth()+1) : fechaDate.getMonth()+1;
//     var dia = (fechaDate.getDate()) < 10 ? "0" + (fechaDate.getDate()) : fechaDate.getDate();

//     var fechaString = anio + "-" + mes + "-" + dia;

//     var feriado = feriadosArray.indexOf(fechaString);

//     if(fechaDate.getDay() == 6 || fechaDate.getDay() == 0 || feriado>=0){
//         return false;
//     }else{
//         return true;
//     }
// }



