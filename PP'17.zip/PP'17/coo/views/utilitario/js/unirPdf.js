
$(document).ready(function () {

    inicializarModulo();
       
});

function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
    }
    
    mostrarContador1();
     
    setInterval(timer, 10000);
    setInterval(mostrarContador1, 5000);


    $("#formPdf").on("submit", function(){

        var files = document.getElementById("archivos[]").files;

        // for (var i = 0; i < files.length; i++)
        // {
        //  alert(files[i].name);
        // }

        if (files.length>0){
            return true;
        }else{

            messageBox(2,'Error','Existen campos vacíos');
            return false;
            
        }
          
        
    });
  
    
    
}


function limpiarFromPdf(){

    $("#formPdf")[0].reset();
    



    //$('[name^="nro_rtf_array"]').remove();
}

function mostrarContador1(){
    $.ajax({
        'url' : './getContador1',
        data: {},
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#contador1').text('Contador total de uniones realizadas : '+row.contador);
                //$('#contador1').val(row.contador);    
                //alert(row.contador);
            }
        }
    });
}

// function validarFormPdf() {

//     if ($('#archivos').val()=='') {
//         alert("El campo no puede estar vacío.");
//         return false;
//     }else{
//         return true;    
//     }



    
// }