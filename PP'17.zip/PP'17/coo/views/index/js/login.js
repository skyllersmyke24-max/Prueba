$(document).ready(function () {

    $.ajax({
        'url' : 'http://pcu408:8080/Cobraly_1/aplicacion/getDependencias',
        data: {},
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#id_dependencia').append($('<option></option>').val(row.id).html(row.desc_dependencia));

                
            }

        }
    });

    $('#id_dependencia').val('002000');

    if($('#tipoError').val()=='1'){
        $('#titulo').text('Error');
        $('#message').text('Validación incorrecta, utilizar usuario y contraseña de red');
        $('#message').removeClass("text-muted");
        $('#message').css('color', 'red');
            
    }

    

    

});