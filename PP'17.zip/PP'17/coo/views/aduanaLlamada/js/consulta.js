
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#idAduanaLlamadaDiv').show();
        $('#idAduanaLlamada').prop('disabled', false);
        $('#tipoDocIdentidadDiv').hide();
        $('#tipoDocIdentidad').prop('disabled', false);
        $('#docIdentidadDiv').show();
        $('#docIdentidad').prop('disabled', false);
        $('#razonSocialDiv').hide();        
        $('#razonSocial').prop('disabled', false);
        $('#telefonoDiv').hide();
        $('#fecLlamadaDiv').hide();
        $('#apellidoPaternoDiv').hide();
        $('#apellidoMaternoDiv').hide();
        $('#nombresDiv').hide();
        $('#cargoDiv').hide();
        $('#contribuyenteContactadoDiv').hide();
        $('#resultadoLlamadaDiv').hide();
        $('#resultadoNegociacionDiv').hide();
        $('#tipoLLamadaDiv').hide();
        $('#observacionDiv').hide();
        $('#expCoactivoDiv').hide();
        $('#rcEmbargoDiv').hide();
        $('#respuestaDiv').hide();
        $('#fecEstimadaEntregaDiv').hide();

        $('#usuRegDiv').show();
        $('#fecRegDiv').hide();
        $('#fecRegRangoDiv').show();
        $('#usuModDiv').hide();
        $('#fecModDiv').hide();
        $('#estadoDiv').hide();

        $('#rc').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $('#mostrarModalIns').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#idAduanaLlamadaDiv').hide();
        $('#idAduanaLlamada').prop('disabled', false);
        
        $('#fecLlamadaDiv').show();
        $('#tipoDocIdentidadDiv').show();
        $('#tipoDocIdentidad').prop('disabled', false);
        $('#docIdentidadDiv').show();
        $('#docIdentidad').prop('disabled', false);
        $('#razonSocialDiv').show();
        $('#razonSocial').prop('disabled', false);
        $('#telefonoDiv').show();
        $('#apellidoPaternoDiv').show();
        $('#apellidoMaternoDiv').show();
        $('#nombresDiv').show();
        $('#cargoDiv').show();
        $('#contribuyenteContactadoDiv').show();
        $('#resultadoLlamadaDiv').show();
        $('#resultadoNegociacionDiv').show();
        $('#tipoLLamadaDiv').show();
        $('#observacionDiv').show();
        $('#expCoactivoDiv').show();
        $('#rcEmbargoDiv').show();
        $('#respuestaDiv').show();
        $('#fecEstimadaEntregaDiv').show();


        $('#usuRegDiv').hide();
        $('#fecRegDiv').hide();
        $('#fecRegRangoDiv').hide();
        $('#usuModDiv').hide();
        $('#fecModDiv').hide();
        $('#estadoDiv').hide();


        $('#idAduanaLlamada').focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $('#btnAceptModalCrud').on('click', function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $('#btnAceptModalCrud').prop('disabled', true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getAduanasLlamadas",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    "columnDefs": [ {
                        orderable: false,
                        className: 'select-checkbox',
                        targets:   0
                    } ],
                        "select": {
                        //style:    'os',
                        style: 'multi',
                        selector: 'td:first-child'
                    },
                            

                    "columns":
                    [
                        {"data":null,"defaultContent": ""},                       
                        {'data':'id'},                         
                        {'data':'tipoDocIdentidadDesc'}, 
                        {'data':'docIdentidad'}, 
                        {'data':'razonSocial'}, 
                        {'data':'fecLlamada'},
                        {'data':'apellidoPaterno'}, 
                        {'data':'apellidoMaterno'}, 
                        {'data':'nombres'}, 
                        {'data':'cargoDesc'}, 
                        {'data':'contribuyenteContactadoDesc'}, 
                        {'data':'resultadoLlamadaDesc'}, 
                        {'data':'resultadoNegociacionDesc'}, 
                        {'data':'tipoLLamadaDesc'}, 
                        {'data':'observacion'}, 
                        {'data':'expCoactivo'}, 
                        {'data':'rcEmbargo'}, 
                        {'data':'respuestaDesc'}, 
                        {'data':'fecEstimadaEntrega'},                         
                        {'data':'estadoDesc'}, 

                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            if ($('#shape').val()=='1'){
                                
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idAduanaLlamada='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idAduanaLlamada='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                            <button type='button' idAduanaLlamada='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                        </div>\
                                    </div>");                                
                                
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });
                

                //seleccionar todo
                $("#select_all").on( "click", function(e) {
                if ($(this).is(":checked")) {
                    table.rows().select();        
                } else {
                    table.rows().deselect(); 
                }});

                if($('#shape').val()=='1'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();
                
                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idAduanaLlamadaDiv').show();
                    $('#idAduanaLlamada').prop('disabled', true);
                    $('#tipoDocIdentidadDiv').show();
                    $('#tipoDocIdentidad').prop('disabled', true);
                    $('#docIdentidadDiv').show();
                    $('#docIdentidad').prop('disabled', true);
                    $('#razonSocialDiv').show();
                    $('#razonSocial').prop('disabled', true);
                    $('#telefonoDiv').show();
                    $('#fecLlamadaDiv').show();
                    $('#apellidoPaternoDiv').show();
                    $('#apellidoMaternoDiv').show();
                    $('#nombresDiv').show();
                    $('#cargoDiv').show();
                    $('#contribuyenteContactadoDiv').show();
                    $('#resultadoLlamadaDiv').show();
                    $('#resultadoNegociacionDiv').show();
                    $('#tipoLLamadaDiv').show();
                    $('#observacionDiv').show();
                    $('#expCoactivoDiv').show();
                    $('#rcEmbargoDiv').show();
                    $('#respuestaDiv').show();
                    $('#fecEstimadaEntregaDiv').show();
                    $('#usuRegDiv').show();
                    $('#fecRegDiv').show();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').show();
                    $('#fecModDiv').show();
                    $('#estadoDiv').show();


                    $('#idAduanaLlamada').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idAduanaLlamada'));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $('#btnAceptModalCrud').attr('accion','upd');
                    $('#btnAceptModalCrud').text('Guardar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idAduanaLlamadaDiv').show();
                    $('#idAduanaLlamada').prop('disabled', true);
                    $('#fecLlamadaDiv').show();
                    $('#tipoDocIdentidadDiv').show();
                    $('#tipoDocIdentidad').prop('disabled', true);
                    $('#docIdentidadDiv').show();
                    $('#docIdentidad').prop('disabled', true);
                    $('#razonSocialDiv').show();
                    $('#razonSocial').prop('disabled', true);
                    $('#telefonoDiv').show();
                    $('#apellidoPaternoDiv').show();
                    $('#apellidoMaternoDiv').show();
                    $('#nombresDiv').show();
                    $('#cargoDiv').show();
                    $('#contribuyenteContactadoDiv').show();
                    $('#resultadoLlamadaDiv').show();
                    $('#resultadoNegociacionDiv').show();
                    $('#tipoLLamadaDiv').show();
                    $('#observacionDiv').show();
                    $('#expCoactivoDiv').show();
                    $('#rcEmbargoDiv').show();
                    $('#respuestaDiv').show();
                    $('#fecEstimadaEntregaDiv').show();

                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').hide();
                    $('#fecModDiv').hide();
                    $('#estadoDiv').hide();

                    $('#idAduanaLlamadaDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idAduanaLlamada'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#tipoDocIdentidadDiv').hide();
                    $('#tipoDocIdentidad').prop('disabled', true);
                    $('#docIdentidadDiv').hide();
                    $('#docIdentidad').prop('disabled', true);
                    $('#razonSocialDiv').hide();
                    $('#razonSocial').prop('disabled', true);
                    $('#telefonoDiv').hide();
                    $('#fecLlamadaDiv').hide();
                    $('#apellidoPaternoDiv').hide();
                    $('#apellidoMaternoDiv').hide();
                    $('#nombresDiv').hide();
                    $('#cargoDiv').hide();
                    $('#contribuyenteContactadoDiv').hide();
                    $('#resultadoLlamadaDiv').hide();
                    $('#resultadoNegociacionDiv').hide();
                    $('#tipoLLamadaDiv').hide();
                    $('#observacionDiv').hide();
                    $('#expCoactivoDiv').hide();
                    $('#rcEmbargoDiv').hide();
                    $('#respuestaDiv').hide();
                    $('#fecEstimadaEntregaDiv').hide();

                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide();
                    $('#usuModDiv').hide();
                    $('#fecModDiv').hide();
                    $('#estadoDiv').hide();

                    $('#idAduanaLlamadaDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('idAduanaLlamadaDiv'));

                    $('#modalCrud').modal('show');
                })
                

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar algún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#docIdentidad").val() != "" && $("#docIdentidad").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updAduanaLlamada",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
     
        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();            
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delAduanaLlamada",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.id + ' ';
                        }   
                        messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                    }
                    catch(e) {
                       messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#docIdentidad").val() != "" && $("#docIdentidad").val() != null) &&
                ($("#telefono").val() != "" && $("#telefono").val() != null)){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insAduanaLlamada",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
    });   
        
    //Consulta
    $('#btnAceptModalCrud').attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');   

 

  
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getAduanasLlamadas',
        data: {
            "idAduanaLlamada":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                          
                $('#idAduanaLlamada').val(row.id)
                $('#tipoDocIdentidad').val(row.tipoDocIdentidad);
                $('#docIdentidad').val(row.docIdentidad);
                $('#razonSocial').val(row.razonSocial);
                $('#telefono').val(row.telefono);
                if(row.fecLlamada != null){
                    $('#fecLlamada').val(moment(row.fecLlamada, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                } 
              
                $('#apellidoPaterno').val(row.apellidoPaterno);
                $('#apellidoMaterno').val(row.apellidoMaterno);
                $('#nombres').val(row.nombres);
                $('#cargo').val(row.cargo);
                $('#contribuyenteContactado').val(row.contribuyenteContactado);
                $('#resultadoLlamada').val(row.resultadoLlamada);
                $('#resultadoNegociacion').val(row.resultadoNegociacion);
                $('#tipoLLamada').val(row.tipoLLamada);
                $('#observacion').val(row.observacion);
                $('#expCoactivo').val(row.expCoactivo);
                $('#rcEmbargo').val(row.rcEmbargo);
                $('#respuesta').val(row.respuesta);

                if(row.fecEstimadaEntrega != null){
                    $('#fecEstimadaEntrega').val(moment(row.fecEstimadaEntrega, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }     

                $('#usuReg').val(row.usuReg);

                if(row.fecReg != null){
                    $('#fecReg').val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }   

                $('#usuMod').val(row.usuMod);

                if(row.fecMod != null){
                    $('#fecMod').val(moment(row.fecMod, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                } 
                
                $('#estado').val(row.estado);

            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#idAduanaLlamada').val(row.idAduanaLlamada);
        $('#tipoDocIdentidad').val(row.tipoDocIdentidad);
        $('#docIdentidad').val(row.docIdentidad);
        $('#razonSocial').val(row.razonSocial);
        $('#telefono').val(row.telefono);
        $('#fecLlamada').val(row.fecLlamada);
        $('#apellidoPaterno').val(row.apellidoPaterno);
        $('#apellidoMaterno').val(row.apellidoMaterno);
        $('#nombres').val(row.nombres);
        $('#cargo').val(row.cargo);
        $('#contribuyenteContactado').val(row.contribuyenteContactado);
        $('#resultadoLlamada').val(row.resultadoLlamada);
        $('#resultadoNegociacion').val(row.resultadoNegociacion);
        $('#tipoLLamada').val(row.tipoLLamada);
        $('#observacion').val(row.observacion);
        $('#expCoactivo').val(row.expCoactivo);
        $('#rcEmbargo').val(row.rcEmbargo);
        $('#respuesta').val(row.respuesta);
        $('#fecEstimadaEntrega').val(row.fecEstimadaEntrega);
        $('#usuReg').val(row.usuReg);
        $('#fecReg').val(row.fecReg);
        $('#usuMod').val(row.usuMod);
        $('#fecMod').val(row.fecMod);
        $('#estado').val(row.estado);


        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();
    
    // $('#codTercero').empty();
    // $("#codTercero").val("");
    // $("#codTercero").text("");



    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
    }

    
     
    $('#tipoDocIdentidad').append($('<option></option>').val('').html('Seleccionar'));
    $('#tipoDocIdentidad').append($('<option></option>').val('1').html('DNI'));
    $('#tipoDocIdentidad').append($('<option></option>').val('6').html('RUC'));
    $('#tipoDocIdentidad').append($('<option></option>').val('7').html('OTRO'));
     
    $('#cargo').append($('<option></option>').val('').html('Seleccionar'));
    $('#cargo').append($('<option></option>').val('0250001').html('ABOGADO'));
    $('#cargo').append($('<option></option>').val('0250002').html('ACCIONISTA'));
    $('#cargo').append($('<option></option>').val('0250003').html('ADMINISTRADOR'));
    $('#cargo').append($('<option></option>').val('0250004').html('ADMINISTRADOR JUDICIAL'));
    $('#cargo').append($('<option></option>').val('0250005').html('APODERADO'));
    $('#cargo').append($('<option></option>').val('0250006').html('CONTADOR'));
    $('#cargo').append($('<option></option>').val('0250007').html('DIRECTOR CENTRO EDUCTIVO'));
    $('#cargo').append($('<option></option>').val('0250008').html('DIRECTOR GENERAL'));
    $('#cargo').append($('<option></option>').val('0250009').html('FAMILIAR DEL TITULAR'));
    $('#cargo').append($('<option></option>').val('0250010').html('FUNCIONARIO PÚBLICO'));
    $('#cargo').append($('<option></option>').val('0250011').html('GERENTE GENERAL'));
    $('#cargo').append($('<option></option>').val('0250013').html('MIEMBRO DEL DIRECTORIO'));
    $('#cargo').append($('<option></option>').val('0250014').html('PRESIDENTE DE DIRECTORIO'));
    $('#cargo').append($('<option></option>').val('0250015').html('RECTOR'));
    $('#cargo').append($('<option></option>').val('0250016').html('REPRESENTANTE LEGAL'));
    $('#cargo').append($('<option></option>').val('0250017').html('SECRETARIA'));
    $('#cargo').append($('<option></option>').val('0250018').html('SIN RELACION'));
    $('#cargo').append($('<option></option>').val('0250019').html('SOCIO-ACCCIONISTA'));
    $('#cargo').append($('<option></option>').val('0250020').html('SUBGERENTE'));
    $('#cargo').append($('<option></option>').val('0250021').html('TESORERO'));
    $('#cargo').append($('<option></option>').val('0250022').html('TITULAR'));
    $('#cargo').append($('<option></option>').val('0250023').html('TRABAJADOR'));
    $('#cargo').append($('<option></option>').val('0250024').html('VICE-RECTOR'));

    $('#contribuyenteContactado').append($('<option></option>').val('').html('Seleccionar'));
    $('#contribuyenteContactado').append($('<option></option>').val('SI').html('SI CONTACTADO'));
    $('#contribuyenteContactado').append($('<option></option>').val('NO').html('NO CONTACTADO'));

    $('#resultadoLlamada').append($('<option></option>').val('').html('Seleccionar'));
    $('#resultadoLlamada').append($('<option></option>').val('0230001').html('CONTESTA'));
    $('#resultadoLlamada').append($('<option></option>').val('0230007').html('CONTESTA CORREO'));
    $('#resultadoLlamada').append($('<option></option>').val('0230004').html('FUERA DE SERVICIO'));
    $('#resultadoLlamada').append($('<option></option>').val('0230002').html('NO CONTESTA'));
    $('#resultadoLlamada').append($('<option></option>').val('0230005').html('NO EXISTE NÚMERO'));
    $('#resultadoLlamada').append($('<option></option>').val('0230008').html('NO SE LLAMO'));
    $('#resultadoLlamada').append($('<option></option>').val('0230009').html('SE DEJO MENSAJE DE VOZ'));
    $('#resultadoLlamada').append($('<option></option>').val('0230010').html('SE ENVIO CORREO ELECTRONICO'));
    $('#resultadoLlamada').append($('<option></option>').val('0230011').html('SIN TELEFONOS'));
    $('#resultadoLlamada').append($('<option></option>').val('0230006').html('SOLICITA RELLAMADA'));
    $('#resultadoLlamada').append($('<option></option>').val('0230003').html('TELEFONO NO CORRESPONDE'));



    $('#resultadoNegociacion').append($('<option></option>').val('').html('Seleccionar'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240001').html('CANCELADO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240008').html('CANCELADO ANTES DE INDUCCION'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240010').html('COMPENSARA'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240004').html('CON PODER DE NEGOCIACIÓN SIN INTENCION DE PAGO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240013').html('ENTREGARA CHEQUE'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240005').html('FRACCIONAMIENTO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240009').html('IMPUGNARA'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240002').html('PAGO ERRADO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240011').html('PAGO PARCIAL'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240012').html('PRESENTARA FORMULARIO VIRTUAL O ESCRITO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240003').html('PROPUESTA DE PAGO'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240006').html('SIN PODER DE NEGOCIACION'));
    $('#resultadoNegociacion').append($('<option></option>').val('0240007').html('SIN RESULTADO'));

    $('#tipoLLamada').append($('<option></option>').val('').html('Seleccionar'));
    $('#tipoLLamada').append($('<option></option>').val('0380001').html('ENTRANTE'));
    $('#tipoLLamada').append($('<option></option>').val('0380002').html('SALIENTE'));

    $('#respuesta').append($('<option></option>').val('').html('Seleccionar'));
    $('#respuesta').append($('<option></option>').val('0730002').html('ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'));
    $('#respuesta').append($('<option></option>').val('0730001').html('SIN RESPUESTA'));
      
  


    setInterval(timer, 10000);


    $('#fecEstimadaEntrega').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecEstimadaEntregaContainer'
    });

    $('#fecReg').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegContainer'
    });

    $('#fecRegIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegIniContainer'
    });

    $('#fecRegFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegFinContainer'
    });

    $('#fecMod').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecModContainer'
    });


    
    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });


    $('#docIdentidad').keyup(function(){
        
        if ($('#btnAceptModalCrud').attr('accion')!='sel'){

            if($(this).val().length == 8 || $(this).val().length == 11){
                
                if($('#tipoDocIdentidad').val() == '1'){

                    $.ajax({
                        'url' : './getDatosDni',                
                        data: {
                            "dni":$(this).val()
                        },
                        'type' : 'POST',
                        'success' : function(data) {
                            
                            var jsonData = JSON.parse(data);
                            //var regUsuario;
                            //$('#codTercero').empty();
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];

                                $('#razonSocial').val(row.razonSocial);
                          
                                
                                
                            }
                        }
                    });
                }else if($('#tipoDocIdentidad').val() == '6'){

                    $.ajax({
                        'url' : './getDatosRuc',                
                        data: {
                            "ruc":$(this).val()
                        },
                        'type' : 'POST',
                        'success' : function(data) {
                            
                            var jsonData = JSON.parse(data);
                            //var regUsuario;
                            //$('#codTercero').empty();
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];

                                $('#razonSocial').val(row.razonSocial);
                          
                                
                                
                            }
                        }
                    });
                }else{
                    messageBox(2,'Error','Selccionar Tipo de Documento');
                }
                
            }

        }



    });
      
}



function getListaTerceros(rc){

    $('#codTercero').empty();
    $('#codTercero').val('');
    $('#codTercero').text('');

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}

/*function validarPlanoInsMas(){
    var file = $('#plano').files[0];
    var item = '';
    var reader = new FileReader();

    reader.onload = function(progressEvent){

        var arrayOne = new Array();
        var arrayOneRow = new Array();
        var mensajeError = '';
        var linea = 0;
        var lines = this.result.split('\n');


        for(var line = 0; line < lines.length; line++){
            item = lines[line];
            item = item.trim();
            if (item != ''){

                arrayOneRow = item.split("\t");

                var rc = arrayOneRow[0];
                var rucTercero = arrayOneRow[1];
                var regResponsableDiligencia = arrayOneRow[2];                 
                
                linea=lines+1

                if (rc.length != 13 ){
                    mensajeError += '<br>Fila: '+linea+', columna rc: '+rc+' debe tener 13 dígitos';
                }
                if (rucTercero.length != 12 ){
                    mensajeError += '<br>Fila: '+linea+', columna rucTercero: '+rucTercero+' debe tener 11 dígitos';
                }
                if (regResponsableDiligencia.length != 4 ){
                    mensajeError += '<br>Fila: '+linea+', columna regResponsableDiligencia: '+regResponsableDiligencia+' debe tener 4 dígitos';
                }
                if(mensajeError==''){
                    arrayOne[line] = arrayPlanoFila;
                }
            }
        }

        if(mensajeError!=''){
            messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
            arrayOne = new Array();
        }
        
        if (arrayOne.length==0){
            alert('El archivo plano está vacío.');
            arrayOne = new Array();
            $('#plano').val("");
        }

    };
    reader.readAsText(file);
    return arrayOne;
}*/

function esDiaHabil(fechaString,feriadosArray){
    
    //*****Formato: 'DD/MM/YYYY' ********/

    //convirtiendo a YYYY-MM-DD
    fechaString=moment(fechaString, 'DD/MM/YYYY').format('YYYY-MM-DD');

    fechaDate = new Date(fechaString);
    
    fechaDate.setTime(fechaDate.getTime() + 24*60*60*1000);

    var anio = fechaDate.getFullYear();
    var mes = (fechaDate.getMonth() + 1) < 10 ? "0" + (fechaDate.getMonth()+1) : fechaDate.getMonth()+1;
    var dia = (fechaDate.getDate()) < 10 ? "0" + (fechaDate.getDate()) : fechaDate.getDate();

    var fechaString = anio + "-" + mes + "-" + dia;

    var feriado = feriadosArray.indexOf(fechaString);

    if(fechaDate.getDay() == 6 || fechaDate.getDay() == 0 || feriado>=0){
        return false;
    }else{
        return true;
    }
}




