
$(document).ready(function () {

    inicializarModulo();
    

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){

        limpiarModalCrud();
        
        $('#tituloCrud').text('Seleccionar');
        $("#btnAceptCrud").attr('accion','sel');
        $("#btnAceptCrud").text('Buscar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#rucDiv").show();
        $("#ruc").prop('disabled', false);
               
        
        $("#ruc").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');

        $('#modalCrud').modal('show');
    }); 
    
    //Modal Ins
    /*$("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloCrud').text('Nuevo Registro');
        $("#btnAceptCrud").attr('accion','ins');
        $("#btnAceptCrud").text('Registrar');
        $("#btnCancelCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formCrud div.form-group").show();
        $("#idCompromisoDiv").hide();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();
        $("#recDiv").show();
        $("#rucDiv").show();
       
        $("#codTerceroDiv").show(); 
        $("#fecPagoPropuestoDiv").show(); 
        $("#fecPagoPropuestoRangoDiv").hide();        
        $("#cantidadPagoPropuesto").show();
        $("#formaPagoPropuestoDiv").show();
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").show(); 
        $("#observacionDiv").show(); 


        $("#fecRegRangoDiv").hide();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").show();



        $("#idCompromiso").focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });*/       

    //btnAceptCrud
    $("#btnAceptCrud").on("click", function(){



        if ($(this).attr('accion')=='sel'){

            if (true){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptCrud").prop("disabled", true);

                $('#dataTableContacto').dataTable().fnClearTable();

                var table = $('#dataTableContacto').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getDatosContacto",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    "columns":
                    [
                        {"data":"ruc"},
                        {"data":"razon_social"},
                        {"data":"tipoContacto"},
                        {"data":"contacto"}     
                    ],

                });

                var table = $('#dataTableDatosRuc').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 

                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getDatosRuc",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    "columns":
                    [
                        {"data":"ruc"},
                        {"data":"razon_social"},
                        {"data":"domicilio"},
                        {"data":"condicion"},
                        {"data":"estado"}
                    ],


                    "columnDefs":[
                    {
                        "targets": 4,
                        "sortable": false,
                        "render": function (data, type, full, meta){

                            if(data == 00){
                                return "<button type='button' class='btn btn-block btn-success btn-sm'>ACTIVO</button> "
                            }else if (data == 11){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>BAJA DE OFICIO</button> "

                            }else if (data == 03){
                                return "<button type='button' class='btn btn-block btn-warning btn-sm'>SUSPENSION TEMPORAL</button> "

                            }
                            else if (data == 04){
                                return "<button type='button' class='btn btn-block btn-warning btn-sm'>ANUL.PROVI-ACTO ILICITO</button> "

                            }
                            else if (data == 10){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>BAJA DEFINITIVA</button> "

                            }
                            else if (data == 01){
                                return "<button type='button' class='btn btn-block btn-warning btn-sm'>BAJA PROVISIONAL</button> "

                            }
                            else if (data == 31){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>ANULACION-ACTO ILICITO</button> "

                            }
                            else if (data == 12){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>BAJA MULT.INSCR Y OTROS</button> "

                            }
                            else if (data == 21){
                                return "<button type='button' class='btn btn-block btn-success btn-sm'>OTROS OBLIGADOS</button> "

                            }
                            else if (data == 22){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>INHABILITADO-VENT. UNICA</button> "

                            }
                            else if (data == 32){
                                return "<button type='button' class='btn btn-block btn-warning btn-sm'>PENDIENTE DE INI. DE ACT</button> "

                            }
                            else if (data == 20){
                                return "<button type='button' class='btn btn-block btn-warning btn-sm'>NUM. INTERNO IDENTIF.</button> "

                            }
                            else if (data == 32){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>ANULACION-ERROR SUNAT</button> "

                            }
                            else if (data == 02){
                                return "<button type='button' class='btn btn-block btn-danger btn-sm'>BAJA PROV. POR OFICIO</button> "

                            }

                        }
                    }
                ],



                  /*"rowCallBack": function( row,data,index) {
                    $condicion = 'ACTIVO';
                    if ( data[4] = $condicion) {
                      $('td', row).eq(4).css({
                        'background-color':'#00D10D',
                        'color' : 'white',

                      });
                    }
                  }*/



                });
               

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                    
                   
                    limpiarModalCrud();

                    $('#tituloCrud').text('Información');
                    $("#btnAceptCrud").attr('accion','get');
                    $("#btnAceptCrud").text('Aceptar');
                    $("#btnCancelCrud").hide();

                  

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptCrud').prop('disabled', false);



                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();
                    
                    $("#codTerceroDiv").show(); 
                    $("#fecPagoPropuestoDiv").show(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#cantidadPagoPropuesto").show();
                    $("#formaPagoPropuestoDiv").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 


                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").show();
                    $("#usuRegDiv").show();
                    $("#estadoDiv").show();




                    $("#idCompromiso").focus();

                    $('#btnAceptCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();


                    


                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){
                     
                    $('#tituloCrud').text('Modificar');
                    $("#btnAceptCrud").attr('accion','upd');
                    $("#btnAceptCrud").text('Guardar');
                    $("#btnCancelCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptCrud').prop('disabled', false);

                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();
                    

                    $("#codTerceroDiv").show(); 
                    $("#fecPagoPropuestoDiv").show(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#cantidadPagoPropuesto").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").show();

                    $("#rcDiv").focus();

                    $('#btnAceptCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloCrud').text('Eliminar');       
                    $("#btnAceptCrud").attr('accion','del');
                    $("#btnAceptCrud").text('Eliminar');
                    $("#btnCancelCrud").show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptCrud').prop('disabled', false);
                    
                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();

                    $("#codTerceroDiv").hide(); 
                    $("#fecPagoPropuestoDiv").hide(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#formaPagoPropuestoDiv").hide();
                    $("#cantidadPagoPropuesto").hide();
                    $("#dniEncargadoTerceroDiv").hide(); 
                    $("#nombreEncargadoTerceroDiv").hide(); 
                    $("#observacionDiv").hide(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").hide();

                    $("#rcDiv").focus();

                    $('#btnAceptCrud').attr('class','btn btn-danger');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');


                })


                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#idCompromiso").val() != "" && $("#idCompromiso").val() != null) &&
                ($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);



                $.ajax({
                    method:"POST",
                    url: "./updCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se modificaron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', true);
            }
        }


        

        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delCompromiso",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Comunicarse con el administrador.");
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se registraron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', false);
            }

        }
    });






        
});

/*function get(id){

    $.ajax({
        method:"POST",
        url : './getCompromisoPago',
        data: {
            "idCompromiso":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $("#idCompromiso").val(row.id);
                
               

                

                $("#rc").val(row.rc);
                $("#rec").val(row.rec);
                $("#ruc").val(row.ruc);

               
                
                
                //$("#codTercero").val(row.codTercero);

                getListaTerceros(row.rc);               
                $("#codTercero").append($("<option selected='selected'></option>").val(row.codTercero).text(row.num_ruc_ter + ' - ' + row.nom_ter)).trigger('change');
                
                //$("#fecPagoPropuesto").val(row.fecPagoPropuesto);
                //$('#fecPagoPropuestoDiv').datepicker('setDate', moment(row.fecPagoPropuesto, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                //alert(row.fecPagoPropuesto);
                //alert();

                $("#fecPagoPropuesto").val(moment(row.fecPagoPropuesto, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                

                $("#formaPagoPropuesto").val(row.formaPagoPropuesto);
                $("#cantidadPagoPropuesto").val(row.cantidadPagoPropuesto);
                $("#dniEncargadoTercero").val(row.dniEncargadoTercero);
                $("#nombreEncargadoTercero").val(row.nombreEncargadoTercero);
                $("#observacion").val(row.observacion);
                $("#fecReg").val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));

                $("#usuReg").val(row.usuReg);
                $("#estado").val(row.estado);


                
            
                
                
                


                
                
            }

        }
    });
}*/

function limpiarModalCrud(){

    $("#formCrud")[0].reset();


    
}
   
function inicializarModulo(){

    
    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){}

    

    setInterval(timer, 10000);

    
}

