
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#idSolicitudServicioDiv').show();
        $('#idSolicitudServicio').prop('disabled', false);
        $('#tipoSolicitudDiv').hide();
        $('#TipoResDiv').hide();
        $('#rutaArchivoPdfDiv').hide();
        $('#rutaArchivoExcelDiv').hide();
        $('#totalDocumentosDiv').hide();
        $('#usuRegDiv').show();
        $('#fecRegDiv').show();
        $('#fecRegRangoDiv').show(); 
        $('#usuAsignaDiv').hide();
        $('#fecAsignaDiv').hide();
        $('#usuTrabajadorDiv').show();
        $('#fecTrabajadorDiv').hide();
        $('#usuCancelaDiv').hide();
        $('#fecCancelaDiv').hide();
        $('#estadoDiv').show();
        $('#obsRegistroDiv').hide();
        $('#obsAtencionDiv').hide();

        $('#idSolicitudServicio').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }



        $('#modalCrud').modal('show');
    });  
    


    //Modal Ins
    $('#mostrarModalIns').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#idSolicitudServicioDiv').hide();
        $('#idSolicitudServicio').prop('disabled', true);
        $('#tipoSolicitudDiv').show();
        $('#TipoResDiv').show();
        $('#rutaArchivoPdfDiv').show();
        $('#rutaArchivoExcelDiv').show();
        $('#totalDocumentosDiv').show();
        $('#usuRegDiv').hide();
        $('#fecRegDiv').hide();
        $('#fecRegRangoDiv').hide();        
        $('#usuAsignaDiv').hide();
        $('#fecAsignaDiv').hide();
        $('#usuTrabajadorDiv').hide();
        $('#fecTrabajadorDiv').hide();
        $('#usuCancelaDiv').hide();
        $('#fecCancelaDiv').hide();
        $('#estadoDiv').hide();
        $('#obsRegistroDiv').show();
        $('#obsAtencionDiv').hide();

        $('#idSolicitudServicio').focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $('#btnAceptModalCrud').on('click', function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();

                
                $('#formCrud *').prop('disabled', true);
                
                $('#btnAceptModalCrud').prop('disabled', true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getSolicitudesServicios",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    "columnDefs": [ {
                        orderable: false,
                        className: 'select-checkbox',
                        targets:   0
                    } ],
                        "select": {
                        //style:    'os',
                        style: 'multi',
                        selector: 'td:first-child'
                    },
                            

                    "columns":
                    [
                        {"data":null,"defaultContent": ""},
                        {"data":"id"},                        
                        {"data":"tipoSolicitud"},
                        {"data":"tipoRes"},
                        {"data":"totalDocumentos"},
                        {"data":"usuReg"},
                        {"data":"fecReg"},
                        {"data":"obsRegistro"},
                        {"data":"obsAtencion"},
                        {"data":"estado"},

                        // {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                        //     if (true){
                        //         $(nTd).html("<form target='_blank' method='post' action='./descargarPdf'>\
                        //         <input type='hidden' name='idSolicitudServicio' value='"+oData.id+"'>\
                        //         <left><input class='btn btn-primary' type='' value='Descargar PDF'></left>\
                        //         </form>");
                        //     }else{
                        //         $(nTd).html("");
                        //     }
                            
                        // }},

                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iR1ow, iCol) {
                            if (oData.rutaArchivoPdf != '' && oData.rutaArchivoExcel != ''){ 
                                 $(nTd).html("<form target='_blank' method='post' action='./descargarPdf'>\
                                <input type='hidden' name='idSolicitudServicio' value='"+oData.id+"'>\
                                <left><button type='submit' idSolicitudServicio='"+oData.id+"' class='descargarPdf btn btn-primary' data-toggle='tooltip'><i class='fas fa-file-pdf'></i></button></left>\
                                </form>\
                                <form target='_blank' method='post' action='./descargarExcel'>\
                                <input type='hidden' name='idSolicitudServicio' value='"+oData.id+"'>\
                                <left><button type='submit' idSolicitudServicio='"+oData.id+"' class='descargarExcel btn btn-primary' data-toggle='tooltip'><i class='fas fa-file-excel'></i></button></left>\
                                </form>");
                            }else if(oData.rutaArchivoPdf.chartAt(0)){
                               $(nTd).html("");
                            }
                            
                        }},

                        
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            if ($('#shape').val()=='1'){
                                if (oData.estado=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                        </div>\
                                    </div>");    
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }
                            else if($('#shape').val()=='2'){
                                if (oData.estado=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalAsi btn btn-primary' data-toggle='tooltip' title='Asingar'><i class='fas fa-user'></i></button>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                        </div>\
                                    </div>");      
                                    table.columns([8]).visible(false);                         
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }
                            else if($('#shape').val()=='3'){
                                if (oData.estado=='02'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalCon btn btn-primary' data-toggle='tooltip' title='Concluir'><i class='fas fa-check'></i></button>\
                                        </div>\
                                    </div>");      
                                    table.columns([8]).visible(false);  

                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idSolicitudServicio='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }

                            }else{
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });
                

                //seleccionar todo
                $("#select_all").on( "click", function(e) {
                if ($(this).is(":checked")) {
                    table.rows().select();        
                } else {
                    table.rows().deselect(); 
                }});

                if($('#shape').val()=='1' || $('#shape').val()=='2' || $('#shape').val()=='3'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }

                // $('#dataTable tbody').on('click','button.descargarPdf',function(){
                //     if($(this).attr("estado")=='01' || $(this).attr("estado")=='02' || $(this).attr("estado")=='02' || $(this).attr("estado")=='03'  ){
                //         window.open("pdfCartaPreliminar?id_carta="+$(this).attr("id_carta"),'_blank');    
                //     }else{
                //         window.open("pdfCarta?id_carta="+$(this).attr("id_carta"),'_blank');    
                //     }
                // });

                // $('#dataTable tbody').on('click','button.descargarXls',function(){
                //     if($(this).attr("estado")=='00' || $(this).attr("estado")=='01' || $(this).attr("estado")=='02' || $(this).attr("estado")=='03'  ){
                //         window.open("pdfCartaPreliminar?id_carta="+$(this).attr("id_carta"),'_blank');    
                //     }else{
                //         window.open("pdfCarta?id_carta="+$(this).attr("id_carta"),'_blank');    
                //     }
                // });


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();
                
                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idSolicitudServicioDiv').show();
                    $('#idSolicitudServicio').prop('disabled', true);  
                    $('#tipoSolicitudDiv').show();
                    $('#TipoResDiv').show();
                    $('#rutaArchivoPdfDiv').hide();
                    $('#rutaArchivoExcelDiv').hide();
                    $('#totalDocumentosDiv').show();
                    $('#usuRegDiv').show();
                    $('#fecRegDiv').show();
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuAsignaDiv').show();
                    $('#fecAsignaDiv').show();
                    $('#usuTrabajadorDiv').hide();
                    $('#fecTrabajadorDiv').hide();
                    $('#usuCancelaDiv').show();
                    $('#fecCancelaDiv').show();
                    $('#estadoDiv').show();
                    $('#obsRegistroDiv').show();
                    $('#obsAtencionDiv').show();


                    $('#idSolicitudServicio').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idSolicitudServicio'));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $('#btnAceptModalCrud').attr('accion','upd');
                    $('#btnAceptModalCrud').text('Guardar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show(); 
                    // $('#idSolicitudServicioDiv').show();
                    // $('#idSolicitudServicio').prop('disabled', true);
                    // $('#tipoSolicitudDiv').hide();
                    // $('#TipoResDiv').hide();
                    // $('#rutaArchivoPdfDiv').hide();
                    // $('#rutaArchivoExcelDiv').hide();
                    // $('#totalDocumentosDiv').hide();
                    // $('#usuRegDiv').hide();
                    // $('#fecRegDiv').hide();
                    // $('#fecRegRangoDiv').hide(); 
                    // $('#usuAsignaDiv').hide();
                    // $('#fecAsignaDiv').hide();
                    // $('#usuTrabajadorDiv').hide();
                    // $('#fecTrabajadorDiv').hide();
                    // $('#usuCancelaDiv').hide();
                    // $('#fecCancelaDiv').hide();
                    // $('#estadoDiv').hide();
                    // $('#obsRegistroDiv').hide();
                    // $('#obsAtencionDiv').hide();

                    $('#idSolicitudServicio').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idSolicitudServicio'));

                    $('#modalCrud').modal('show');
                });

                //Modal Crud (asi)
                $('#dataTable tbody').on('click','button.mostrarModalAsi',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Asignar');
                    $('#btnAceptModalCrud').attr('accion','asi');
                    $('#btnAceptModalCrud').text('Asignar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show(); 
                    $('#idSolicitudServicioDiv').show();
                    $('#idSolicitudServicio').prop('disabled', true);
                    $('#tipoSolicitudDiv').hide();
                    $('#TipoResDiv').show();
                    $('#rutaArchivoPdfDiv').hide();
                    $('#rutaArchivoExcelDiv').hide();
                    $('#totalDocumentosDiv').hide();
                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuAsignaDiv').hide();
                    $('#fecAsignaDiv').hide();
                    $('#usuTrabajadorDiv').show();
                    $('#fecTrabajadorDiv').hide();
                    $('#usuCancelaDiv').hide();
                    $('#fecCancelaDiv').hide();
                    $('#estadoDiv').hide();
                    $('#obsRegistroDiv').hide();
                    $('#obsAtencionDiv').hide();

                    $('#idSolicitudServicio').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idSolicitudServicio'));

                    $('#modalCrud').modal('show');
                });

                //Modal Crud (con)
                $('#dataTable tbody').on('click','button.mostrarModalCon',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Concluir');
                    $('#btnAceptModalCrud').attr('accion','con');
                    $('#btnAceptModalCrud').text('Concluir');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show(); 
                    $('#idSolicitudServicioDiv').show();
                    $('#idSolicitudServicio').prop('disabled', true);
                    $('#tipoSolicitudDiv').show();
                    $('#tipoSolicitud').prop('disabled', true);
                    $('#TipoResDiv').show();
                    $('#tipoRes').prop('disabled', true);
                    $('#rutaArchivoPdfDiv').hide();
                    $('#rutaArchivoExcelDiv').hide();
                    $('#totalDocumentosDiv').hide();
                    $('#usuRegDiv').show();
                    $('#usuReg').prop('disabled', true);
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuAsignaDiv').hide();
                    $('#fecAsignaDiv').hide();
                    $('#usuTrabajadorDiv').hide();
                    $('#fecTrabajadorDiv').hide();
                    $('#usuCancelaDiv').hide();
                    $('#fecCancelaDiv').hide();
                    $('#estadoDiv').hide();
                    $('#obsRegistroDiv').hide();
                    $('#obsAtencionDiv').show();

                    $('#idSolicitudServicio').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idSolicitudServicio'));

                    $('#modalCrud').modal('show');
                });

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#idSolicitudServicioDiv').show();
                    $('#idSolicitudServicio').prop('disabled', true);
                    $('#tipoSolicitudDiv').hide();
                    $('#tipoResDiv').hide();
                    $('#rutaArchivoPdfDiv').hide();
                    $('#rutaArchivoExcelDiv').hide();
                    $('#totalDocumentosDiv').hide();
                    $('#usuRegDiv').hide();
                    $('#fecRegDiv').hide();
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuAsignaDiv').hide();
                    $('#fecAsignaDiv').hide();
                    $('#usuTrabajadorDiv').hide();
                    $('#fecTrabajadorDiv').hide();
                    $('#usuCancelaDiv').hide();
                    $('#fecCancelaDiv').hide();
                    $('#estadoDiv').hide();
                    $('#obsRegistroDiv').hide();
                    $('#obsAtencionDiv').hide();

                    $('#idSolicitudServicio').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('idSolicitudServicio'));

                    $('#modalCrud').modal('show');
                });
                
                $('#alertaUltimosRegistros').hide(); 

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#codTercero").val() != "" && $("#codTercero").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updTomaDicho",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }

        if ($(this).attr('accion')=='asi'){
           

            if (($('#idSolicitudServicio').val() != '' && $('#idSolicitudServicio').val() != null) &&
                ($('#usuTrabajador').val() != '' && $('#usuTrabajador').val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./asiSolicitudServicio",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
     
        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();            
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delSolicitudServicio",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.id + ' ';
                        }   
                        messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                    }
                    catch(e) {
                       messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($('#tipoSolicitud').val() != '' && $('#tipoSolicitud').val() != null) &&
                ($('#tipoRes').val() != '' && $('#tipoRes').val() != null) &&
                ($('#totalDocumentos').val() != '' && $('#obsRegistro').val() != '' && 
                 $('#totalDocumentos').val() != null && $('#rutaArchivoPdf').val() != ''
                 && $('#rutaArchivoExcel').val() != '')){


                $('#formCrud *').prop('disabled', false);
                //var frm = $("#formCrud").serialize();
                var frm = new FormData($("#formCrud")[0]);
                $('#formCrud *').prop('disabled', true);               


                $.ajax({
                    method:"POST",
                    url: "./insSolicitudServicio",
                    processData: false,
                    contentType: false,
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                 messageBox(2,'Error','Existen campos vacíos');
            }
        }

        if ($(this).attr('accion')=='con'){
            
            if ( $('#obsAtencion').val() != '' ){


                $('#formCrud *').prop('disabled', false);
                //var frm = $("#formCrud").serialize();
                var frm = new FormData($("#formCrud")[0]);
                $('#formCrud *').prop('disabled', true);               


                $.ajax({
                    method:"POST",
                    url: "./conSolicitudServicio",
                    processData: false,
                    contentType: false,
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se concluyo la solicitud con Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                 messageBox(2,'Error','Existen campos vacíos');
            }
        }


    });   
        
    //Consulta
    //var myDateIni = new Date(moment($('#fecPrimerPago').val(), 'DD/MM/YYYY').format('YYYY-MM-DD'));

    
    


    if($('#shape').val()=='1'){
        var myDateIni = new Date();
        $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        $('#alertaDataTable').show();  
        $('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }

    if($('#shape').val()=='2'){
        //var myDateIni = new Date();
        //$('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        //$('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        //$('#alertaDataTable').show();  
        //$('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }
    if($('#shape').val()=='3'){
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 
        frmSelBkp = null;


    }

});

function get(id){

    $.ajax({
        method:"POST",
        url : './getSolicitudesServicios',
        data: {
            "idSolicitudServicio":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                
                /*if (row.idArea !== null && row.idArea.trim() !== "" ){
                    $("#idArea").append($("<option selected='selected'></option>").val(row.idArea).text(row.idArea)).trigger('change');
                }*/


                $('#idSolicitudServicio').val(row.id);
                $('#tipoSolicitud').val(row.tipoSolicitud);
                $('#tipoRes').val(row.tipoRes);
                $('#totalDocumentos').val(row.totalDocumentos);
                $('#usuReg').val(row.usuReg);         
                if(row.fecReg != null){
                    $('#fecReg').val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }
                $('#usuAsigna').val(row.usuAsigna);
                if(row.fecAsigna != null){
                    $('#fecAsigna').val(moment(row.fecAsigna, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }   
                $('#usuCancela').val(row.usuTrabajador);
                if(row.fecCancela != null){
                    $('#fecCancela').val(moment(row.fecCancela, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }
                $('#estado').val(row.estado);
                $('#obsRegistro').val(row.obsRegistro);
                $('#obsAtencion').val(row.obsAtencion);
            
                
            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#idSolicitudServicio').val(row.idSolicitudServicio);
        $('#tipoSolicitud').val(row.tipoSolicitud);
        $('#tipoRes').val(row.tipoRes);
        $('#rutaArchivoPdf').val(row.rutaArchivoPdf);
        $('#rutaArchivoExcel').val(row.rutaArchivoExcel);
        $('#totalDocumentos').val(row.totalDocumentos);
        $('#usuReg').val(row.usuReg);
        $('#fecReg').val(row.fecReg);
        $('#usuAsigna').val(row.usuAsigna);
        $('#fecAsigna').val(row.fecAsigna);
        $('#usuTrabajador').val(row.usuTrabajador);
        $('#fecTrabajador').val(row.fecTrabajador);
        $('#usuCancela').val(row.usuCancela);
        $('#fecCancela').val(row.fecCancela);
        $('#estado').val(row.estado);
        $('#obsRegistro').val(row.obsRegistro);
        $('#obsAtencion').val(row.obsAtencion);
        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();
    
    // $('#codTercero').empty();
    // $("#codTercero").val("");
    // $("#codTercero").text("");



    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Registro
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
        
        
    }

    if($('#shape').val()=='2'){
        //Asignacion
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        
    }

    if($('#shape').val()=='3'){
        //Asignacion
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        
    }
    

     
    $('#tipoSolicitud').append($('<option></option>').val('').html('Seleccionar'));
    $('#tipoSolicitud').append($('<option></option>').val('NOTIFICACION').html('NOTIFICACION'));
    $('#tipoSolicitud').append($('<option></option>').val('DIGITALIZACION').html('DIGITALIZACION'));
    $('#tipoSolicitud').append($('<option></option>').val('ARCHIVO').html('ARCHIVO'));
    

    $('#tipoRes').append($('<option></option>').val('').html('Seleccionar'));
    $('#tipoRes').append($('<option></option>').val('OTRAS RSIRAT/NO EMBARGOS').html('OTRAS RSIRAT/NO EMBARGOS'));
    $('#tipoRes').append($('<option></option>').val('EMBARGOS').html('EMBARGOS'));
    

    setInterval(timer, 10000);


    $('#fecReg').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegContainer'
    });

    $('#fecRegIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegIniContainer'
    });

    $('#fecRegFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegFinContainer'
    });
    
    $('#fecAsigna').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecAsignaContainer'
    });

    $('#fecTrabajador').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecTrabajadorContainer'
    });

    $('#fecCancela').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecCancelaContainer'
    });
    
                                                                                                                                                    

    $('#usuTrabajador').select2({ 

        placeholder: 'Seleccionar', 
        minimumInputLength: 3, 
        dropdownParent: $('#formCrud'),
        language: {
            inputTooShort: function() {
                return 'Agregar caracteres para buscar...'
            }
        },
        multiple: false, 
        width: '100%',
        ajax: { 
            url: '../aplicacion/getUsuarioSelect2',
            type: 'POST', 
            data: function(term) { 
                return term;
               
            }, 
            processResults: function(data, page) { 
                var jsonData = JSON.parse(data);
                return { 
                    results: $.map(jsonData.data, function (item) {
                        return {
                            id: item.id,
                            text: item.id + ' - ' + item.nombres 
                        }
                    })                    
                }; 
            }
        } 
    });





    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });


}










