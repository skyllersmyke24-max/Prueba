
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        
       
        $('#IDDiv').show();
        $('#ID').prop('disabled', false);
        $('#RLADUANADiv').show();
        $('#RLADUANA').prop('disabled', false);
        $('#RLANODiv').show();
        $('#RLANO').prop('disabled', false);
        $('#RLNROLIQDiv').show();
        $('#RLNROLIQ').prop('disabled', false);
        $('#ADUANADiv').hide();

        $('#TIPO_LIQUIDACIONDiv').hide();
        $('#ADUANADiv').hide();

        $('#FEC_LIQUIDACIONDiv').hide();
        $('#TIP_LIQUIDACIONDiv').hide();
        $('#TIP_USUARIODiv').hide();
        $('#RLCODUSUDiv').hide();
        $('#RLTIPDOCDiv').hide();
        $('#RLLIBTRIDiv').hide();
        $('#RLCOMITEDiv').hide();
        $('#RLCODORIDESCDiv').hide();

        $('#RLDETALLDiv').hide();
        $('#RLDETAL2Div').hide();
        $('#RLDETAL3Div').hide();
        $('#RLDETAL4Div').hide();
        $('#RLDETAL5Div').hide();
        $('#MONEDADiv').hide();
        $('#MONTO_SOLESDiv').hide();
        $('#MONTO_DOLARESDiv').hide();
        $('#PAGOS_SOLESDiv').hide();
        $('#PAGOS_DOLARESDiv').hide();
        $('#FEC_CANCELADODiv').hide();

        $('#EXP_COACTIVODiv').show();
        $('#SUPERVISORDiv').show();
        $('#EQUIPODiv').show();
        

        $('#RLADUANA').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $('#mostrarModalIns').on('click', function(){
        
        // limpiarModalCrud();

        // $('#tituloModalCrud').text('Nuevo Registro');
        // $('#btnAceptModalCrud').attr('accion','ins');
        // $('#btnAceptModalCrud').text('Registrar');
        // $('#btnCancelModalCrud').show();

        // $('#formCrud *').prop('disabled', false);
        // $('#btnAceptModalCrud').prop('disabled', false);

        // $('#formCrud div.form-group').show();
        // $('#NUMERO_LIQUIDACIONDiv').show();
        // $('#NUMERO_LIQUIDACION').prop('disabled', false);
        // $('#RLLIBTRIDiv').show();
                

        // $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        // $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $('#btnAceptModalCrud').on('click', function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $('#btnAceptModalCrud').prop('disabled', true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getLiquidaciones",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },                                                
                    
                    "columns":
                    [
                        {'data':'NUMERO_LIQUIDACION'},                   
                        {'data':'TIPO_LIQUIDACION'}, 
                        {'data':'ADUANA'}, 
                        {'data':'FEC_LIQUIDACION'}, 
                        {'data':'TIP_LIQUIDACION'}, 
                        {'data':'TIP_USUARIO'}, 
                        {'data':'RLCODUSU'}, 
                        {'data':'RLTIPDOC'}, 
                        {'data':'RLLIBTRI'}, 
                        {'data':'RLCOMITE'}, 
                        {'data':'RLCODORIDESC'},
                        {'data':'RLDETALL'},
                        {'data':'RLDETAL2'},
                        {'data':'RLDETAL3'},
                        {'data':'RLDETAL4'},
                        {'data':'RLDETAL5'},
                        {'data':'MONEDA'},
                        {'data':'MONTO_SOLES'},
                        {'data':'MONTO_DOLARES'},
                        {'data':'PAGOS_SOLES'},
                        {'data':'PAGOS_DOLARES'},
                        {'data':'EXP_COACTIVO'},
                        {'data':'SUPERVISOR'},
                        {'data':'EQUIPO'},
                        {"data":"ID","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./liquidacionSaldo'>\
                                <input type='hidden' name='ID' value='"+oData.ID+"'>\
                                <input type='hidden' name='RLADUANA' value='"+oData.RLADUANA+"'>\
                                <input type='hidden' name='RLANO' value='"+oData.RLANO+"'>\
                                <input type='hidden' name='RLNROLIQ' value='"+oData.RLNROLIQ+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Saldo de Liquidación N° "+oData.NUMERO_LIQUIDACION+"''>\
                                <left><input class='btn btn-primary' type='submit' value='Saldo'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"ID","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./consultaDeudor'>\
                                <input type='hidden' name='RLLIBTRI' value='"+oData.RLLIBTRI+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Reporte Deudor N° "+oData.RLLIBTRI+"-"+oData.RLCOMITE+"''>\
                                <left><input class='btn btn-primary' type='submit' value='Deudor Reporte'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"ID","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./liquidacionDetalle'>\
                                <input type='hidden' name='ID' value='"+oData.ID+"'>\
                                <input type='hidden' name='RLADUANA' value='"+oData.RLADUANA+"'>\
                                <input type='hidden' name='RLANO' value='"+oData.RLANO+"'>\
                                <input type='hidden' name='RLNROLIQ' value='"+oData.RLNROLIQ+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Detalle Deuda de Liquidación N° "+oData.NUMERO_LIQUIDACION+"''>\
                                <left><input class='btn btn-primary' type='submit' value='Detalle Deuda'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"NUMERO_LIQUIDACION","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            if ($('#shape').val()=='1'){
                                
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' NUMERO_LIQUIDACION='"+oData.NUMERO_LIQUIDACION+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");                                
                                
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });
                

                //seleccionar todo
                $("#select_all").on( "click", function(e) {
                if ($(this).is(":checked")) {
                    table.rows().select();        
                } else {
                    table.rows().deselect(); 
                }});

                if($('#shape').val()=='1'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();
                
                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();  

                    $('#IDDiv').show();
                    $('#ID').prop('disabled', true);
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    $('#ADUANADiv').hide();

                    $('#TIPO_LIQUIDACIONDiv').show();
                    $('#ADUANADiv').show();
                    $('#FEC_LIQUIDACIONDiv').show();
                    $('#TIP_LIQUIDACIONDiv').show();
                    $('#TIP_USUARIODiv').show();
                    $('#RLCODUSUDiv').show();
                    $('#RLTIPDOCDiv').show();
                    $('#RLLIBTRIDiv').show();
                    $('#RLCOMITEDiv').show();
                    $('#RLCODORIDESCDiv').show();
                    $('#RLDETALLDiv').show();
                    $('#RLDETAL2Div').show();
                    $('#RLDETAL3Div').show();
                    $('#RLDETAL4Div').show();
                    $('#RLDETAL5Div').show();
                    $('#MONEDADiv').show();
                    $('#MONTO_SOLESDiv').show();
                    $('#MONTO_DOLARESDiv').show();
                    $('#PAGOS_SOLESDiv').show();
                    $('#PAGOS_DOLARESDiv').show();

                    $('#EXP_COACTIVODiv').show();
                    $('#SUPERVISORDiv').show();
                    $('#EQUIPODiv').show();

                    $('#RLADUANA').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('NUMERO_LIQUIDACION'));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    // limpiarModalCrud();
                     
                    // $('#tituloModalCrud').text('Modificar');
                    // $('#btnAceptModalCrud').attr('accion','upd');
                    // $('#btnAceptModalCrud').text('Guardar');
                    // $('#btnCancelModalCrud').show();

                    // $('#formCrud *').prop('disabled', false);
                    // $('#btnAceptModalCrud').prop('disabled', false);

                    // $('#formCrud div.form-group').show();
                    // $('#idAduanaLlamadaDiv').show();
                    // $('#idAduanaLlamada').prop('disabled', true);
                    // $('#fecLlamadaDiv').show();
                    // $('#tipoDocIdentidadDiv').show();
                    // $('#tipoDocIdentidad').prop('disabled', true);
                    // $('#docIdentidadDiv').show();
                    // $('#docIdentidad').prop('disabled', true);
                    // $('#razonSocialDiv').show();
                    // $('#razonSocial').prop('disabled', true);
                    // $('#telefonoDiv').show();
                    // $('#apellidoPaternoDiv').show();
                    // $('#apellidoMaternoDiv').show();
                    // $('#nombresDiv').show();
                    // $('#cargoDiv').show();
                    // $('#contribuyenteContactadoDiv').show();
                    // $('#resultadoLlamadaDiv').show();
                    // $('#resultadoNegociacionDiv').show();
                    // $('#tipoLLamadaDiv').show();
                    // $('#observacionDiv').show();
                    // $('#expCoactivoDiv').show();
                    // $('#rcEmbargoDiv').show();
                    // $('#respuestaDiv').show();
                    // $('#fecEstimadaEntregaDiv').show();

                    // $('#usuRegDiv').hide();
                    // $('#fecRegDiv').hide();
                    // $('#fecRegRangoDiv').hide();
                    // $('#usuModDiv').hide();
                    // $('#fecModDiv').hide();
                    // $('#estadoDiv').hide();

                    // $('#idAduanaLlamadaDiv').focus();

                    // $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    // get($(this).attr('idAduanaLlamada'));

                    // $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    // limpiarModalCrud();

                    // $('#tituloModalCrud').text('Eliminar');       
                    // $('#btnAceptModalCrud').attr('accion','del');
                    // $('#btnAceptModalCrud').text('Eliminar');
                    // $('#btnCancelModalCrud').show();

                    // $('#formCrud *').prop('disabled', true);
                    // $('#btnAceptModalCrud').prop('disabled', false);
                    
                    // $('#formCrud div.form-group').show();
                    // $('#idTomaDichoDiv').show();
                    // $('#idTomaDicho').prop('disabled', true);
                    // $('#tipoDocIdentidadDiv').hide();
                    // $('#tipoDocIdentidad').prop('disabled', true);
                    // $('#docIdentidadDiv').hide();
                    // $('#docIdentidad').prop('disabled', true);
                    // $('#razonSocialDiv').hide();
                    // $('#razonSocial').prop('disabled', true);
                    // $('#telefonoDiv').hide();
                    // $('#fecLlamadaDiv').hide();
                    // $('#apellidoPaternoDiv').hide();
                    // $('#apellidoMaternoDiv').hide();
                    // $('#nombresDiv').hide();
                    // $('#cargoDiv').hide();
                    // $('#contribuyenteContactadoDiv').hide();
                    // $('#resultadoLlamadaDiv').hide();
                    // $('#resultadoNegociacionDiv').hide();
                    // $('#tipoLLamadaDiv').hide();
                    // $('#observacionDiv').hide();
                    // $('#expCoactivoDiv').hide();
                    // $('#rcEmbargoDiv').hide();
                    // $('#respuestaDiv').hide();
                    // $('#fecEstimadaEntregaDiv').hide();

                    // $('#usuRegDiv').hide();
                    // $('#fecRegDiv').hide();
                    // $('#fecRegRangoDiv').hide();
                    // $('#usuModDiv').hide();
                    // $('#fecModDiv').hide();
                    // $('#estadoDiv').hide();

                    // $('#idAduanaLlamadaDiv').focus();

                    // $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    // get($(this).attr('idAduanaLlamadaDiv'));

                    // $('#modalCrud').modal('show');
                })
                    
                $('#alertaDataTable').hide();

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar algún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            // if (($("#docIdentidad").val() != "" && $("#docIdentidad").val() != null)){
                
            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./updAduanaLlamada",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
            //             }
            //             catch(e) {
            //                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //             }   
                        
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }
            //     });
            // }else{
            //     messageBox(2,'Error','Existen campos vacíos');
            // }
        }
     
        if ($(this).attr('accion')=='del'){
           
            // $('#formCrud *').prop('disabled', false);
            // var frm = $("#formCrud").serialize();            
            // $('#formCrud *').prop('disabled', true);

            // $.ajax({
            //     method:"POST",
            //     url: "./delAduanaLlamada",
            //     data: frm,
            //     success : function(data) {
                    
            //         $('#modalCrud').modal('hide');
            //         $('#dataTable').DataTable().ajax.reload();

            //         try {
            //             var jsonData = JSON.parse(data);
            //             var msjDatos = '';
            //             for (var i = 0; i < jsonData.data.length; i++) {
            //                 var row = jsonData.data[i];
            //                 msjDatos += row.id + ' ';
            //             }   
            //             messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
            //         }
            //         catch(e) {
            //            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }   
                   
            //     },
            //     error: function( req, status, err ) {
            //         messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //     }
            // });
        }

        if ($(this).attr('accion')=='ins'){
            
            // if (($("#docIdentidad").val() != "" && $("#docIdentidad").val() != null) &&
            //     ($("#telefono").val() != "" && $("#telefono").val() != null)){


            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./insAduanaLlamada",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
            //             }
            //             catch(e) {
            //                messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //             }   

                        
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,'Error','Reportar a: '+$('#correoti').val());
            //         }
            //     });
            
            // }else{
            //     messageBox(2,'Error','Existen campos vacíos');
            // }
        }
    });   
        
    


    if($('#shape').val()=='1'){
        // var myDateIni = new Date();
        // $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        // $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#ultimosRegistros').val('1');

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        $('#ultimosRegistros').val('');
        //$('#mostrarModalSel').trigger('click'); 

        frmSelBkp = null;

        $('#alertaDataTable').show();  
        $('#alertaDataTableMensaje').text('Se muestran los útimos 1000 registros. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }
 

  
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getSolicitudesProcesadas',
        data: {
            "NUMERO_LIQUIDACION":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#ID').val(row.ID);
                $('#RLADUANA').val(row.RLADUANA);
                $('#RLANO').val(row.RLANO);
                $('#RLNROLIQ').val(row.RLNROLIQ); 

                $('#TIPO_LIQUIDACION').val(row.TIPO_LIQUIDACION);
                $('#ADUANA').val(row.ADUANA);

                $('#FEC_LIQUIDACION').val(row.FEC_LIQUIDACION);
                $('#TIP_LIQUIDACION').val(row.TIP_LIQUIDACION);
                $('#TIP_USUARIO').val(row.TIP_USUARIO);
                $('#RLCODUSU').val(row.RLCODUSU);
                $('#RLTIPDOC').val(row.RLTIPDOC);
                $('#RLLIBTRI').val(row.RLLIBTRI);
                $('#RLCOMITE').val(row.RLCOMITE);
                $('#RLCODORIDESC').val(row.RLCODORIDESC);
                $('#RLDETALL').val(row.RLDETALL);

                $('#RLDETAL2').val(row.RLDETAL2);
                $('#RLDETAL3').val(row.RLDETAL3);
                $('#RLDETAL4').val(row.RLDETAL4);
                $('#RLDETAL5').val(row.RLDETAL5);
                $('#MONEDA').val(row.MONEDA);
                $('#MONTO_SOLES').val(row.MONTO_SOLES);
                $('#MONTO_DOLARES').val(row.MONTO_DOLARES);
                $('#PAGOS_SOLES').val(row.PAGOS_SOLES);
                $('#PAGOS_DOLARES').val(row.PAGOS_DOLARES);

                $('#PAGOS_DOLARES').val(row.EXP_COACTIVO);
                $('#PAGOS_DOLARES').val(row.SUPERVISOR);
                $('#PAGOS_DOLARES').val(row.EQUIPO);


                // if(row.fecEstimadaEntrega != null){
                //     $('#fecEstimadaEntrega').val(moment(row.fecEstimadaEntrega, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                // }     

               
            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#TIPO_LIQUIDACION').val(row.TIPO_LIQUIDACION);
        $('#ADUANA').val(row.ADUANA);
        $('#NUMERO_LIQUIDACION').val(row.NUMERO_LIQUIDACION);
        $('#FEC_LIQUIDACION').val(row.FEC_LIQUIDACION);
        $('#TIP_LIQUIDACION').val(row.TIP_LIQUIDACION);
        $('#TIP_USUARIO').val(row.TIP_USUARIO);
        $('#RLCODUSU').val(row.RLCODUSU);
        $('#RLTIPDOC').val(row.RLTIPDOC);
        $('#RLLIBTRI').val(row.RLLIBTRI);
        $('#RLCOMITE').val(row.RLCOMITE);
        $('#RLCODORIDESC').val(row.RLCODORIDESC);
        $('#RLDETALL').val(row.RLDETALL);

        $('#RLDETAL2').val(row.RLDETAL2);
        $('#RLDETAL3').val(row.RLDETAL3);
        $('#RLDETAL4').val(row.RLDETAL4);
        $('#RLDETAL5').val(row.RLDETAL5);
        $('#MONEDA').val(row.MONEDA);
        $('#MONTO_SOLES').val(row.MONTO_SOLES);
        $('#MONTO_DOLARES').val(row.MONTO_DOLARES);
        $('#PAGOS_SOLES').val(row.PAGOS_SOLES);
        $('#PAGOS_DOLARES').val(row.PAGOS_DOLARES);


        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();
    
    // $('#codTercero').empty();
    // $("#codTercero").val("");
    // $("#codTercero").text("");



    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
    }

    
     
    // $('#tipoDocIdentidad').append($('<option></option>').val('').html('Seleccionar'));
    // $('#tipoDocIdentidad').append($('<option></option>').val('1').html('DNI'));
    // $('#tipoDocIdentidad').append($('<option></option>').val('6').html('RUC'));
    // $('#tipoDocIdentidad').append($('<option></option>').val('7').html('OTRO'));

    setInterval(timer, 10000);


    // $('#fecEstimadaEntrega').datepicker({
    //     todayBtn: "linked",
    //     //keyboardNavigation: false,
    //     //forceParse: false,
    //     calendarWeeks: false,
    //     autoclose: true,
    //     format: 'dd/mm/yyyy',
    //     //startDate: '-90d',  
    //     //endDate: '+90d', //startDate: '-1d',  
    //     language: 'es',
    //     //daysOfWeekDisabled: [0],
    //     container:'#fecEstimadaEntregaContainer'
    // });

    
    
    // $("#formCrud").find(':input').each(function() {
    //     $("#"+this.id).keyup(function(){
    //         $(this).val($(this).val().replace('"', ''));
    //         $(this).val($(this).val().replace("'", ""));
    //     });
    // });


   
      
}






