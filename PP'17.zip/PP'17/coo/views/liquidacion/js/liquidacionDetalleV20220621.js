
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        
        $('#IDDiv').hide();
        $('#RLADUANADiv').show();
        $('#RLADUANA').prop('disabled', false);
        $('#RLANODiv').show();
        $('#RLANO').prop('disabled', false);
        $('#RLNROLIQDiv').show();
        $('#RLNROLIQ').prop('disabled', false);
        $('#RDCODRUBDiv').hide();
        $('#DESCRIDiv').hide();
        $('#RDMONDETDiv').hide();
        $('#FMODDiv').hide();
        $('#FLAGDiv').hide();


        $('#RLADUANA').focus();        

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }
        
        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        // limpiarModalCrud();

        // $('#tituloModalCrud').text('Nuevo Registro');
        // $('#btnAceptModalCrud').attr('accion','ins');
        // $('#btnAceptModalCrud').text('Registrar');
        // $('#btnCancelModalCrud').show();

        // $('#formCrud *').prop('disabled', false);
        // $('#btnAceptModalCrud').prop('disabled', false);

        // $('#formCrud div.form-group').show();
        // $('#idDiligenciaDiv').hide();
        // $('#idDiligencia').prop('disabled', true);
        // $('#idTomaDichoDiv').show();
        // $('#idTomaDicho').prop('disabled', true);
        // $('#fecDiligenciaDiv').show();
        // $('#fecDiligenciaRangoDiv').hide();
        // $('#resultadoDiv').show();
        // $('#observacionDiv').show();
        // $('#mtoInformadoDiv').show();
        // $('#nombreEncargadoTerDiv').show();        
        // $('#telefonoEncargadoTerDiv').show();
        // $('#correoEncargadoTerDiv').show(); 
        // $('#regResponsableDiligenciaDiv').show();
        // $('#usuRegDiv').hide();
        // $('#fecRegDiv').hide();
        // $('#fecRegRangoDiv').hide();
        // $('#usuModDiv').hide();
        // $('#fecModDiv').hide();
        // $('#estadoDiv').hide(); 

        // $('#resultado').val('4');
        // $('#regResponsableDiligencia').val($('#idUsuario').val());

        // $('#idDiligencia').focus();
        
        
        // //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        // //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        // $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        // $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable.hidden({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getLiquidacionesDetalle",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"RLADUANA"},
                        {"data":"RLANO"},                        
                        {"data":"RLNROLIQ"},
                        {"data":"RDCODRUB"},
                        {"data":"DESCRI"},
                        {"data":"RDMONDET"},     
                        {"data":"FMOD"},
                        {"data":"FLAG"}

                        // {"data":"RLANO","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                        //     //$(nTd).html("");
                        //     if ($('#shape').val()=='1'){
                        //         $(nTd).html("<div class='btn-toolbar m-b-10'>\
                        //             <div class='btn-group'>\
                        //                 <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                        //             </div>\
                        //         </div>");
                               
                        //     }
                        //     else if ($('#shape').val()=='2'){
                        //         $(nTd).html("<div class='btn-toolbar m-b-10'>\
                        //             <div class='btn-group'>\
                        //                 <button type='button' RLADUANA='"+oData.RLADUANA+"' RLANO='"+oData.RLANO+"' RLNROLIQ='"+oData.RLNROLIQ+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                        //             </div>\
                        //         </div>");                            
                        //     }else{                                
                        //         $(nTd).html("");
                        //     }
                            
                        // }}
                    ],
                });

                if ($('#shape').val()=='1' || $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                        buttons: [
                           { 
                                extend: 'excel', 
                                text: 'Descargar Excel', 
                                className:'buttonDataTable', 
                                type:'button'
                            }
                        ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){

                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#IDDiv').hide();
                    $('#RLADUANADiv').show();
                    $('#RLADUANA').prop('disabled', true);
                    $('#RLANODiv').show();
                    $('#RLANO').prop('disabled', true);
                    $('#RLNROLIQDiv').show();
                    $('#RLNROLIQ').prop('disabled', true);
                    $('#RDCODRUBDiv').show();
                    $('#DESCRIDiv').show();
                    $('#RDMONDETDiv').show();


                    $('#RLADUANA').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('RLADUANA'),$(this).attr('RLANO'),$(this).attr('RLNROLIQ'));     

                    $('#modalCrud').modal('show');
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    // limpiarModalCrud();
                     
                    // $('#tituloModalCrud').text('Modificar');
                    // $('#btnAceptModalCrud').attr('accion','upd');
                    // $('#btnAceptModalCrud').text('Guardar');
                    // $('#btnCancelModalCrud').show();

                    // $('#formCrud *').prop('disabled', false);
                    // $('#btnAceptModalCrud').prop('disabled', false);

                    // $('#formCrud div.form-group').show();
                    // $('#idDiligenciaDiv').show();
                    // $('#idDiligencia').prop('disabled', true);
                    // $('#idTomaDichoDiv').show();
                    // $('#idTomaDicho').prop('disabled', true);
                    // $('#fecDiligenciaDiv').show();
                    // $('#fecDiligenciaRangoDiv').hide();
                    // $('#resultadoDiv').show();
                    // $('#observacionDiv').show();
                    // $('#mtoInformadoDiv').show();
                    // $('#nombreEncargadoTerDiv').show();        
                    // $('#telefonoEncargadoTerDiv').show();
                    // $('#correoEncargadoTerDiv').show(); 
                    // $('#regResponsableDiligenciaDiv').hide();
                    // $('#usuRegDiv').hide();
                    // $('#fecRegDiv').hide();
                    // $('#fecRegRangoDiv').hide();
                    // $('#usuModDiv').hide();
                    // $('#fecModDiv').hide();
                    // $('#estadoDiv').hide(); 

                    // $('#idDiligencia').focus();

                    // $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    // get($(this).attr('idDiligencia'));

                    // $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    // limpiarModalCrud();

                    // $('#tituloModalCrud').text('Eliminar');       
                    // $('#btnAceptModalCrud').attr('accion','del');
                    // $('#btnAceptModalCrud').text('Eliminar');
                    // $('#btnCancelModalCrud').show();

                    // $('#formCrud *').prop('disabled', true);
                    // $('#btnAceptModalCrud').prop('disabled', false);
                    
                    // $('#formCrud div.form-group').show();
                    // $('#idDiligenciaDiv').show();
                    // $('#idDiligencia').prop('disabled', true);
                    // $('#idTomaDichoDiv').show();
                    // $('#idTomaDicho').prop('disabled', true);
                    // $('#fecDiligenciaDiv').show();
                    // $('#fecDiligenciaRangoDiv').hide();
                    // $('#resultadoDiv').show();
                    // $('#observacionDiv').show();
                    // $('#mtoInformadoDiv').show();
                    // $('#nombreEncargadoTerDiv').hide();        
                    // $('#telefonoEncargadoTerDiv').hide();
                    // $('#correoEncargadoTerDiv').hide(); 
                    // $('#regResponsableDiligenciaDiv').hide();
                    // $('#usuRegDiv').hide();
                    // $('#fecRegDiv').hide();
                    // $('#fecRegRangoDiv').hide();
                    // $('#usuModDiv').hide();
                    // $('#fecModDiv').hide();
                    // $('#estadoDiv').hide(); 

                    // $('#idDiligencia').focus();

                    // $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    // get($(this).attr('idDiligencia'));

                    // $('#modalCrud').modal('show');
                })

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            // if ((($('#resultado').val() !='2' && $('#resultado').val() !='3' && $('#resultado').val() !='4') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#resultado').val() != '' && $('#resultado').val() != null))
            //     ||
            //     (($('#resultado').val() =='2' || $('#resultado').val() =='3') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
            //     ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))
            //     ||
            //     (($('#resultado').val() =='4') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#mtoInformado').val() != '' && $('#mtoInformado').val() != null) &&
            //     ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
            //     ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))){
                
            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./updDiligencia",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);
            //                 getDatosGenerales(row.idTomaDicho);
            //             }
            //             catch(e) {
            //                messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //             }   
                        
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //         }
            //     });
            // }else{
            //     messageBox(2,"Error","Existen campos vacíos");
            // }
        }

        if ($(this).attr('accion')=='del'){
           
            // $('#formCrud *').prop('disabled', false);
            // var frm = $("#formCrud").serialize();            
            // $('#formCrud *').prop('disabled', true);

            // $.ajax({
            //     method:"POST",
            //     url: "./delDiligencia",
            //     data: frm,
            //     success : function(data) {
                    
            //         $('#modalCrud').modal('hide');
            //         $('#dataTable').DataTable().ajax.reload();

            //         try {
            //             var jsonData = JSON.parse(data);
            //             var msjDatos = '';
            //             for (var i = 0; i < jsonData.data.length; i++) {
            //                 var row = jsonData.data[i];
            //                 msjDatos += row.id + ' ';
            //             }   
            //             messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
            //             getDatosGenerales(row.idTomaDicho);
            //         }
            //         catch(e) {
            //            messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //         }   
                   
            //     },
            //     error: function( req, status, err ) {
            //         messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //     }
            // });
        }

        if ($(this).attr('accion')=='ins'){
            
            // if ( (($('#resultado').val() !='2' && $('#resultado').val() !='3' && $('#resultado').val() !='4') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#resultado').val() != '' && $('#resultado').val() != null))
            //     ||
            //     (($('#resultado').val() =='2' || $('#resultado').val() =='3') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
            //     ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null))
            //     ||
            //     (($('#resultado').val() =='4') &&
            //     ($('#idTomaDicho').val() != '' && $('#idTomaDicho').val() != null) &&
            //     ($('#fecDiligencia').val() != '' && $('#fecDiligencia').val() != null) &&
            //     ($('#mtoInformado').val() != '' && $('#mtoInformado').val() != null) &&
            //     ($('#nombreEncargadoTer').val() != '' && $('#nombreEncargadoTer').val() != null) &&               
            //     ($('#regResponsableDiligencia').val() != '' && $('#regResponsableDiligencia').val() != null)) ){


            //     $('#formCrud *').prop('disabled', false);
            //     var frm = $("#formCrud").serialize();
            //     $('#formCrud *').prop('disabled', true);

            //     $.ajax({
            //         method:"POST",
            //         url: "./insDiligencia",
            //         data: frm,
            //         success : function(data) {
                        
            //             $('#dataTable').DataTable().ajax.reload();
            //             $('#modalCrud').modal('hide');

            //             try {
            //                 var jsonData = JSON.parse(data);
            //                 var msjDatos = '';
            //                 for (var i = 0; i < jsonData.data.length; i++) {
            //                     var row = jsonData.data[i];
            //                     msjDatos += row.id + ' ';
            //                 }   
            //                 messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
            //                 getDatosGenerales(row.idTomaDicho);
            //             }
            //             catch(e) {
            //                messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //             }   

                        
            //         },
            //         error: function( req, status, err ) {
            //             messageBox(3,"Error","Reportar a: "+$('#correoti').val());
            //         }
            //     });
            
            // }else{
            //     messageBox(2,"Error","Existen campos vacíos");
            // }
        }

    });
    
    if($('#shape').val()=='1'){
        // var myDateIni = new Date();
        // $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        // $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        // $('#btnAceptModalCrud').attr('accion','sel');
        // $('#btnAceptModalCrud').trigger('click'); 

        $('#mostrarModalSel').trigger('click'); 

        frmSelBkp = null;

        // $('#alertaDataTable').show();  
        // $('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }

    if($('#shape').val()=='2'){
        //var myDateIni = new Date();
        //$('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        //$('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        //$('#alertaDataTable').show();  
        //$('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');

    }  
        
});

function get(RLADUANA,RLANO,RLNROLIQ){

    $.ajax({
        method:"POST",
        url : './getDiligencias',
        data: {
            "idDiligencia":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                
                $('#idDiligencia').val(row.id);
                $('#idTomaDicho').val(row.idTomaDicho);
                
                if(row.fecDiligencia != null){
                    $('#fecDiligencia').val(moment(row.fecDiligencia, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }     
                
                $('#resultado').val(row.resultado);

                $('#resultado').trigger('change');

                $('#observacion').val(row.observacion);
                $('#mtoInformado').val(row.mtoInformado);
                $('#nombreEncargadoTer').val(row.nombreEncargadoTer);

                $('#telefonoEncargadoTer').val(row.telefonoEncargadoTer);
                $('#correoEncargadoTer').val(row.correoEncargadoTer);
                $('#regResponsableDiligencia').val(row.regResponsableDiligencia);
                $('#estado').val(row.estado);
             

            
                
            }

        }
    });
}

function getDatosGenerales(ID){

    $.ajax({
        method:"POST",
        url : './getSolicitudesProcesadas',
        data: {
            "ID":ID,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                //$('#ID2').val(row.ID);
                

                $('#RLADUANA2').val(row.RLADUANA);
                $('#RLANO2').val(row.RLANO);
                $('#RLNROLIQ2').val(row.RLNROLIQ);
                               
                
            }
        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#idTomaDicho').val(row.idTomaDicho);
        $('#rc').val(row.rc);
        $('#rucContribuyente').val(row.rucContribuyente);
        $('#rucTercero').val(row.rucTercero);
        $('#fecTomaDichoIni').val(row.fecTomaDichoIni);
        $('#fecTomaDichoFin').val(row.fecTomaDichoFin);
        $('#regResponsableDiligencia').val(row.regResponsableDiligencia);
        $('#resultado').val(row.resultado);
        $('#codAuxRc').val(row.codAuxRc);
        $('#codEjeRc').val(row.codEjeRc);
        $('#fecRegIni').val(row.fecRegIni);
        $('#fecRegFin').val(row.fecRegFin);        
        $('#estado').val(row.estado);
        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();


    //$("#idUsuario").val("");
    //$("#idUsuario").text("");

    

    $('#codTercero').empty();
    $("#codTercero").val("");
    $("#codTercero").text("");



    //$("#tipoFrecuencia").val("");
    
    

    /*$("#numOrdFis").val("");
    $("#numOrdFis").text("");*/


    

    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General        
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
        $('#cardDatosGenerales').hide();

        
    }
    if($('#shape').val()=='2'){
        //Consulta por id 
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        $('#cardDatosGenerales').hide();

        getDatosGenerales($("#ID2").val());
    }
           
    var feriadosArray = new Array();
   
    
    //var dt = moment(myDate.date, "YYYY-MM-DD HH:mm:ss")




    setInterval(timer, 10000);

    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });
    

     



    
    
}








