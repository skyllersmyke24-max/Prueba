
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#id_cuentaDiv').show();
        $('#id_cuenta').prop('disabled', false);
        $('#id_usuarioDiv').show();
        $('#id_dependenciaDiv').show();
        $('#estadoDiv').show();
        $('#contador_ingresoDiv').hide();
        $('#ultimo_ingresoDiv').hide();

        $('#id_cuenta').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#id_cuentaDiv').hide();
        $('#id_cuenta').prop('disabled', false);
        $('#id_usuarioDiv').show();
        $('#id_dependenciaDiv').show();
        $('#estadoDiv').show();
        $('#contador_ingresoDiv').hide();
        $('#ultimo_ingresoDiv').hide();

        $('#id_cuenta').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"asc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getCuentas",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"id"},                           
                        {"data":"id_usuarioDesc"},
                        {"data":"id_dependenciaDesc"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./perfil'>\
                                <input type='hidden' name='idCuentaInd' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Perfiles vinculados a la Cuenta N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='"+oData.totalPerfilesVinculados+"'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"estadoDesc"},
                        {"data":"contador_ingreso"},
                        {"data":"ultimo_ingreso"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {

                            if ($('#shape').val()=='1'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' id_cuenta='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        <button type='button' id_cuenta='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                        <button type='button' id_cuenta='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                    </div>\
                                </div>");
                            }
                            else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });


                if($('#shape').val()=='1'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#id_cuentaDiv').show();
                    $('#id_cuenta').prop('disabled', true);
                    $('#id_usuarioDiv').show();
                    $('#id_dependenciaDiv').show();
                    $('#estadoDiv').show();
                    $('#contador_ingresoDiv').show();
                    $('#ultimo_ingresoDiv').show();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('id_cuenta'));     

                    $('#modalCrud').modal('show');

                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $("#btnAceptModalCrud").attr('accion','upd');
                    $("#btnAceptModalCrud").text('Guardar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#id_cuentaDiv').show();
                    $('#id_cuenta').prop('disabled', true);
                    $('#id_usuarioDiv').show();
                    $('#id_dependenciaDiv').show();
                    $('#estadoDiv').show();
                    $('#contador_ingresoDiv').hide();
                    $('#ultimo_ingresoDiv').hide();

                    $('#id_cuentaDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('id_cuenta'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#id_cuentaDiv').show();
                    $('#id_cuenta').prop('disabled', true);
                    $('#id_usuarioDiv').show();
                    $('#id_dependenciaDiv').show();
                    $('#estadoDiv').show();
                    $('#contador_ingresoDiv').hide();
                    $('#ultimo_ingresoDiv').hide();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('id_cuenta'));

                    $('#modalCrud').modal('show');
                })


                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($('#id_cuenta').val() != '' && $('#id_cuenta').val() != null) &&
                ($('#id_dependencia').val() != '' && $('#id_dependencia').val() != null) &&
                ($('#estado').val() != '' && $('#estado').val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updCuenta",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }


        if ($(this).attr('accion')=='del'){

            if (($('#id_cuenta').val() != '' && $('#id_cuenta').val() != null) &&
                ($('#id_cuenta').val() != '' && $('#id_cuenta').val() != null)){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./delCuenta",
                    data: frm,
                    success : function(data) {
                    
                        $('#modalCrud').modal('hide');
                        $('#dataTable').DataTable().ajax.reload();

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                       
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($('#id_usuario').val() != '' && $('#id_usuario').val() != null) &&
                ($('#id_dependencia').val() != '' && $('#id_dependencia').val() != null) &&
                ($('#estado').val() != '' && $('#estado').val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insCuenta",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }

        }
    });   
        
    //Consulta
    $("#btnAceptModalCrud").attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');    


    $('#mostrarModalInsMas').on('click', function(){

        $('#formInsMas')[0].reset();

        $('#tituloModalInsMas').text('Registro Masivo');
        $('#btnAceptModalInsMas').attr('accion','insMas');
        $('#btnAceptModalInsMas').text('Registrar');
        $('#btnCancelModalInsMas').show();

        $('#formInsMas *').prop('disabled', false);
        $('#btnAceptModalInsMas').prop('disabled', false);

        $('#formInsMas div.form-group').show();
        
        $('#modalInsMas').modal('show');
    });

    $('#btnAceptModalInsMas').on('click', function(){

        if ($(this).attr('accion')=='insMas'){
            
            if (($('#idPlano2').val() != '' && $('#idPlano2').val() != null) &&
                ($('#id_dependencia2').val() != '' && $('#id_dependencia2').val() != null)){

                $('#formInsMas *').prop('disabled', false);
                var frm = $("#formInsMas").serialize();
                $('#formInsMas *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insMasCuenta",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalInsMas').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + '<br>';
                            }   
                            messageBox(1,'Exito','Se registró '+jsonData.data.length+' registros con los siguientes Ids: <br> '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
    });


    //Modal VinMas
    $('#mostrarModalVinMas').on('click', function(){

        $('#formVinMas')[0].reset();

        $('#tituloModalVinMas').text('Registro Masivo');
        $('#btnAceptModalVinMas').attr('accion','vinMas');
        $('#btnAceptModalVinMas').text('Registrar');
        $('#btnCancelModalVinMas').show();

        $('#formVinMas *').prop('disabled', false);
        $('#btnAceptModalVinMas').prop('disabled', false);

        $('#formVinMas div.form-group').show();
        
        $('#modalVinMas').modal('show');
    
    });


    $('#btnAceptModalVinMas').on('click', function(){

        if ($(this).attr('accion')=='vinMas'){
            
            if (($('#idPlano3').val() != '' && $('#idPlano3').val() != null) &&
                ($('#id_dependencia3').val() != '' && $('#id_dependencia3').val() != null) &&
                ($('#id_perfil3').val() != '' && $('#id_perfil3').val() != null)){

                $('#formVinMas *').prop('disabled', false);
                var frm = $("#formVinMas").serialize();
                $('#formVinMas *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./vinMasPerfil",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalVinMas').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + '<br>';
                            }   
                            messageBox(1,'Exito','Se registró '+jsonData.data.length+' registros con los siguientes Ids: <br> '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
    });
        
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getCuentas',
        data: {
            "id_cuenta":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#id_cuenta').val(row.id);
                $('#id_usuario').val(row.id_usuario);
                $('#id_dependencia').val(row.id_dependencia);
                $('#estado').val(row.estado);
                $('#contador_ingreso').val(row.contador_ingreso);
                if(row.ultimo_ingreso != null){
                    $('#ultimo_ingreso').val(moment(row.ultimo_ingreso, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }
                
                
            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });

        $('#id_cuenta').val(row.id_cuenta);
        $('#id_usuario').val(row.id_usuario);
        $('#id_dependencia').val(row.id_dependencia);
        $('#estado').val(row.estado);
        $('#contador_ingreso').val(row.contador_ingreso);
        if(row.ultimo_ingreso != null){
            $('#ultimo_ingreso').val(moment(row.ultimo_ingreso, 'YYYY-MM-DD').format('DD/MM/YYYY'));
        }
        
    }
}

function limpiarModalCrud(){

    $('#formCrud')[0].reset();

}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
        $('#mostrarModalInsMas').show();
        $('#mostrarModalVinMas').show();
    }
 
    $('#estado').append($('<option></option>').val('').html('Seleccionar'));
    $('#estado').append($('<option></option>').val('00').html('00 - INACTIVO'));
    $('#estado').append($('<option></option>').val('01').html('01 - ACTIVO'));
    
    setInterval(timer, 10000);


    $('#idPlano2').change(function() {

        document.getElementById('idArray2Div').innerHTML = '';
        

        var file = this.files[0];
        var item = '';
        var reader = new FileReader();

        reader.onload = function(progressEvent){

            var arrayOne = new Array();
            var arrayOneRow = new Array();
            var mensajeError = '';
            var linea = 0;
            var lines = this.result.split('\n');
            var htmlArray= '';

            for(var line = 0; line < lines.length; line++){
                item = lines[line];
                item = item.trim();
                if (item != ''){

                    arrayOneRow = item.split("\t");

                    var idUsuario = arrayOneRow[0];                                    
                    
                    linea=line+1

                    if (idUsuario.length != 4 ){
                        mensajeError += '<br><br>Fila '+linea+', columna idUsuario: '+idUsuario+' debe tener 4 dígitos';
                    }
                    
                    if(mensajeError==''){
                        htmlArray += '<input type="hidden" name="idArray2['+line+']" value="'+arrayOneRow[0]+ '">';
                        //htmlArray += '<input type="hidden" name="idArray['+line+']" value="'+arrayOneRow[1]+ '">';
                        //htmlArray += '<input type="hidden" name="idArray['+line+']" value="'+arrayOneRow[2]+ '">';
                    }
                }
            }

            if (linea==0 || mensajeError!=''){
                if (arrayOne.length==0){
                    messageBox(2,'Error','El plano esta vacío.');
                }

                if(mensajeError!=''){
                    messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
                }
                arrayOne = new Array();
                $('#idPlano2').val('');

                document.getElementById('idArray2Div').innerHTML = '';
                
            }else{
                document.getElementById('idArray2Div').innerHTML = htmlArray;
            }
            

        };
        reader.readAsText(file);
    });

    $('#idPlano3').change(function() {

        document.getElementById('idArray3Div').innerHTML = '';
        

        var file = this.files[0];
        var item = '';
        var reader = new FileReader();

        reader.onload = function(progressEvent){

            var arrayTwo = new Array();
            var arrayTwoRow = new Array();
            var mensajeError = '';
            var linea = 0;
            var lines = this.result.split('\n');
            var htmlArray= '';

            for(var line = 0; line < lines.length; line++){
                item = lines[line];
                item = item.trim();
                if (item != ''){

                    arrayTwoRow = item.split("\t");

                    var idUsuario = arrayTwoRow[0];                                    
                    
                    linea=line+1

                    if (idUsuario.length != 4 ){
                        mensajeError += '<br><br>Fila '+linea+', columna idUsuario: '+idUsuario+' debe tener 4 dígitos';
                    }
                    
                    if(mensajeError==''){
                        htmlArray += '<input type="hidden" name="idArray3['+line+']" value="'+arrayTwoRow[0]+ '">';
                        //htmlArray += '<input type="hidden" name="idArray['+line+']" value="'+arrayTwoRow[1]+ '">';
                        //htmlArray += '<input type="hidden" name="idArray['+line+']" value="'+arrayTwoRow[2]+ '">';
                    }
                }
            }

            if (linea==0 || mensajeError!=''){
                if (arrayTwo.length==0){
                    messageBox(2,'Error','El plano esta vacío.');
                }

                if(mensajeError!=''){
                    messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
                }
                arrayTwo = new Array();
                $('#idPlano3').val('');

                document.getElementById('idArray3Div').innerHTML = '';
                
            }else{
                document.getElementById('idArray3Div').innerHTML = htmlArray;
            }
            

        };
        reader.readAsText(file);
    });


    $('#id_dependencia').append($('<option></option>').val('').html('SELECCIONAR'));    
    $('#id_dependencia2').append($('<option></option>').val('').html('SELECCIONAR'));
    $('#id_dependencia3').append($('<option></option>').val('').html('SELECCIONAR'));
    $.ajax({
        'url' : '../aplicacion/getDependencias',
        data: {},
        'type' : 'POST',
        'success' : function(data) {

            var jsonData = JSON.parse(data);

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#id_dependencia').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));
                $('#id_dependencia2').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));
                $('#id_dependencia3').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));
            }
        }
    });

    $('#id_perfil3').append($('<option></option>').val('').html('SELECCIONAR'));
    $.ajax({
        'url' : '../aplicacion/getPerfiles',
        data: {},
        'type' : 'POST',
        'success' : function(data) {

            var jsonData = JSON.parse(data);

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#id_perfil3').append($('<option></option>').val(row.id).html(row.id+' - '+row.descripcion));
            }
        }
    });

   

    $('#ultimo_ingreso').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#ultimo_ingresoContainer'
    });
    
    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            this.value = this.value.toUpperCase();
        });
    });





    
    
}




