
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();
                
        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#id_perfilDiv').show();
        $('#id_perfil').prop('disabled', false);
        $('#descripcionDiv').hide();
        $('#id_usuario_actualizaDiv').hide();
        $('#fecha_actualizaDiv').hide();
        $('#estadoDiv').show();

        $('#id_perfil').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#id_perfilDiv').show();
        $('#id_perfil').prop('disabled', false);
        $('#descripcionDiv').show();
        $('#id_usuario_actualizaDiv').hide();
        $('#fecha_actualizaDiv').hide();
        $('#estadoDiv').show();

        $('#id_perfil').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[4,"desc"],[0,"asc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getPerfiles",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"id"},                           
                        {"data":"descripcion"},
                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            //$(nTd).html("");
                            if (true){
                                $(nTd).html("<form target='_blank' method='post' action='./opcion'>\
                                <input type='hidden' name='idPerfilInd' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Opciones vinculadas al Perfil N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='"+oData.totalOpcionesVinculadas+"'></left>\
                                </form>");
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},
                        {"data":"estadoDesc"},

                        {"data":"idCuentaInd","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {

                            if ($('#shape').val()=='1'){
                                $(nTd).html("");
                            }else if ($('#shape').val()=='2'){
                                if (oData.idCuentaInd == null){
                                    //vincular
                                    $(nTd).html("");
                                }else{
                                    //desvincular
                                    $(nTd).html("VINCULADO");

                                    $(nTd).css('color', '#2ECC71');
                                    $(nTd).css('font-weight', 'bold');
                                    $('td', iRow).css('background-color', '#DBF7E7');
                                }
                                
                            }
                            else{                                
                                $(nTd).html("");
                            }

                            
                            
                        }},

                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {

                            if ($('#shape').val()=='1'){
                                $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                    <div class='btn-group'>\
                                        <button type='button' id_perfil='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        <button type='button' id_perfil='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                        <button type='button' id_perfil='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                    </div>\
                                </div>");
                            }else if ($('#shape').val()=='2'){
                                if (oData.idCuentaInd == null){
                                    //vincular
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' id_perfil='"+oData.id+"' class='mostrarModalVin btn btn-primary' data-toggle='tooltip' title='Vincular'>Vincular</button>\
                                        </div>\
                                    </div>");

                                }else{
                                    //desvincular
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' id_perfil='"+oData.id+"' class='mostrarModalDes btn btn-primary' data-toggle='tooltip' title='Desvincular'>Desvincular</button>\
                                        </div>\
                                    </div>");

                                }
                                
                            }
                            else{                                
                                $(nTd).html("");
                            }

                            
                            
                        }}                     
                    ],

                    "fnRowCallback": function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                        if ($('#shape').val()=='1'){
                            //$('td', nRow).css('background-color', '#FFFFFF');
                        }else if ($('#shape').val()=='2'){
                            if (aData.idCuentaInd == null){
                                //vincular
                                $('td', nRow).css('background-color', '#FFFFFF');

                            }else{
                                //desvincular
                                $('td', nRow).css('background-color', '#DBF7E7');
                            }
                        }
                        else{                                
                            $(nTd).html("");
                        }

                    }
                });
                
                if($('#shape').val()=='1'){
                    //Consulta General
                    table.column(2).visible(true);
                    table.column(3).visible(true);
                    table.column(4).visible(false);
                }
                if($('#shape').val()=='2'){
                    //Consulta de Cuotas por Cuenta
                    table.column(2).visible(false);
                    table.column(3).visible(false);
                    table.column(4).visible(true);
                }

                if($('#shape').val()=='1'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }

                

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#id_perfilDiv').show();
                    $('#id_perfil').prop('disabled', true);
                    $('#descripcionDiv').show();
                    $('#id_usuario_actualizaDiv').show();
                    $('#fecha_actualizaDiv').show();
                    $('#estadoDiv').show();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('id_perfil'));     

                    $('#modalCrud').modal('show');

                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $("#btnAceptModalCrud").attr('accion','upd');
                    $("#btnAceptModalCrud").text('Guardar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#id_perfilDiv').show();
                    $('#id_perfil').prop('disabled', true);
                    $('#descripcionDiv').show();
                    $('#id_usuario_actualizaDiv').hide();
                    $('#fecha_actualizaDiv').hide();
                    $('#estadoDiv').show();


                    $('#id_perfil').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('id_perfil'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#id_perfilDiv').show();
                    $('#id_perfil').prop('disabled', true);
                    $('#descripcionDiv').show();
                    $('#id_usuario_actualizaDiv').hide();
                    $('#fecha_actualizaDiv').hide();
                    $('#estadoDiv').show();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('id_perfil'));

                    $('#modalCrud').modal('show');
                })

                //Modal perfilOpcion (Vincular)
                $('#dataTable tbody').on('click','button.mostrarModalVin',function(){
                    
                    limpiarModalPerfilCuenta();

                    $('#tituloModalPerfilCuenta').text('Vincular');       
                    $('#btnAceptModalPerfilCuenta').attr('accion','vin');
                    $('#btnAceptModalPerfilCuenta').text('Vincular');
                    $('#btnCancelModalPerfilCuenta').show();

                    $('#formPerfilCuenta *').prop('disabled', true);
                    $('#btnAceptModalPerfilCuenta').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#id_cuenta3Div').show();
                    $('#id_cuenta3').prop('disabled', true);
                    $('#id_perfil3Div').show();
                    $('#id_perfil3').prop('disabled', true);
                    

                    $('#btnAceptModalPerfilCuenta').attr('class','btn btn-primary');

                    getDatosPerfilCuenta($(this).attr('id_perfil'),$('#idCuentaInd2').val());

                    $('#modalPerfilCuenta').modal('show');
                })

                //Modal perfilOpcion (Desvincular)
                $('#dataTable tbody').on('click','button.mostrarModalDes',function(){
                    
                    limpiarModalPerfilCuenta();

                    $('#tituloModalPerfilCuenta').text('Desvincular');       
                    $('#btnAceptModalPerfilCuenta').attr('accion','des');
                    $('#btnAceptModalPerfilCuenta').text('Desvincular');
                    $('#btnCancelModalPerfilCuenta').show();

                    $('#formPerfilCuenta *').prop('disabled', true);
                    $('#btnAceptModalPerfilCuenta').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#id_cuenta3Div').show();
                    $('#id_cuenta3').prop('disabled', true);
                    $('#id_perfil3Div').show();
                    $('#id_perfil3').prop('disabled', true);
                    

                    $('#btnAceptModalPerfilCuenta').attr('class','btn btn-danger');

                    getDatosPerfilCuenta($(this).attr('id_perfil'),$('#idCuentaInd2').val());

                    $('#modalPerfilCuenta').modal('show');
                })

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($('#id_perfil').val() != '' && $('#id_perfil').val() != null) &&
                ($('#descripcion').val() != '' && $('#descripcion').val() != null) &&
                ($('#estado').val() != '' && $('#estado').val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updPerfil",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }


        if ($(this).attr('accion')=='del'){

            if (($('#id_perfil').val() != '' && $('#id_perfil').val() != null) &&
                ($('#descripcion').val() != '' && $('#descripcion').val() != null)){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./delPerfil",
                    data: frm,
                    success : function(data) {
                    
                        $('#modalCrud').modal('hide');
                        $('#dataTable').DataTable().ajax.reload();

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                       
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($('#id_perfil').val() != '' && $('#id_perfil').val() != null) &&
                ($('#descripcion').val() != '' && $('#descripcion').val() != null) &&
                ($('#estado').val() != '' && $('#estado').val() != null)){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insPerfil",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }

        }
    });   

    //btnAceptModalCrud
    $("#btnAceptModalPerfilCuenta").on("click", function(){

        
        if ($(this).attr('accion')=='vin'){
           
            if (true){
                
                $('#formPerfilCuenta *').prop('disabled', false);
                var frm = $("#formPerfilCuenta").serialize();
                $('#formPerfilCuenta *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./vinPerfil",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalPerfilCuenta').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se vinculó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }


        if ($(this).attr('accion')=='des'){

            if (true){

                $('#formPerfilCuenta *').prop('disabled', false);
                var frm = $("#formPerfilCuenta").serialize();
                $('#formPerfilCuenta *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./desPerfil",
                    data: frm,
                    success : function(data) {
                    
                        $('#modalPerfilCuenta').modal('hide');
                        $('#dataTable').DataTable().ajax.reload();

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se desvinculó el registro con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                       
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }
        }

    });  
        
    //Consulta
    $("#btnAceptModalCrud").attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');


   
        
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getPerfiles',
        data: {
            "id_perfil":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#id_perfil').val(row.id);
                $('#descripcion').val(row.descripcion);
                $('#id_usuario_actualiza').val(row.id_usuario_actualiza);
                if(row.fecha_actualiza != null){
                    $('#fecha_actualiza').val(moment(row.fecha_actualiza, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }
                $('#estado').val(row.estado);
                
                
            }

        }
    });
}

function getDatosCuenta(id){
    $.ajax({
        method:"POST",
        url : './getCuentas',
        data: {
            "id_cuenta":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                //$('#idPerfilInd').val(row.id_perfil);
                $('#id_usuario2').val(row.id_usuario);
                $('#id_dependencia2').val(row.id_dependencia);
                $('#estado2').val(row.estado);
                

            }

        }
    });
}

function getDatosPerfilCuenta(id_perfil,id_cuenta){

   
    $('#id_cuenta3').val(id_cuenta);
    $('#id_perfil3').val(id_perfil);
    
                
                

}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });

        $('#id_perfil').val(row.id_perfil);
        $('#descripcion').val(row.descripcion);
        $('#id_usuario_actualiza').val(row.id_usuario_actualiza);
        if(row.fecha_actualiza != null){
            $('#fecha_actualiza').val(moment(row.fecha_actualiza, 'YYYY-MM-DD').format('DD/MM/YYYY'));
        }
        $('#estado').val(row.estado);       
        
    }
}

function limpiarModalCrud(){

    $('#formCrud')[0].reset();

}

function limpiarModalPerfilCuenta(){

    $('#formPerfilCuenta')[0].reset();

}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
        $('#cardDatosCuenta').hide();
    }
    if($('#shape').val()=='2'){
        //Consulta por Cuenta
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        $('#cardDatosCuenta').show();
    }

    

    $('#estado').append($('<option></option>').val('').html('Seleccionar'));
    $('#estado').append($('<option></option>').val('00').html('00 - INACTIVO'));
    $('#estado').append($('<option></option>').val('01').html('01 - ACTIVO'));

    $('#estado2').append($('<option></option>').val('').html('Seleccionar'));
    $('#estado2').append($('<option></option>').val('00').html('00 - INACTIVO'));
    $('#estado2').append($('<option></option>').val('01').html('01 - ACTIVO'));
    
    setInterval(timer, 10000);
    
    $('#id_dependencia2').append($('<option></option>').val('').html('Seleccionar'));    
    $.ajax({
        'url' : '../aplicacion/getDependencias',
        data: {},
        'type' : 'POST',
        'success' : function(data) {

            var jsonData = JSON.parse(data);

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#id_dependencia2').append($('<option></option>').val(row.id).html(row.id+' - '+row.desc_dependencia));    
            }
        }
    });

    $('#id_perfil3').append($('<option></option>').val('').html('Seleccionar'));    
    $.ajax({
        'url' : '../aplicacion/getPerfiles',
        data: {},
        'type' : 'POST',
        'success' : function(data) {

            var jsonData = JSON.parse(data);

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
                $('#id_perfil3').append($('<option></option>').val(row.id).html(row.id+' - '+row.descripcion));    
            }
        }
    });
    
    getDatosCuenta($("#idCuentaInd2").val());
    


    $('#fecha_actualiza').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecha_actualizaContainer'
    });
    
    

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });

    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            this.value = this.value.toUpperCase();
        });
    });





    
    
}




