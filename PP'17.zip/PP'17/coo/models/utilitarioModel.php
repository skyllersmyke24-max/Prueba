<?php 
class utilitarioModel extends Model{

	public function __construct(){
		parent::__construct();

	}

	public function addContador1($id_dependencia){
		$sql="DECLARE @contador varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '004001','$id_dependencia','6', @contador output ;
		select @contador as contador;";
		
		$result = $this->_db1->query($sql) or die($sql);

	}

	public function addContador2($id_dependencia){
		$sql="DECLARE @contador varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '004002','$id_dependencia','6', @contador output ;
		select @contador as contador;";
		
		$result = $this->_db1->query($sql) or die($sql);

	}

	public function addContador3($id_dependencia){
		$sql="DECLARE @contador varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '004003','$id_dependencia','6', @contador output ;
		select @contador as contador;";
		
		$result = $this->_db1->query($sql) or die($sql);

	}

	
	
}
?>