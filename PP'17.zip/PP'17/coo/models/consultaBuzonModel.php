<?php 

class consultaBuzonModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	
	
	/*public function getDatosBuzonSol($cod_usuario){

		$sql="select
			distinct
			substring(a.cod_usuario,1,11) as ruc,
			nom_usuario,
			case 
			when a.ind_activo='1' then '1 - ACTIVO'
			when a.ind_activo='0' then '0 - INACTIVO'
			end as estado
			from
			db_base_cc.prog.usuario a
			where
			substring(a.cod_usuario,1,11) = '$cod_usuario'

			";


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}*/


public function getdatosBuzon($cod_usuario,$idArrayRuc){

			$sql="select
			distinct
			substring(a.cod_usuario,1,11) as ruc,
			a.nom_usuario as razon_social
			from
			db_base_cc.prog.usuario a
			where substring(a.cod_usuario,1,11) is not null
			and ind_activo='1'";

		if ($cod_usuario=='*'){
			if (count($idArrayRuc)>0){

				$idSerie='';
				foreach($idArrayRuc as $item){
		 			$idSerie.="'".$item."',";
		 		}

				$idSerie = substr($idSerie, 0, strlen($idSerie) - 1 );
				$sql=$sql." and substring(a.cod_usuario,1,11) in ($idSerie)";
			}

		}else{
			if($cod_usuario<>''){
				$sql=$sql." and substring(a.cod_usuario,1,11) = '$cod_usuario'";
			}
		}

		$sql=$sql." order by substring(a.cod_usuario,1,11) desc";

		//echo $sql;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}




	
}
?>