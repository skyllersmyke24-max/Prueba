<?php 
class layoutModel extends Model{

	protected $id;
	protected $nombres;
	protected $apellido_paterno;
	protected $apellido_materno;
	protected $correo;
	protected $id_area;
	protected $id_modalidad_contrato;
	protected $estado;
	protected $perfil;
	protected $sexo;
	protected $username;
	protected $jefe;
	protected $foto;
	protected $id_dependencia;

	protected $accesosOpcionesArray;

	public function __construct(){
		parent::__construct();

		$this->setId('');
		$this->setNombres('');
		$this->setApellido_Paterno('');
		$this->setApellido_Materno('');
		$this->setCorreo('');
		$this->setId_Area('');
		$this->setId_Modalidad_Contrato('');
		$this->setEstado('');
		$this->setPerfil('');
		$this->setSexo('');
		$this->setUsername('');
		$this->setJefe('');
		$this->setFoto('');
		$this->setId_Dependencia('');
		$this->setId_Session('');	

		$this->setAccesosOpcionesArray(array());

	}

	public function instanciarUsuario($id,$id_dependencia){

		$id=strtoupper($id);

		$sql = "select 
		a.id, 
		a.nombres, 
		a.apellido_paterno, 
		a.apellido_materno, 
		lower(a.correo)  as correo, 
		a.id_area, 
		a.id_modalidad_contrato, 
		a.estado, 
		a.perfil, 
		a.sexo, 
		a.username, 
		a.jefe, 
		a.foto, 
		b.id_dependencia 
		from db_6E2000.dbo.a000_usuario a
		inner join db_6E2000.dbo.a000_cta b on b.id_usuario = a.id and b.id_dependencia='$id_dependencia'
		where 
		upper(a.id) = '$id'";

		$result=$this->_db1->query($sql) or die($sql);
		
		foreach ($result as $row) {
			$this->setId(trim($row['id']));
			$this->setNombres(trim($row['nombres']));
			$this->setApellido_Paterno(trim($row['apellido_paterno']));
			$this->setApellido_Materno(trim($row['apellido_materno']));
			$this->setCorreo(trim($row['correo']));
			$this->setId_Area(trim($row['id_area']));
			$this->setId_Modalidad_Contrato(trim($row['id_modalidad_contrato']));
			$this->setEstado(trim($row['estado']));
			$this->setPerfil(trim($row['perfil']));
			$this->setSexo(trim($row['sexo']));
			$this->setUsername(trim($row['username']));
			$this->setJefe(trim($row['jefe']));
			$this->setFoto($row['foto']);
			$this->setId_Dependencia(trim($row['id_dependencia']));

			
		}


		//setAccesosOpcion
		$id_cuenta = $this->getId().$this->getId_Dependencia();

		$sql = "SELECT 
				o.id_opcion,
				o.opcion
				FROM 
				db_6E2000.dbo.a000_opcion o
				inner join db_6E2000.dbo.a000_perfil_det pd on pd.id_opcion = o.id_opcion
				inner join db_6E2000.dbo.a000_perfil p on p.id_perfil = pd.id_perfil  and p.estado='01'
				inner join db_6E2000.dbo.a000_cta_per cp on cp.id_perfil = p.id_perfil
				inner join db_6E2000.dbo.a000_cta c on c.id_cuenta = cp.id_cuenta and c.estado='01' 
				and c.id_cuenta = '$id_cuenta'
				where
				o.estado = '01'";

		$result=$this->_db1->query($sql) or die($sql);
		

		$accesosOpcionesArray = array();

		while($row = $result->fetch()){
		    array_push($accesosOpcionesArray, $row['opcion']);
		}


		$this->setAccesosOpcionesArray($accesosOpcionesArray);


	}



	public function validarAccesoOpcion($opcion,$indRegistro){
		
		if(isset($_SESSION['id'])){

			$accesosOpcionesArray = $this->getAccesosOpcionesArray();
						
			if (in_array($opcion,$accesosOpcionesArray,true)){


				if($indRegistro== true and isset($_SESSION['id_session'])){


					$sql = "SELECT 
					o.id_opcion,
					o.opcion
					FROM 
					db_6E2000.dbo.a000_opcion o
					where
					o.opcion = '$opcion'
					and
					o.estado = '01'";

					$result=$this->_db1->query($sql) or die($sql);

					$id_opcion = '';

					while ($row = $result->fetch())  {
				    	$id_opcion = $row['id_opcion'];
					}

					$sql="	EXECUTE [db_6E2000].[dbo].[sp_a000_03_seccion_det] '".$_SESSION['id_session']."','$id_opcion', '".$this->getId_Dependencia()."';";


					$this->_db1->query($sql) or die($sql);
				}
				return true;
			}
			else{
				return false;				
			}
		}else{
			return false;
		}
	}


	public function diasTranscurridos($fecha){
			
		if(isset($_SESSION['id'])){

			$fechaAnterior = new DateTime($fecha); //Formato "2015-02-14" en string
			$fechaHoy = new DateTime("now");

			$diff = $fechaAnterior->diff($fechaHoy);

			if ($diff->days < 30){
				return true;
			}
			else{
				return false;				
			}
		}else{
			return false;
		}
	}


	public function getNotificaciones(){
		$sql = "select * from [db_6E2000].[dbo].[a000_not] a 
		inner join [db_6E2000].[dbo].[a000_not_u] b on a.id_notificacion = b.id_notificacion
		where b.id_usuario = '$this->id_usuario'";

		$result =$this->_db1->query($sql) or die($sql);

		return $result;
	}
	public function getTotalNotificaciones(){
		$sql = "select count(*) as total from [db_6E2000].[dbo].[a000_not] a 
		inner join [db_6E2000].[dbo].[a000_not_u] b on a.id_notificacion = b.id_notificacion
		where b.id_usuario = '$this->id_usuario'";
	
		$result =$this->_db1->query($sql) or die($sql);
		

		$total = 0;
        foreach ($result as $row) {
        	$total=$row['total'];
        }
        return $total;
	}


	public function setId($id){
		$this->id = $id;
	}
	public function getId(){
		return $this->id;
	}
	public function setNombres($nombres){
		$this->nombres = $nombres;
	}
	public function getNombres(){
		return $this->nombres;
	}
	public function setApellido_Paterno($apellido_paterno)
	{
		$this->apellido_paterno = $apellido_paterno;
	}
	public function getApellido_Paterno()
	{
		return $this->apellido_paterno;
	}
	public function setApellido_Materno($apellido_materno){
		$this->apellido_materno = $apellido_materno;
	}
	public function getApellido_Materno(){
		return $this->apellido_materno;
	}
	public function setCorreo($correo){
		$this->correo = $correo;
	}
	public function getCorreo(){
		return $this->correo;
	}
	public function setId_Area($id_area){
		$this->id_area = $id_area;
	}
	public function getId_Area(){
		return $this->id_area;
	}
	public function setId_Modalidad_Contrato($id_modalidad_contrato){
		$this->id_modalidad_contrato = $id_modalidad_contrato;
	}
	public function getId_Modalidad_Contrato(){
		return $this->id_modalidad_contrato;
	}
	public function setEstado($estado){
		$this->estado = $estado;
	}
	public function getEstado(){
		return $this->estado;
	}
	public function setPerfil($perfil){
		$this->perfil = $perfil;
	}
	public function getPerfil(){
		return $this->perfil;
	}
	public function setSexo($sexo){
		$this->sexo = $sexo;
	}
	public function getSexo(){
		return $this->sexo;
	}
	public function setUsername($username){
		$this->username = $username;
	}
	public function getUsername(){
		return $this->username;
	}
	public function setJefe($jefe){
		$this->jefe = $jefe;
	}
	public function getJefe(){
		return $this->jefe;
	}
	public function setFoto($foto){
		$this->foto = $foto;
	}
	public function getFoto(){
		return $this->foto;
	}
	public function setId_Dependencia($id_dependencia){
		$this->id_dependencia = $id_dependencia;
	}
	public function getId_Dependencia(){
		return $this->id_dependencia;
	}

	public function setId_Session($id_session){
		$this->id_session = $id_session;
	}

	public function getId_Session(){
		return $this->id_session;
	}

	public function setAccesosOpcionesArray($accesosOpcionesArray){
		$this->accesosOpcionesArray = $accesosOpcionesArray;
	}

	public function getAccesosOpcionesArray(){
		return $this->accesosOpcionesArray;
	}

	public function getNombresCompletos(){
		$nombres_completos = $this->getApellido_Paterno().' '.$this->getApellido_Materno().' '.$this->getNombres() ;
		return $nombres_completos;
	}

	
	
}
?>