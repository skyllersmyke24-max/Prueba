<?php 

class segimientoModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	


	
}
?>