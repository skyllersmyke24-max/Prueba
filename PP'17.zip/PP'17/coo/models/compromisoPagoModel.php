<?php 

class compromisoPagoModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	public function generarId(){
		$sql="DECLARE @idCompromiso varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '010001','002000','6', @idCompromiso output ;
		select @idCompromiso as idCompromiso;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function generarIdDet(){
		$sql="DECLARE @idCompromisoDet varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '010002','002000','6', @idCompromisoDet output ;
		select @idCompromisoDet as idCompromisoDet;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}
	
	public function getCompromisos($idCompromiso,$ruc,$rec,$rc,$rucTercero,$dniEncargadoTercero,$fecRegIni,$fecRegFin,$estado,$idUsuarioSession){

		$sql="SELECT 
		a.id,
		a.ruc,
		a.ruc+' - '+b.razon_social as rucDesc,
		a.rec,
		a.rc,
		a.numEmb,
		CONVERT(char(10), a.fecPrimerPago, 126) as fecPrimerPago,
		a.formaPagoPropuesto,
		case 
		when a.formaPagoPropuesto='01' then '01 - BOLETA PAGO 1662'
		when a.formaPagoPropuesto='02' then '02 - CHEQUE'
		when a.formaPagoPropuesto='03' then '03 - NPS'
		when a.formaPagoPropuesto='09' then '09 - OTROS'
		when a.formaPagoPropuesto='99' then '99 - NO ESPECIFICO'
		end as formaPagoPropuesto_desc,
		a.nroCuotas,
		a.mtoCuota,
		a.tipoFrecuencia,
		a.diaSemana,
		case 
		when a.diaSemana = 'LU' then 'LUNES'
		when a.diaSemana = 'MA' then 'MARTES'
		when a.diaSemana = 'MI' then 'MIERCOLES'
		when a.diaSemana = 'JU' then 'JUEVES'
		when a.diaSemana = 'VI' then 'VIERNES'
		end as diaSemanaDesc,
		a.diaMes,
		a.montoTotalInformado,
		a.dniEncargadoTercero,
		a.nombreEncargadoTercero,
		a.observacion,
		a.fecReg,
		a.usuReg,
		a.fecMod,
		a.usuMod,
		a.estado,
		a.codTercero,
		b.num_ruc_ter as rucTercero,
		b.num_ruc_ter+' - '+ b.nom_ter as rucTerceroDesc,
		b.nom_ter as razonSocialTercero,
		case 
		when a.estado='01' then '01 - ACTIVO'
		end as estado_desc,
		b.num_ruc_ter,
		b.nom_ter

		FROM db_6E2000.dbo.a010_compromisoPago a
		left join db_cobranza.intr.embargos_terceros b on b.num_rc = a.rc and b.num_ter = a.codTercero
		WHERE a.id is not null
		and
		a.estado<>'DE' ";

		if ($idCompromiso != '' ){
			$sql=$sql." and a.id = '$idCompromiso'";
		}
		if ($ruc != '' ){
			$sql=$sql." and a.ruc = '$ruc'";
		}
		if ($rec != '' ){
			$sql=$sql." and a.rec = '$rec'";
		}
		if ($rc != '' ){
			$sql=$sql." and a.rc = '$rc'";
		}
		if ($rucTercero != '' ){
			$sql=$sql." and b.num_ruc_ter = '$rucTercero'";
		}
		if ($dniEncargadoTercero != '' ){
			$sql=$sql." and a.dniEncargadoTercero = '$dniEncargadoTercero'";
		}		
		if (strtotime(str_replace('/', '-', $fecRegIni)) and strtotime(str_replace('/', '-', $fecRegFin))){

			$fecRegIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegIni)));
			$fecRegFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegFin)));

			$sql=$sql." and a.fecReg between '".$fecRegIni." 00:00:00' and '".$fecRegFin." 23:59:59'";
		}
		if ($idUsuarioSession != '' ){
			$sql=$sql." and a.usuReg = '$idUsuarioSession'";
		}
		
		$sql=$sql." order by a.id desc";

		


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}
	
	public function getCuotas($idCompromiso,$rucTercero,$fechaVencimientoCuotaIni,$fechaVencimientoCuotaFin,$mtoCuotaIni,$mtoCuotaFin,$saldoMtoEmbIni,$saldoMtoEmbFin){

		$sql="select  
		c.num_ruc_ter as rucTercero,
		c.num_ruc_ter+' - '+ c.nom_ter as rucTerceroDesc,
		c.nom_ter as razonSocialTercero,
		b.idCompromiso,
		row_number() over(order by b.fechaVencimientoCuota asc) as nroCuota,
		b.fechaVencimientoCuota,
		b.mtoCuota,
		b.saldoMtoEmb,
		case
		when b.mtoPago is null then 0
		else b.mtoPago
		end as mtoPago,
		case
		when b.mtoPago is null then 'Pendiente'
		when b.mtoPago is not null and b.mtoPago >= cast((b.mtoCuota *.95) as bigint) then 'Pagado'
		else 'Pendiente'
		end as estadoPago,
		b.estado,
		b.usuReg,
		b.fecReg,
		b.usuMod,
		b.fecMod
		from 
		db_6E2000.dbo.a010_compromisoPago a
		inner join db_6E2000.dbo.a010_compromisoPagoDet b on b.idCompromiso = a.id
		left join db_cobranza.intr.embargos_terceros c on c.num_rc = a.rc and c.num_ter = a.codTercero
		WHERE b.id is not null
		and
		a.estado<>'DE'";

		if ($idCompromiso != '' ){
			$sql=$sql." and b.idCompromiso = '$idCompromiso'";
		}
		if ($rucTercero != '' ){
			$sql=$sql." and c.num_ruc_ter = '$rucTercero'";
		}
		if (strtotime(str_replace('/', '-', $fechaVencimientoCuotaIni)) and strtotime(str_replace('/', '-', $fechaVencimientoCuotaFin))){

			$fechaVencimientoCuotaIni=date('Y-m-d',strtotime(str_replace('/', '-', $fechaVencimientoCuotaIni)));
			$fechaVencimientoCuotaFin=date('Y-m-d',strtotime(str_replace('/', '-', $fechaVencimientoCuotaFin)));

			$sql=$sql." and a.fechaVencimientoCuota between '".$fechaVencimientoCuotaIni." 00:00:00' and '".$fechaVencimientoCuotaFin." 23:59:59'";
		}

		if ($mtoCuotaIni != '' and $mtoCuotaFin != ''){
			$sql=$sql." and b.mtoCuota between '$mtoCuotaIni' and '$mtoCuotaFin'";
		}

		if ($saldoMtoEmbIni != '' and $saldoMtoEmbFin != ''){
			$sql=$sql." and b.saldoMtoEmb between '$saldoMtoEmbIni' and '$saldoMtoEmbFin'";
		}
	
		$sql=$sql." order by b.fechaVencimientoCuota asc";

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}


	public function insCompromiso($idCompromiso,$ruc,$rec,$rc,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuReg,$estado,$codTercero){

		$fecPrimerPago = date('Y-m-d',strtotime(str_replace('/', '-', $fecPrimerPago)));

		$sql="INSERT INTO db_6E2000.dbo.a010_compromisoPago(id,ruc,rec,rc,fecPrimerPago,formaPagoPropuesto,nroCuotas,mtoCuota,tipoFrecuencia,diaSemana,diaMes,montoTotalInformado,dniEncargadoTercero,nombreEncargadoTercero,observacion,usuReg,fecReg,estado,codTercero) VALUES('$idCompromiso','$ruc','$rec','$rc','$fecPrimerPago','$formaPagoPropuesto','$nroCuotas','$mtoCuota','$tipoFrecuencia','$diaSemana','$diaMes','$montoTotalInformado','$dniEncargadoTercero','$nombreEncargadoTercero','$observacion','$usuReg',getdate(),'$estado','$codTercero');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg){


		$sql="INSERT INTO db_6E2000.dbo.a010_compromisoPagoDet(id,idCompromiso,fechaVencimientoCuota,mtoCuota,saldoMtoEmb,estado,usuReg,fecReg) VALUES('$idCompromisoDet','$idCompromiso','$fechaVencimientoCuota','$mtoCuota','$saldoMtoEmb','$estado','$usuReg',getdate());";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updCompromiso($idCompromiso,$rc,$rec,$ruc,$codTercero,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$estado,$usuMod){

		$fecPrimerPago = date('Y-m-d',strtotime(str_replace('/', '-', $fecPrimerPago)));
		
		$sql="UPDATE db_6E2000.dbo.a010_compromisoPago 
		SET 
		rc = '$rc',
		rec = '$rec', 
		ruc = '$ruc',
		codTercero = '$codTercero', 		
		fecPrimerPago = '$fecPrimerPago', 
		formaPagoPropuesto = '$formaPagoPropuesto', 
		nroCuotas = '$nroCuotas',
		mtoCuota = '$mtoCuota',
		tipoFrecuencia = '$tipoFrecuencia',
		diaSemana = '$diaSemana',
		diaMes = '$diaMes',
		montoTotalInformado = '$montoTotalInformado',
		dniEncargadoTercero = '$dniEncargadoTercero',
		nombreEncargadoTercero = '$nombreEncargadoTercero',
		observacion = '$observacion',
		fecMod = getdate(),
		usuMod = '$usuMod'
		WHERE 
		id = '$idCompromiso' ";
		
		

		$this->_db1->query($sql) or die($sql);
		
	}



	public function delCompromiso($idCompromiso){
		//$sql="delete from db_6E2000.dbo.a010_compromisoPago where id = '$idCompromiso'";


		$sql="UPDATE db_6E2000.dbo.a010_compromisoPago 
		SET 
		estado='DE'
		WHERE 
		id = '$idCompromiso' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delCompromisoDet($idCompromiso){
		//$sql="delete from db_6E2000.dbo.a010_compromisoPago where id = '$idCompromiso'";


		$sql="UPDATE db_6E2000.dbo.a010_compromisoPagoDet 
		SET 
		estado='DE'
		WHERE 
		idCompromiso = '$idCompromiso' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function getCantCompromisosPorTercero(){

		$sql="select
		c.num_ruc_ter as rucTercero,
		c.num_ruc_ter+' - '+ c.nom_ter as rucTerceroDesc,
		count(distinct a.id) as cantCompromisos,
		count(distinct b.id) as cantCuotas, 
		sum(a.montoTotalInformado) as mtoTotalInformado
		from 
		db_6E2000.dbo.a010_compromisoPago a
		inner join db_6E2000.dbo.a010_compromisoPagoDet b on b.idCompromiso = a.id
		left join db_cobranza.intr.embargos_terceros c on c.num_rc = a.rc and c.num_ter = a.codTercero
		where 
		a.estado<>'DE'
		group by
		c.num_ruc_ter,
		c.num_ruc_ter+' - '+ c.nom_ter";
			
	


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function getDatosRC($rc){
		
		$sql="select 
		top 1 
		a.num_rc as rc, 
		a.num_ruc as ruc, 
		a.num_exp_rc as rec, 
		a.razon_social as razonSocial
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'";
				
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	public function getListaTerceros($rc){
		
		$sql="select 
		a.num_ter as codTercero,
		a.num_ruc_ter as rucTercero,
		a.nom_ter as nombreTercero
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'
		order by a.nom_ter";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	public function getDatosGrafico1($idUsuario,$anho,$mes){
		$sql="select 
		cast(a.fecha as date) as dia,

		(select 
		case
		when sum(b.horasOcupadas) is not null then sum(b.horasOcupadas)
		else 0
		end  
		from dpo2.dbo.actividadPersonal b where b.fecha = a.fecha and b.idUsuario='$idUsuario' and b.estado='04') as horasOcupadas

		
		from
		db_sunat.dbo.a000_fecha a
		

		where
		a.mes = '$mes'
		and
		a.anho = '$anho'
		and
		a.dia_sem in ('2','3','4','5','6') and a.ind_feriado='0' 

		order by cast(a.fecha as date)";
		//echo($sql);

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function getDatosGrafico2($idArea,$anho,$mes){
		$sql="select 
		cast(a.fecha as date) as dia,

		(select 
		case
		when sum(b.horasOcupadas) is not null then sum(b.horasOcupadas)
		else 0
		end  
		from dpo2.dbo.actividadPersonal b where b.fecha = a.fecha and b.idArea like '$idArea' and b.estado='04') as horasOcupadas

		
		from
		db_sunat.dbo.a000_fecha a
		

		where
		a.mes = '$mes'
		and
		a.anho = '$anho'
		and
		a.dia_sem in ('2','3','4','5','6') and a.ind_feriado='0' 

		order by cast(a.fecha as date)";
		//echo($sql);

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}


	public function getOfCombo($id_desc,$id_usuario){
		//Ruc o Razón

		$sql = "


		select 
		c.num_ord_fis as id, 
		c.num_ord_fis + ' - ' + c.ddp_nombre as descripcion

		from 
		dpo.dbo.cof c

		where
		c.num_ord_fis in (select r.num_ord_fis from dpo.dbo.rec_aud r where r.cod_reg_rec ='$id_usuario' and r.flg_est_rec='1')
		
		and
		
		(c.num_ord_fis like'$id_desc%' 
		or 
		c.ddp_nombre like '%$id_desc%' )

		 ";


		$result =$this->_db2->query($sql) or die($sql);
		return $result;
	}

	
}
?>