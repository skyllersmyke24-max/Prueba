<?php 
class usuarioController extends Controller{
	public function __construct(){
		parent::__construct();
	}

	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('USUARIO/CONSULTA',true)){

				$id = '';
				$idArray = array();
				$nombres = '';
				$apellido_paterno = '';
				$apellido_materno = '';
				$correo = '';
				$fecha_nacimiento = '';
				$id_area = '';
				$id_modalidad_contrato = '';
				$id_dependencia = '';
				$estado = '';
				$username = '';
				$jefe = '';
				$title = 'Consulta General de Usuarios';
			    $shape = '1';

			    if(isset($_POST['id'])){
					$id = trim($_POST['id']);
				}
				if(isset($_POST['idArray'])){
					$idArray = $_POST['idArray'];
				}
				if(isset($_POST['nombres'])){
					$nombres = trim($_POST['nombres']);
				}
				if(isset($_POST['apellido_paterno'])){
					$apellido_paterno = trim($_POST['apellido_paterno']);
				}
				if(isset($_POST['apellido_materno'])){
					$apellido_materno = trim($_POST['apellido_materno']);
				}
				if(isset($_POST['correo'])){
					$correo = trim($_POST['correo']);
				}
				if(isset($_POST['fecha_nacimiento'])){
					$fecha_nacimiento = trim($_POST['fecha_nacimiento']);
				}
				if(isset($_POST['id_area'])){
					$id_area = trim($_POST['id_area']);
				}
				if(isset($_POST['id_modalidad_contrato'])){
					$id_modalidad_contrato = trim($_POST['id_modalidad_contrato']);
				}
				if(isset($_POST['id_dependencia'])){
					$id_dependencia = trim($_POST['id_dependencia']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}	
				if(isset($_POST['username'])){
					$username = trim($_POST['username']);
				}		
				if(isset($_POST['jefe'])){
					$jefe = trim($_POST['jefe']);
				}	
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}


				$this->_view->id = $id;
				$this->_view->idArray = $idArray;
				$this->_view->nombres = $nombres;
				$this->_view->apellido_paterno = $apellido_paterno;
				$this->_view->apellido_materno = $apellido_materno;
				$this->_view->correo = $correo;
				$this->_view->fecha_nacimiento = $fecha_nacimiento;
				$this->_view->id_area = $id_area;
				$this->_view->id_modalidad_contrato = $id_modalidad_contrato;
				$this->_view->id_dependencia = $id_dependencia;
				$this->_view->estado = $estado;
				$this->_view->username = $username;
				$this->_view->jefe = $jefe;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('consulta'));
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function registro(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;
			
			if ($objLayout->validarAccesoOpcion('USUARIO/REGISTRO',true)){

				$_POST['shape']='2';
				$_POST['title']='Registro de Usuarios';

				$this->consulta();
			}
			else{
				$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
				$this->_view->tipoError = '2';
				$this->_view->renderizar('../index/login',true);
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function profile(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;
			
			// $objUsuario = $this->loadModel('usuario');
			// $this->_view->usuario = $objUsuario;
			
			$this->_view->setJs(array('profile')); //carga un js en la vista
			$this->_view->renderizar('profile');

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getUsuarios(){

		if(isset($_SESSION['id'])){
			
			$id = '';
			$idArray = array();
			$nombres = '';
			$apellido_paterno = '';
			$apellido_materno = '';
			$correo = '';
			$fecha_nacimiento = '';
			$id_area = '';
			$id_modalidad_contrato = '';
			$id_dependencia = '';
			$estado = '';
			$username = '';
			$jefe = '';

		   	if(isset($_POST['id'])){
				$id = trim($_POST['id']);
			}
			if(isset($_POST['idArray'])){
				$idArray = $_POST['idArray'];
			}
			if(isset($_POST['nombres'])){
				$nombres = trim($_POST['nombres']);
			}
			if(isset($_POST['apellido_paterno'])){
				$apellido_paterno = trim($_POST['apellido_paterno']);
			}
			if(isset($_POST['apellido_materno'])){
				$apellido_materno = trim($_POST['apellido_materno']);
			}
			if(isset($_POST['correo'])){
				$correo = trim($_POST['correo']);
			}
			if(isset($_POST['fecha_nacimiento'])){
				$fecha_nacimiento = trim($_POST['fecha_nacimiento']);
			}
			if(isset($_POST['id_area'])){
				$id_area = trim($_POST['id_area']);
			}
			if(isset($_POST['id_modalidad_contrato'])){
				$id_modalidad_contrato = trim($_POST['id_modalidad_contrato']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['username'])){
				$username = trim($_POST['username']);
			}
			if(isset($_POST['jefe'])){
				$jefe = trim($_POST['jefe']);
			}


			$objModel = $this->loadModel('usuario');
			$result = $objModel->getUsuarios($id,$idArray,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$jefe);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function insUsuario(){

		if(isset($_SESSION['id'])){

			$id = '';
			$nombres = '';
			$apellido_paterno = '';
			$apellido_materno = '';
			$correo = '';
			$fecha_nacimiento = '';
			$id_area = '';
			$id_modalidad_contrato = '';
			$id_dependencia = '';
			$estado = '';
			$username = '';
			$sexo = '';
			$jefe = '';

		
			if(isset($_POST['id'])){
				$id = trim($_POST['id']);
			}
			if(isset($_POST['nombres'])){
				$nombres = trim($_POST['nombres']);
			}
			if(isset($_POST['apellido_paterno'])){
				$apellido_paterno = trim($_POST['apellido_paterno']);
			}
			if(isset($_POST['apellido_materno'])){
				$apellido_materno = trim($_POST['apellido_materno']);
			}
			if(isset($_POST['correo'])){
				$correo = trim($_POST['correo']);
			}
			if(isset($_POST['fecha_nacimiento'])){
				$fecha_nacimiento = trim($_POST['fecha_nacimiento']);
			}
			if(isset($_POST['id_area'])){
				$id_area = trim($_POST['id_area']);
			}
			if(isset($_POST['id_modalidad_contrato'])){
				$id_modalidad_contrato = trim($_POST['id_modalidad_contrato']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['username'])){
				$username = trim($_POST['username']);
			}
			if(isset($_POST['sexo'])){
				$sexo = trim($_POST['sexo']);
			}
			if(isset($_POST['jefe'])){
				$jefe = trim($_POST['jefe']);
			}


			$objModel = $this->loadModel('usuario');
			$objModel->insUsuario($id,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$sexo,$jefe);

			
			$_POST = array();
			$_POST['id']=$id;
			$this->getUsuarios();
			

		}
	}

	public function updUsuario(){

		if(isset($_SESSION['id'])){

			$id = '';
			$nombres = '';
			$apellido_paterno = '';
			$apellido_materno = '';
			$correo = '';
			$fecha_nacimiento = '';
			$id_area = '';
			$id_modalidad_contrato = '';
			$id_dependencia = '';
			$estado = '';
			$username = '';
			$sexo = '';
			$jefe = '';

		
			if(isset($_POST['id'])){
				$id = trim($_POST['id']);
			}
			if(isset($_POST['nombres'])){
				$nombres = trim($_POST['nombres']);
			}
			if(isset($_POST['apellido_paterno'])){
				$apellido_paterno = trim($_POST['apellido_paterno']);
			}
			if(isset($_POST['apellido_materno'])){
				$apellido_materno = trim($_POST['apellido_materno']);
			}
			if(isset($_POST['correo'])){
				$correo = trim($_POST['correo']);
			}
			if(isset($_POST['fecha_nacimiento'])){
				$fecha_nacimiento = trim($_POST['fecha_nacimiento']);
			}
			if(isset($_POST['id_area'])){
				$id_area = trim($_POST['id_area']);
			}
			if(isset($_POST['id_modalidad_contrato'])){
				$id_modalidad_contrato = trim($_POST['id_modalidad_contrato']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['username'])){
				$username = trim($_POST['username']);
			}
			if(isset($_POST['sexo'])){
				$sexo = trim($_POST['sexo']);
			}
			if(isset($_POST['jefe'])){
				$jefe = trim($_POST['jefe']);
			}


			$objModel = $this->loadModel('usuario');
			$objModel->updUsuario($id,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$sexo,$jefe);

			
			$_POST = array();
			$_POST['id']=$id;
			$this->getUsuarios();
			

		}
	}

	public function delUsuario(){

		if(isset($_SESSION['id'])){

			$id = '';
		
			if(isset($_POST['id'])){
				$id = $_POST['id'];
			}

			$objModel = $this->loadModel('usuario');
			$objModel->delUsuario($id);


			$_POST = array();
			$_POST['id']=$id;
			$_POST['estado']='00';
			$this->getUsuarios();


		}
	}



	
}

?>