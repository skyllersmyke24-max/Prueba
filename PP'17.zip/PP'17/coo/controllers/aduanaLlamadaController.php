<?php 

class aduanaLlamadaController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}


	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('ADUANALLAMADA/CONSULTA',true)){

			    $idAduanaLlamada = '';
				$tipoDocIdentidad = '';
				$docIdentidad = '';
				$fecLlamada = '';
				$apellidoPaterno = '';
				$apellidoMaterno = '';
				$nombres = '';
				$cargo = '';
				$expCoactivo = '';
				$usuReg = '';				
				$fecRegIni = '';
				$fecRegFin = '';
				$estado = '';
			    $title = 'Consulta de Llamadas (Deuda Aduanas - Sigad)';
			    $shape = '1';
			   	
			   	if(isset($_POST['idAduanaLlamada'])){	
					$idAduanaLlamada = trim($_POST['idAduanaLlamada']);
				}
			   	if(isset($_POST['tipoDocIdentidad'])){	
					$tipoDocIdentidad = trim($_POST['tipoDocIdentidad']);
				}
			   	if(isset($_POST['docIdentidad'])){	
					$docIdentidad = trim($_POST['docIdentidad']);
				}
				if(isset($_POST['fecLlamada'])){	
					$fecLlamada = trim($_POST['fecLlamada']);
				}
			   	if(isset($_POST['apellidoPaterno'])){	
					$apellidoPaterno = trim($_POST['apellidoPaterno']);
				}
			   	if(isset($_POST['apellidoMaterno'])){	
					$apellidoMaterno = trim($_POST['apellidoMaterno']);
				}
			   	if(isset($_POST['nombres'])){	
					$nombres = trim($_POST['nombres']);
				}
			   	if(isset($_POST['cargo'])){	
					$cargo = trim($_POST['cargo']);
				}
			   	if(isset($_POST['expCoactivo'])){	
					$expCoactivo = trim($_POST['expCoactivo']);
				}
			   	if(isset($_POST['usuReg'])){	
					$usuReg = trim($_POST['usuReg']);
				}
				if(isset($_POST['fecRegIni'])){	
					$fecRegIni = trim($_POST['fecRegIni']);
				}
				if(isset($_POST['fecRegFin'])){	
					$fecRegFin = trim($_POST['fecRegFin']);
				}
				if(isset($_POST['estado'])){	
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				

				$this->_view->idAduanaLlamada = $idAduanaLlamada;
				$this->_view->tipoDocIdentidad = $tipoDocIdentidad;
				$this->_view->docIdentidad = $docIdentidad;
				$this->_view->fecLlamada = $fecLlamada;
				$this->_view->apellidoPaterno = $apellidoPaterno;
				$this->_view->apellidoMaterno = $apellidoMaterno;
				$this->_view->nombres = $nombres;
				$this->_view->cargo = $cargo;
				$this->_view->expCoactivo = $expCoactivo;
				$this->_view->usuReg = $usuReg;
				$this->_view->fecRegIni = $fecRegIni;
				$this->_view->fecRegFin = $fecRegFin;
				$this->_view->estado = $estado;


				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	

	

	public function generarId(){

		$idAduanaLLamada = '';

		$objModel = $this->loadModel('aduanaLlamada');
		$result = $objModel->generarId();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idAduanaLLamada=$row['idAduanaLLamada'];
				}
		}
		return $idAduanaLLamada;
	}

	
	public function getAduanasLlamadas(){

		if(isset($_SESSION['id'])){
			
			$idAduanaLlamada  = '';
			$idAduanaLlamadaArray = array();
			$fecLlamadaIni = '';
			$fecLlamadaFin = '';
			$tipoDocIdentidad = '';
			$docIdentidad = '';
			$apellidoPaterno = '';
			$apellidoMaterno = '';
			$nombres = '';
			$resultadoLlamada = '';
			$resultadoNegociacion = '';
			$tipoLLamada = '';
			$expCoactivo = '';
			$respuesta = '';
			$usuReg = '';
			$fecRegIni = '';
			$fecRegFin = '';
			$usuMod = '';
			$fecMod = '';
			$estado = '';
		    $estadoArray = array();

		   	if(isset($_POST['idAduanaLlamada'])){	
				$idAduanaLlamada = trim($_POST['idAduanaLlamada']);
			}
			if(isset($_POST['idAduanaLlamadaArray'])){	
				$idAduanaLlamadaArray = $_POST['idAduanaLlamadaArray'];
			}			
			if(isset($_POST['fecLlamadaIni'])){	
				$fecLlamadaIni = trim($_POST['fecLlamadaIni']);
			}
			if(isset($_POST['fecLlamadaFin'])){	
				$fecLlamadaFin = trim($_POST['fecLlamadaFin']);
			}

		   	if(isset($_POST['tipoDocIdentidad'])){	
				$tipoDocIdentidad = trim($_POST['tipoDocIdentidad']);
			}
		   	if(isset($_POST['docIdentidad'])){	
				$docIdentidad = trim($_POST['docIdentidad']);
			}
		   	if(isset($_POST['apellidoPaterno'])){	
				$apellidoPaterno = trim($_POST['apellidoPaterno']);
			}
		   	if(isset($_POST['apellidoMaterno'])){	
				$apellidoMaterno = trim($_POST['apellidoMaterno']);
			}
		   	if(isset($_POST['nombres'])){	
				$nombres = trim($_POST['nombres']);
			}		   

		   	if(isset($_POST['expCoactivo'])){	
				$expCoactivo = trim($_POST['expCoactivo']);
			}

		   	if(isset($_POST['usuReg'])){	
				$usuReg = trim($_POST['usuReg']);
			}

			if(isset($_POST['fecRegIni'])){	
				$fecRegIni = trim($_POST['fecRegIni']);
			}

			if(isset($_POST['fecRegFin'])){	
				$fecRegFin = trim($_POST['fecRegFin']);
			}

			if(isset($_POST['estado'])){	
				$estado = trim($_POST['estado']);
			}

			if(isset($_POST['estadoArray'])){
				$estadoArray = $_POST['estadoArray'];
			}
			
			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
				array_push($estadoArray, '02');
			}

			$objModel = $this->loadModel('aduanaLlamada');
			$result = $objModel->getAduanasLlamadas($idAduanaLlamada,$idAduanaLlamadaArray,$fecLlamadaIni,$fecLlamadaFin,$tipoDocIdentidad,$docIdentidad,$apellidoPaterno,$apellidoMaterno,$nombres,$expCoactivo,$usuReg,$fecRegIni,$fecRegFin,$estado,$estadoArray);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}
	
	public function insAduanaLlamada(){

		if(isset($_SESSION['id'])){
						
			$idAduanaLlamada = $this->generarId();
			$telefono = '';	
			$fecLlamada = '';
			$tipoDocIdentidad = '';
			$docIdentidad = '';
			$razonSocial = '';
			$apellidoPaterno = '';
			$apellidoMaterno = '';
			$nombres = '';
			$cargo = '';
			$contribuyenteContactado = '';
			$resultadoLlamada = '';
			$resultadoNegociacion = '';
			$tipoLLamada = '';
			$observacion = '';
			$expCoactivo = '';
			$rcEmbargo = '';
			$respuesta = '';
			$fecEstimadaEntrega = '';
			$usuReg = $_SESSION['id'];
			$estado = '01';



			if(isset($_POST['telefono'])){	
				$telefono = trim($_POST['telefono']);
			}
			if(isset($_POST['fecLlamada'])){	
				$fecLlamada = trim($_POST['fecLlamada']);
			}
		   	if(isset($_POST['tipoDocIdentidad'])){	
				$tipoDocIdentidad = trim($_POST['tipoDocIdentidad']);
			}
		   	if(isset($_POST['docIdentidad'])){	
				$docIdentidad = trim($_POST['docIdentidad']);
			}
			if(isset($_POST['razonSocial'])){	
				$razonSocial = trim($_POST['razonSocial']);
			}
		   	if(isset($_POST['apellidoPaterno'])){	
				$apellidoPaterno = trim($_POST['apellidoPaterno']);
			}
		   	if(isset($_POST['apellidoMaterno'])){	
				$apellidoMaterno = trim($_POST['apellidoMaterno']);
			}
		   	if(isset($_POST['nombres'])){	
				$nombres = trim($_POST['nombres']);
			}
		   	if(isset($_POST['cargo'])){	
				$cargo = trim($_POST['cargo']);
			}
		   	if(isset($_POST['contribuyenteContactado'])){	
				$contribuyenteContactado = trim($_POST['contribuyenteContactado']);
			}
		   	if(isset($_POST['resultadoLlamada'])){	
				$resultadoLlamada = trim($_POST['resultadoLlamada']);
			}
		   	if(isset($_POST['resultadoNegociacion'])){	
				$resultadoNegociacion = trim($_POST['resultadoNegociacion']);
			}
		   	if(isset($_POST['tipoLLamada'])){	
				$tipoLLamada = trim($_POST['tipoLLamada']);
			}
		   	if(isset($_POST['observacion'])){	
				$observacion = trim($_POST['observacion']);
			}
		   	if(isset($_POST['expCoactivo'])){	
				$expCoactivo = trim($_POST['expCoactivo']);
			}
		   	if(isset($_POST['rcEmbargo'])){	
				$rcEmbargo = trim($_POST['rcEmbargo']);
			}
		   	if(isset($_POST['respuesta'])){	
				$respuesta = trim($_POST['respuesta']);
			}
		   	if(isset($_POST['fecEstimadaEntrega'])){	
				$fecEstimadaEntrega = trim($_POST['fecEstimadaEntrega']);
			}
		   			


			$objModel = $this->loadModel('aduanaLlamada');
			$objModel->insAduanaLlamada($idAduanaLlamada,$telefono,$fecLlamada,$tipoDocIdentidad,$docIdentidad,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuReg,$estado);


			
			$_POST = array();
			$_POST['idAduanaLlamada']=$idAduanaLlamada;
			$this->getAduanasLlamadas();

		}
	}
	 
	public function updAduanaLlamada(){

		if(isset($_SESSION['id'])){

			
			$idAduanaLlamada = '';
			$telefono = '';
			$razonSocial = '';
			$fecLlamada = '';
			$apellidoPaterno = '';
			$apellidoMaterno = '';
			$nombres = '';
			$cargo = '';
			$contribuyenteContactado = '';
			$resultadoLlamada = '';
			$resultadoNegociacion = '';
			$tipoLLamada = '';
			$observacion = '';
			$expCoactivo = '';
			$rcEmbargo = '';
			$respuesta = '';
			$fecEstimadaEntrega = '';
			$usuMod = $_SESSION['id'];
			$estado = '';

		
			if(isset($_POST['idAduanaLlamada'])){	
				$idAduanaLlamada = trim($_POST['idAduanaLlamada']);
			}
			if(isset($_POST['telefono'])){	
				$telefono = trim($_POST['telefono']);
			}			
			if(isset($_POST['razonSocial'])){	
				$razonSocial = trim($_POST['razonSocial']);
			}
			if(isset($_POST['fecLlamada'])){	
				$fecLlamada = trim($_POST['fecLlamada']);
			}
		   	if(isset($_POST['apellidoPaterno'])){	
				$apellidoPaterno = trim($_POST['apellidoPaterno']);
			}
		   	if(isset($_POST['apellidoMaterno'])){	
				$apellidoMaterno = trim($_POST['apellidoMaterno']);
			}
		   	if(isset($_POST['nombres'])){	
				$nombres = trim($_POST['nombres']);
			}
		   	if(isset($_POST['cargo'])){	
				$cargo = trim($_POST['cargo']);
			}
		   	if(isset($_POST['contribuyenteContactado'])){	
				$contribuyenteContactado = trim($_POST['contribuyenteContactado']);
			}
		   	if(isset($_POST['resultadoLlamada'])){	
				$resultadoLlamada = trim($_POST['resultadoLlamada']);
			}
		   	if(isset($_POST['resultadoNegociacion'])){	
				$resultadoNegociacion = trim($_POST['resultadoNegociacion']);
			}
		   	if(isset($_POST['tipoLLamada'])){	
				$tipoLLamada = trim($_POST['tipoLLamada']);
			}
		   	if(isset($_POST['observacion'])){	
				$observacion = trim($_POST['observacion']);
			}
		   	if(isset($_POST['expCoactivo'])){	
				$expCoactivo = trim($_POST['expCoactivo']);
			}
		   	if(isset($_POST['rcEmbargo'])){	
				$rcEmbargo = trim($_POST['rcEmbargo']);
			}
		   	if(isset($_POST['respuesta'])){	
				$respuesta = trim($_POST['respuesta']);
			}
		   	if(isset($_POST['fecEstimadaEntrega'])){	
				$fecEstimadaEntrega = trim($_POST['fecEstimadaEntrega']);
			}
		  
			if(isset($_POST['estado'])){	
				$estado = trim($_POST['estado']);
			}


			

			$objModel = $this->loadModel('aduanaLlamada');
			$objModel->updAduanaLlamada($idAduanaLlamada,$fecLlamada,$telefono,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuMod,$estado);

			
			$_POST = array();
			$_POST['idAduanaLlamada']=$idAduanaLlamada;
			$this->getAduanasLlamadas();
			

		}
	}

	public function delAduanaLlamada(){

		if(isset($_SESSION['id'])){

			$idAduanaLlamada = '';
		
			if(isset($_POST['idAduanaLlamada'])){
				$idAduanaLlamada = $_POST['idAduanaLlamada'];
			}

			$objModel = $this->loadModel('aduanaLlamada');
			$objModel->delAduanaLlamada($idAduanaLlamada);


			$_POST = array();
			$_POST['idAduanaLlamada']=$idAduanaLlamada;
			$_POST['estado']='DE';
			$this->getAduanasLlamadas();


		}
	}


	public function getDatosRuc(){

		if(isset($_SESSION['id'])){

			$ruc = '';

			if(isset($_POST['ruc'])){
				$ruc = trim($_POST['ruc']);
			}
			
			$objModel = $this->loadModel('aduanaLlamada');
			$result = $objModel->getDatosRuc($ruc);


			$arreglo['data'] = array();
			

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	public function getDatosDni(){

		if(isset($_SESSION['id'])){

			$dni = '';

			if(isset($_POST['dni'])){
				$dni = trim($_POST['dni']);
			}
			
			$objModel = $this->loadModel('aduanaLlamada');
			$result = $objModel->getDatosDni($dni);


			$arreglo['data'] = array();
			

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	
	
	
}




?>