<?php 

class indexController extends Controller{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
		
		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			
			if ($objLayout->validarAccesoOpcion('INDEX/INDEX',true)){

				$shape = '1';
			    $title = 'Cobraly';

			    if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}			
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				$this->_view->layout = $objLayout;

				$this->_view->setJs(array('index')); 
				$this->_view->renderizar('index');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}
			
		}
		else{			
			$this->_view->tipoError = '0';
			$this->_view->urlAnterior = '';
			$this->_view->renderizar('login',true);
		}
	}

	
}
?>