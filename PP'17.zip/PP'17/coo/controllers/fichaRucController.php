<?php 
class fichaRucController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){
					
			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;			
			
			if ($objLayout->validarAccesoOpcion('FICHARUC/CONSULTA',true)){
				
			    $ruc = '';
				$auto = '';
				$shape = '1';
		    	$title = 'Consulta Ficha Ruc';

			    if(isset($_GET['ruc'])){
					$ruc = trim($_GET['ruc']);
				}
				if(isset($_GET['auto'])){
					$auto = trim($_GET['auto']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}

				$this->_view->ruc = $ruc;
				$this->_view->auto = $auto;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}



	public function getDatosContacto(){

		if(isset($_SESSION['id'])){
			
		    $ruc = "";		   
		    //$idUsuarioSession = $_SESSION['id'];
		    $objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
		    
		    
			if(isset($_POST['ruc'])){
				$ruc = trim($_POST['ruc']);
			}


			$objModel = $this->loadModel('fichaRuc');
			$result = $objModel->getDatosContacto($ruc);
			

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
		
		}
	}



		   public function getDatosRuc(){
		   	if(isset($_SESSION['id'])){
					
				    $ruc = "";		   
				    //$idUsuarioSession = $_SESSION['id'];
				    $objLayout = $this->loadModel('layout');
					$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
				    
				    
					if(isset($_POST['ruc'])){
						$ruc = trim($_POST['ruc']);
					}


					$objModel = $this->loadModel('fichaRuc');
					$result = $objModel->getDatosRuc($ruc);
					

					$arreglo["data"] = array();

					while ($row = $result->fetch())  {
					    $arreglo["data"][] = $row;
					}

					echo json_encode($arreglo);
				
				}
			}

   }


	


?>