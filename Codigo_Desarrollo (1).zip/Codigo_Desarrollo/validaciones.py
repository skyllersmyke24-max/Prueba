import os
from rutas_de_archivos import ruta_carpeta_credenciales, ruta_usuario, ruta_contraseña

def validar_carpeta_credencial():
    if not os.path.exists(ruta_carpeta_credenciales):
        os.mkdir(ruta_carpeta_credenciales)
    else:
        return True

def validar_usuario():
    if os.path.exists(ruta_usuario):
        return True
    else:
        return False

def validar_contraseña():
    if os.path.exists(ruta_contraseña):
        return True
    else:
        return False
