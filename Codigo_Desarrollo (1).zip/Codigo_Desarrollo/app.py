import flet as ft

# Importación de los contenedores
from Containers.boton_proceso import boton_proceso
from Containers.campo_ingreso import campo_de_texto
from Containers.filas_proceso import fila_proceso
from Containers.imagen_institucional import imagen_institucional
from Containers.texto_registro import texto_alerta
from Containers.texto_titulo import texto_titulo

# Importación de las rutas
from rutas_de_archivos import (
    ruta_usuario,
    ruta_contraseña,
    ruta_ejecutable_asignar_SIEV,
    ruta_ejecutable_registrar_SIEV,
    ruta_ejecutable_prueba
)
from validaciones import validar_carpeta_credencial, validar_usuario, validar_contraseña

# Proceso de encriptación
from flet.security import encrypt, decrypt

# Ejecutar el programa de javascript
from proceso_javascript import ejecutar_programa_js

# Mostrar una alerta en el sistema usando ctypes
import ctypes 

def main(page: ft.Page):

    page.title = "Sistema de Escritos"

    # proceso_temporal = lambda x: print("Acaba de hacer click")

    # Nombre de los procesos
    etiqueta_asignar = "ASIGNAR ESCRITO"
    etiqueta_registrar = "GRABAR ESCRITO"
    etiqueta_registrar_credenciales = "REGISTRAR USUARIO"
    etiqueta_actualizar_contraseña = "ACTUALIZAR CONTRASEÑA"
    etiqueta_guardar_cambios = "GUARDAR CAMBIOS"
    etiqueta_proceso_completado = "PROCESO COMPLETADO"

    # Etiqueta de textos de entrada
    etiqueta_usuario = "USUARIO INTRANET"
    etiqueta_contraseña = "CONTRASEÑA"

    # Mensajes de alerta
    alerta_usuario = "El campo usuario está vacio"
    alerta_contraseña = "El campo contraseña está vacio"
    alerta_usuario_y_contraseña = "El campo usuario y contraseña están vacios"

    # Mensajes de alerta correcto
    mensaje_usuario_registrado = "El usuario se ha registrado con éxito"
    mensaje_contraseña_actualizada = "La contraseña se ha actualizada con éxito"
    mensaje_proceso_completado = "El proceso ha culminado exitosamente."

    #Mensaje de titulos
    titulo_app = "Bienvenido al ROBOT REGISTRO DE ESCRITOS MPV SUNAT - URD999"
    subtitulo_paso1 = "1.-El usuario al ingresar a Intranet en línea/administrativos/expediente virtual/menú de opciones, debe contar con los perfiles SIEV de “asignación de responsables” y “escritos electrónicos (grabar escrito)”, asimismo, “seguimiento y consultas”."
    subtitulo_paso2 = "2.-La hoja de “asignación de responsables” y “escritos electrónicos (grabar)” del archivo Excel, debe contener los datos requeridos según estructura y en formato texto."
    
    # Iconos
    icono_asignar = ft.Icons.ASSIGNMENT
    icono_registrar = ft.Icons.APP_REGISTRATION
    icono_registrar_credenciales = ft.Icons.LOCK
    icono_actualizar_contraseña = ft.Icons.REFRESH
    icono_usuario = ft.Icons.PERSON
    icono_contraseña = ft.Icons.LOCK_PERSON
    icono_guardar_cambios = ft.Icons.SAVE

    # Campo de ingreso
    campo_usuario = campo_de_texto(etiqueta_usuario, icono_usuario)
    campo_contraseña = campo_de_texto(etiqueta_contraseña, icono_contraseña, True)

    # Procesos de validación
    validar_carpeta_credencial()
    existe_usuario = validar_usuario()
    existe_contraseña = validar_contraseña()

    #Titulos visibles en la aplicación
    titulo_principal = texto_titulo(titulo_app)

    tamaño_texto_requisitos = 14
    distancia_margen_requisitos = 120

    #Requisitos de la aplicación
    requisito_1 = texto_titulo(subtitulo_paso1)
    requisito_1.content.size = tamaño_texto_requisitos
    requisito_1.margin = ft.margin.symmetric(horizontal=distancia_margen_requisitos)
    
    requisito_2 = texto_titulo(subtitulo_paso2)
    requisito_2.content.size = tamaño_texto_requisitos
    requisito_2.margin = ft.margin.symmetric(horizontal=distancia_margen_requisitos)




    def refrescar_cambios_de_registro():
        existe_usuario = validar_usuario()
        existe_contraseña = validar_contraseña()
        cuenta_registrada = True if (existe_usuario and existe_contraseña) else False
        cuenta_no_registrada = False if cuenta_registrada else True
        color_activado = (
            ft.Colors.INDIGO_900 if cuenta_registrada else ft.Colors.INDIGO_200
        )
        color_desactivado = (
            ft.Colors.INDIGO_200 if cuenta_registrada else ft.Colors.INDIGO_900
        )
        return (
            cuenta_registrada,
            cuenta_no_registrada,
            color_activado,
            color_desactivado,
        )

    cuenta_registrada, cuenta_no_registrada, color_activado, color_desactivado = (
        refrescar_cambios_de_registro()
    )

    if existe_usuario:
        campo_usuario.content.disabled = existe_usuario
        with open(ruta_usuario, "rb") as file:
            contenido_usuario = file.read()
            decifrar_usuario = contenido_usuario.decode("utf-8")
            desencriptar_usuario = decrypt(decifrar_usuario, "LLAVE_PRUEBA")
            campo_usuario.content.value = desencriptar_usuario
        page.update()

    if existe_contraseña:
        campo_contraseña.content.disabled = existe_contraseña
        with open(ruta_contraseña, "rb") as file:
            contenido_contraseña = file.read()
            decifrar_contraseña = contenido_contraseña.decode("utf-8")
            desencriptar_contraseña = decrypt(decifrar_contraseña, "LLAVE_PRUEBA")
            campo_contraseña.content.value = desencriptar_contraseña
        page.update()

    def boton_activar_con_usuario(nombre_boton, cuenta_registrada, color_activado):
        nombre_boton.disabled = cuenta_registrada
        nombre_boton.bgcolor = color_activado

    def boton_desactivado_sin_usuario(nombre_boton, cuenta_no_registrada, color_inhabilitado):
        nombre_boton.disabled = cuenta_no_registrada
        nombre_boton.bgcolor = color_inhabilitado

    def proceso_registrar_credenciales(e):

        if not campo_usuario.content.value and not campo_contraseña.content.value:
            mensaje_alerta.content.value = alerta_usuario_y_contraseña
            mensaje_alerta.content.color = ft.Colors.RED_900
            page.update()
            return

        if not campo_usuario.content.value:
            mensaje_alerta.content.value = alerta_usuario
            mensaje_alerta.content.color = ft.Colors.RED_900
            page.update()
            return

        if not campo_contraseña.content.value:
            mensaje_alerta.content.value = alerta_contraseña
            mensaje_alerta.content.color = ft.Colors.RED_900
            page.update()
            return

        with open(ruta_usuario, "wb") as file:
            contenido_usuario = campo_usuario.content.value
            encriptar_usario = encrypt(contenido_usuario, "LLAVE_PRUEBA")
            cifrar_usuario = encriptar_usario.encode("utf-8")
            file.write(cifrar_usuario)

        with open(ruta_contraseña, "wb") as file:
            contendio_contraseña = campo_contraseña.content.value
            encriptar_contraseña = encrypt(contendio_contraseña, "LLAVE_PRUEBA")
            cifrar_contraseña = encriptar_contraseña.encode("utf-8")
            file.write(cifrar_contraseña)

        campo_usuario.content.disabled = validar_usuario()
        campo_contraseña.content.disabled = validar_contraseña()

        cuenta_registrada, cuenta_no_registrada, color_activado, color_desactivado = (
            refrescar_cambios_de_registro()
        )

        boton_activar_con_usuario(boton_asignar, cuenta_no_registrada, color_activado)
        boton_activar_con_usuario(boton_registrar, cuenta_no_registrada, color_activado)
        boton_activar_con_usuario(
            boton_registrar_credenciales, cuenta_registrada, color_desactivado
        )
        boton_activar_con_usuario(
            boton_actualizar_contraseña, cuenta_no_registrada, color_activado
        )

        mensaje_alerta.content.value = mensaje_usuario_registrado
        mensaje_alerta.content.color = ft.Colors.GREEN_900

        page.update()

    def limpiar_campo_contraseña(e):
        campo_contraseña.content.disabled = False
        campo_contraseña.content.value = ""
        mensaje_alerta.content.value = ""

        boton_actualizar_contraseña.content.controls[0].name = icono_guardar_cambios
        boton_actualizar_contraseña.content.controls[1].value = etiqueta_guardar_cambios
        boton_actualizar_contraseña.on_click = actualizar_contraseña
        page.update()

    def actualizar_contraseña(e):

        if not campo_contraseña.content.value:
            mensaje_alerta.content.value = alerta_usuario
            mensaje_alerta.content.color = ft.Colors.RED_900
            page.update()
            return

        with open(ruta_contraseña, "wb") as file:
            contendio_contraseña = campo_contraseña.content.value
            encriptar_contraseña = encrypt(contendio_contraseña, "LLAVE_PRUEBA")
            cifrar_contraseña = encriptar_contraseña.encode("utf-8")
            file.write(cifrar_contraseña)

        campo_contraseña.content.disabled = validar_contraseña()
        boton_actualizar_contraseña.content.controls[0].name = (
            icono_actualizar_contraseña
        )
        boton_actualizar_contraseña.content.controls[1].value = (
            etiqueta_actualizar_contraseña
        )
        boton_actualizar_contraseña.on_click = limpiar_campo_contraseña

        mensaje_alerta.content.value = mensaje_contraseña_actualizada
        mensaje_alerta.content.color = ft.Colors.GREEN_900
        page.update()

    def ejecutar_asignar(e):
        valor_usuario = campo_usuario.content.value
        valor_contraseña = campo_contraseña.content.value
        boton_asignar.bgcolor = ft.Colors.TEAL_600
        boton_asignar.disabled = True
        boton_registrar.disabled = True
        page.update()

        ejecutar_programa_js(
            valor_usuario, valor_contraseña, ruta_ejecutable_asignar_SIEV
        )

        
        boton_asignar.bgcolor = ft.Colors.INDIGO_900
        boton_asignar.disabled = False
        boton_registrar.disabled = False
        page.update()

        # Mostrar una alerta en el sistema usando ctypes
        # ctypes.windll.user32.MessageBoxW(0, mensaje_proceso_completado, etiqueta_proceso_completado, 0x40)

    def ejecutar_registrar(e):
        valor_usuario = campo_usuario.content.value
        valor_contraseña = campo_contraseña.content.value

        boton_registrar.bgcolor = ft.Colors.TEAL_600
        boton_asignar.disabled = True
        boton_registrar.disabled = True

        page.update()

        # page.update()

        ejecutar_programa_js(
            valor_usuario, valor_contraseña, ruta_ejecutable_registrar_SIEV
        )

        boton_registrar.bgcolor = ft.Colors.INDIGO_900
        boton_asignar.disabled = False
        boton_registrar.disabled = False
        page.update()

        # boton_asignar.content.bgcolor = ft.Colors.INDIGO_900
        # boton_asignar.disabled = False
        # page.update()

    # Botones
    boton_asignar = boton_proceso(etiqueta_asignar, icono_asignar, ejecutar_asignar)
    boton_desactivado_sin_usuario(boton_asignar, cuenta_no_registrada, color_activado)

    boton_registrar = boton_proceso(
        etiqueta_registrar, icono_registrar, ejecutar_registrar
    )
    boton_desactivado_sin_usuario(boton_registrar, cuenta_no_registrada, color_activado)

    boton_registrar_credenciales = boton_proceso(
        etiqueta_registrar_credenciales,
        icono_registrar_credenciales,
        proceso_registrar_credenciales,
    )

    # boton_desactivado_sin_usuario(boton_registrar, cuenta_registrada, color_desactivado)
    boton_registrar_credenciales.disabled = cuenta_registrada
    boton_registrar_credenciales.bgcolor = color_desactivado
    # page.update()

    boton_actualizar_contraseña = boton_proceso(
        etiqueta_actualizar_contraseña,
        icono_actualizar_contraseña,
        limpiar_campo_contraseña,
    )

    boton_desactivado_sin_usuario(
        boton_actualizar_contraseña, cuenta_no_registrada, color_activado
    )

    mensaje_alerta = texto_alerta()
    mensaje_alerta.content.size = 16

    # Fila de proceso
    fila_de_escritos = fila_proceso()
    fila_de_escritos.content.controls.append(boton_asignar)
    fila_de_escritos.content.controls.append(boton_registrar)
    fila_de_escritos.margin = ft.margin.symmetric(vertical=3)

    fila_de_registro = fila_proceso()
    fila_de_registro.content.controls.append(boton_registrar_credenciales)
    fila_de_registro.content.controls.append(boton_actualizar_contraseña)


    logo_sunat = imagen_institucional()

    contendor_principal = ft.Container(
        content=ft.Column(
            controls=[
                logo_sunat,
                titulo_principal,
                requisito_1,
                requisito_2,
                fila_de_escritos,
                campo_usuario,
                campo_contraseña,
                mensaje_alerta,
                fila_de_registro,
            ],
        ),
        bgcolor=ft.Colors.WHITE,
        padding=ft.padding.symmetric(vertical=20),
        adaptive=True
        # alignment=ft.MainAxisAlignment.CENTER
    )

    ANCHO_VENTANA = 864
    ALTO_VENTANA = 630

    page.window.width = ANCHO_VENTANA
    page.window.max_width = ANCHO_VENTANA
    page.window.min_width = ANCHO_VENTANA

    page.window.height = ALTO_VENTANA
    page.window.max_height = ALTO_VENTANA
    page.window.min_height = ALTO_VENTANA

    page.window.maximizable = False
    # page.window.maximized = True

    page.add(contendor_principal)



ft.app(target=main)
