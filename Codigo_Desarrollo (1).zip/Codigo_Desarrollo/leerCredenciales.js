const fsp = require('fs/promises')

async function loadUserAccountFile(archivoUsuario) {
    try {
        const textoUserAccount = await fsp.readFile(archivoUsuario, 'utf-8');
        return textoUserAccount;
    } catch (error) {
        console.error('Error al leer el archivo:', error);
        return null;
    }
}

module.exports = loadUserAccountFile