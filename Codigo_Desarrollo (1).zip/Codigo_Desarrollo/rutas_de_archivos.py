import os
import sys

nombre_carpeta_credenciales = "Credenciales"
archivo_usuario = "Usuario.bin"
archivo_contraseña = "Contraseña.bin"
ejecutable_asignar_SIEV_escrito = "AsignarExpediente.exe"
ejecutable_registrar_SIEV_escrito = "RegistrarEscritos.exe"
ejecutable_prueba = "sum.exe"

ruta_base = os.getcwd()

ruta_carpeta_credenciales = os.path.join(ruta_base, nombre_carpeta_credenciales)
ruta_usuario = os.path.join(ruta_carpeta_credenciales, archivo_usuario)
ruta_contraseña = os.path.join(ruta_carpeta_credenciales, archivo_contraseña)

ruta_ejecutable_prueba = (
    os.path.join(sys._MEIPASS, ejecutable_prueba)
    if getattr(sys, "frozen", False)
    else ejecutable_prueba
)

ruta_ejecutable_asignar_SIEV = (
    os.path.join(sys._MEIPASS, ejecutable_asignar_SIEV_escrito)
    if getattr(sys, "frozen", False)
    else ejecutable_asignar_SIEV_escrito
)

ruta_ejecutable_registrar_SIEV = (
    os.path.join(sys._MEIPASS, ejecutable_registrar_SIEV_escrito)
    if getattr(sys, "frozen", False)
    else ejecutable_registrar_SIEV_escrito
)
