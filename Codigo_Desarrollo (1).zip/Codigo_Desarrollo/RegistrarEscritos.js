const puppeteer = require('puppeteer')
const selector = require('./selectorRegistrarEscritos.json')
const ExcelFileManager = require('./excelService')
const loadUserAccountFile = require('./leerCredenciales')
const getChromeExecutablePath = require('./rutaChrome')
const path = require('path')

async function RegistrarEscritos(textoUsuario, textoPassword) {

    let browser
    const TIEMPO_REINICIO_NAVEGADOR = 15000

    try {

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: true,
            defaultViewport: false,
            slowMo: 50,
            args: ['--start-maximized'],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await RegistrarEscritos(textoUsuario, textoPassword);
            });
        }

        const URLIntranet = "https://intranet.sunat.peru/cl-at-iamenu/"
        const URLSIEV = "https://intranet.sunat.peru/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=3:3.3.7"

        const tiempoEspera = 5000
        const TIEMPO_AVISO = 8000
        const paginaRegistro = "Escritos electronicos (grabar)"
        const columnaExpediente = 1
        const columnaNumeroEscrito = 2
        const columnaConsulta = 3
        const escritoTipoMPV = "Escrito Presentado por MPV"
        const mensajeGrabadoMPV = "El expediente se ha grabado con éxito."

        // Colores para pintar en el excel
        // const colorRojo = 'FF0000'
        // const colorVerde = '00B050'
        // const colorNaranja = 'F79646'
        const colorCeleste = 'DAE9F8'

        // const mensajeMotivoUsuario = "REGISTRAR DOCUMENTOS"
        const documentoExcel = "SIEV_ESCRITOS"
        // const rutaArchivoUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')
        // const rutaArchivoContrasena = path.resolve(process.cwd(), 'Credenciales', 'contraseña.txt')

        // const textoUsuario = await loadUserAccountFile(rutaArchivoUsuario)
        // const textoPassword = await loadUserAccountFile(rutaArchivoContrasena)

        const page = await browser.newPage()

        console.clear()
        console.log('** Ejecutando APP - Grabar Escritos **')
        console.log("Navegando a la Intranet SUNAT...")

        await page.goto(URLIntranet)

        console.log("Digitando usuario ...")
        const campoUsuario = await page.waitForSelector(selector.campo_usuario)
        await campoUsuario.type(textoUsuario)

        console.log("Digitando contrasena ...")
        const campoContraseña = await page.waitForSelector(selector.campo_contraseña)
        await campoContraseña.type(textoPassword)

        console.log("Iniciando sesion ...")
        const boton_iniciar_sesion = await page.waitForSelector(selector.boton_iniciar_sesion)
        await boton_iniciar_sesion.click()

        let validarCuentaUsuario

        try {

            validarCuentaUsuario = await page.waitForSelector(selector.error_iniciar_sesion, { timeout: TIEMPO_AVISO, visible: true }) ? false : false

        } catch (e) {

            validarCuentaUsuario = true

        }

        if(!validarCuentaUsuario){
            // console.log('*** Usuario no valido ***')
            mensaje_error = await page.evaluate(() => {
                return document.querySelector("td[style='color:red']") ? document.querySelector("td[style='color:red']").innerText : null
            })
    
            console.log(mensaje_error)
            // console.log('*** Usuario no valido ***')
            
            await browser.close()

            await new Promise((resolve) => setTimeout(() => resolve(process.exit()), tiempoEspera));
        }

        //Esperamos 5 segundos para consultar en el SIEV

        const excelAsignarExpediente = new ExcelFileManager()

        // await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), 'asignar_expediente') documentoExcel

        await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), documentoExcel)

        const indiceLimite = excelAsignarExpediente.obtenerNumeroDeFilas(paginaRegistro)

        // console.log(indiceLimite)
        console.log(`Total de consultas: ${indiceLimite - 1}`)

        // excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), 'asignar_expediente')

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        try {

            await page.goto(URLSIEV)

            let frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

            const escritosElectronicos = await frameMenu.waitForSelector(selector.escritos_electronicos)

            await escritosElectronicos.click()

            let prestacionDeEscritos = await frameMenu.waitForSelector(selector.prestacion_de_escritos)

            await prestacionDeEscritos.click()

        } catch (e) {
            console.log('** Usted no tiene acceso al perfil de Escritos Electrónicos **')
            await browser.close()
            console.log('*** CERRANDO EL PROCESO ***')
            await new Promise((resolve) => setTimeout(() => resolve(process.exit()), tiempoEspera));
        }

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        let frameDet = await NuevaConsultaRegistro(page)

        // let listaFrameDet = page.frames().map(frame => frame.url())

        // let numeroElementosListaFrame = listaFrameDet.length

        // let frameDet = await page.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

        for (let indiceActual = 2; indiceActual <= indiceLimite; indiceActual++) {

            // console.log('N° consulta ' + indiceActual + ' de ' + indiceLimite)
            console.log(`*Numero de consulta ${indiceActual - 1} de ${indiceLimite - 1}*`)

            const contenidoExpediente = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaExpediente)
            const contenidoNumeroDelEscrito = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaNumeroEscrito)
            const contenidoConsulta = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaConsulta)

            const validarContenido = contenidoConsulta ? contenidoConsulta : false

            if (validarContenido) {
                console.log(' -> Siguiente Consulta')
                console.clear()
                continue
            }
            // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

            const tipoEscrito = await frameDet.waitForSelector(selector.tipo_de_escrito)

            await tipoEscrito.type(escritoTipoMPV)

            const numeroExpediente = await frameDet.waitForSelector(selector.campo_numero_de_expediente)

            await numeroExpediente.type(contenidoExpediente.toString())

            const buscarExpediente = await frameDet.waitForSelector(selector.boton_buscar)

            await buscarExpediente.click()

            await excelAsignarExpediente.GuardarExcel(process.cwd(), documentoExcel)

            let validarExistenciaExpediente

            try {

                validarExistenciaExpediente = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_AVISO, visible: true }) ? false : null

            } catch (e) {

                validarExistenciaExpediente = true

            }

            if (!validarExistenciaExpediente) {

                const mensajeConsultaREC = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })

                console.log(' ->', mensajeConsultaREC)

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaConsulta, mensajeConsultaREC)
                excelAsignarExpediente.PintarCelda(paginaRegistro, indiceActual, columnaConsulta, colorCeleste)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)

                await botonLimpiarCampos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), documentoExcel)

                continue
            }

            const opcionVerExpediente = await frameDet.waitForSelector(selector.opcion_ver_expediente)
            await opcionVerExpediente.click()

            const numeroExpedienteMPV = await frameDet.waitForSelector(selector.campo_numero_expediente_mpv)
            await numeroExpedienteMPV.type(contenidoNumeroDelEscrito.toString())

            const botonBuscarExpedienteMPV = await frameDet.waitForSelector(selector.boton_buscar_expediente_mpv)
            await botonBuscarExpedienteMPV.click()

            let validarExistenciaExpedienteMPV

            try {

                validarExistenciaExpedienteMPV = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_AVISO, visible: true }) ? false : null

            } catch (e) {

                validarExistenciaExpedienteMPV = true

            }

            if (!validarExistenciaExpedienteMPV) {

                const mensajeConsultaMPV = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })

                console.log(' ->', mensajeConsultaMPV)

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaConsulta, mensajeConsultaMPV)
                excelAsignarExpediente.PintarCelda(paginaRegistro, indiceActual, columnaConsulta, colorCeleste)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                // const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)

                // await botonLimpiarCampos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), documentoExcel)

                frameDet = await NuevaConsultaRegistro(page)

                continue
            }

            const botonGrabar = await frameDet.waitForSelector(selector.boton_grabar)

            await botonGrabar.click()

            const botonAceptarGrabacion = await frameDet.waitForSelector(selector.boton_aceptar_grabado)

            await botonAceptarGrabacion.click()

            await new Promise((resolve) => setTimeout(resolve, TIEMPO_AVISO))
            
            
            // const botonRegresar = await frameDet.waitForSelector(selector.boton_regresar)

            // await botonRegresar.click()

            console.log(' ->', mensajeGrabadoMPV)

            excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaConsulta, mensajeGrabadoMPV)
            excelAsignarExpediente.PintarCelda(paginaRegistro, indiceActual, columnaConsulta, colorCeleste)

            await excelAsignarExpediente.GuardarExcel(process.cwd(), documentoExcel)

            frameDet = await NuevaConsultaRegistro(page)
        }

        await browser.close()
        console.log('Consulta finalizada')

    } catch (error) {
        // console.error('Error al iniciar el navegador o realizar consultas:', error);
        process.stdout.write("Error: " + error.message + "\n");

        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(() => setTimeout(RegistrarEscritos(textoUsuario, textoPassword), TIEMPO_REINICIO_NAVEGADOR), TIEMPO_REINICIO_NAVEGADOR);
    }
}


async function NuevaConsultaRegistro(pagina_principal) {

    const tiempoEspera = 5000

    const frameMenu = await pagina_principal.waitForFrame(async frame => { return frame.name() === "menu" })

    const registroDocumentosInternos = await frameMenu.waitForSelector(selector.prestacion_de_escritos)

    await registroDocumentosInternos.click()

    await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

    // pagina_principal.frames().map(frame => console.log('frame url', frame.url()))

    const listaFrames = pagina_principal.frames().map(frame => frame.url())

    const filtroframeDocumentosInternos = listaFrames.find(frame => frame.includes('escrito') ? frame : false)

    const frameDet = await pagina_principal.waitForFrame(async frame => { return frame.url() === filtroframeDocumentosInternos })

    return frameDet

}

const parametros_recibidos = process.argv.slice(2)
const textoUsuario = parametros_recibidos[0]
const textoPassword = parametros_recibidos[1]

RegistrarEscritos(textoUsuario, textoPassword)