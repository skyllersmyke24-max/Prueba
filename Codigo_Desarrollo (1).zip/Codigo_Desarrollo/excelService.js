const ExcelJS = require('exceljs')
const path = require('path')

class ExcelFileManager {
    constructor() {
        this.workbook = new ExcelJS.Workbook()
        this.worksheets = {}
    }

    async AbrirDocumentoExcel(RutaDocumento, NombreDocumento) {
        try {
            const RutaGuardado = path.resolve(RutaDocumento, `${NombreDocumento}.xlsx`);
            console.log(`Documento "${NombreDocumento}.xlsx" abierto correctamente.`);
            return await this.workbook.xlsx.readFile(RutaGuardado);

        } catch (error) {
            // console.error('Error al abrir el documento Excel:', error.message);
            console.log('')
        }
    }

    async GuardarExcel(RutaDocumento, NombreDocumento) {
        const RutaGuardado = path.resolve(RutaDocumento, `${NombreDocumento}.xlsx`)
        await this.workbook.xlsx.writeFile(RutaGuardado)
    }

    AgregarHojaExcel(NombreHoja) {
        //if(this.ObtenerHojaExcel(NombreHoja)){
        //    console.warn(`La Hoja con el nombre ${NombreHoja} ya existe`)
        //    return this.ObtenerHojaExcel(NombreHoja)
        //}

        const worksheet = this.workbook.addWorksheet(NombreHoja)
        this.worksheets[NombreHoja] = worksheet
        return worksheet
    }

    ObtenerHojaExcel(NombreHoja) {
        try {
            const worksheet = this.workbook.getWorksheet(NombreHoja);
            if (!worksheet) {
                throw new Error(`La hoja "${NombreHoja}" no se encontró en el documento.`);
            }
            //console.log(`La hoja "${NombreHoja}" ha sido seleccionada correctamente.`);
            return worksheet;
        } catch (error) {
            console.error('Error al obtener la hoja de cálculo:', error.message);
            return false;
        }
    }

    AgregarEncabezadosHojaExcel(NombreHoja, Encabezados) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        worksheet.columns = Encabezados
        // console.log('Encabeazados Agregados con éxito.')
    }

    AgregarFilaHojaExcel(NombreHoja, DatosFila) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        worksheet.addRow(DatosFila)
        console.log('---> Datos agregados al documento excel con éxito.')
    }

    ObtenerValorCelda(NombreHoja, indiceFila, indiceColumna) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        const fila = worksheet.getRow(indiceFila)
        const contenidoCelda = fila.getCell(indiceColumna).value
        return contenidoCelda
    }

    EscribirValorCelda(NombreHoja, indiceFila, indiceColumna, Texto) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        const fila = worksheet.getRow(indiceFila)
        fila.getCell(indiceColumna).value = Texto
    }

    obtenerNumeroDeFilas(NombreHoja){
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        let ultimoindiceFila
        const fila = worksheet.eachRow((row, rowNumber) => {
            // console.log('Fila '+rowNumber+' = '+row.values)
            ultimoindiceFila = rowNumber
        })
        // return ultimoindiceFila
        // console.log('Ultimo indice de fila ' + ultimoindiceFila)
        return ultimoindiceFila
    }

    ObtenerUnaCeldaUltimaFila(NombreHoja, columna) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        const ultimaFila = worksheet.lastRow
        //console.log(ultimaFila)

        if (ultimaFila) {
            const valorCelda = ultimaFila.getCell(columna).value
            return valorCelda
        }
    }

    PintarCelda(NombreHoja, indiceFila, indiceColumna, color) {
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        const fila = worksheet.getRow(indiceFila)
        const celda = fila.getCell(indiceColumna)
        // const celda = worksheet.getCell(indiceFila, indiceColumna)
        celda.fill = {
            type: 'pattern',
            pattern:'solid',
            fgColor: { argb: color }
        }
    }

    agregarValorATabla(NombreHoja, nombreTabla,indiceFila, indiceColumna){
        const worksheet = this.ObtenerHojaExcel(NombreHoja)
        const tabla = worksheet.getTable(nombreTabla); // Reemplaza con el nombre de tu tabla
        // Obtener el rango de la tabla




        console.log(tabla.rows())
    }

}

module.exports = ExcelFileManager

// async function prueba() {
//     const Resultado_Excel = new ExcelFileManager()

//     await Resultado_Excel.AbrirDocumentoExcel(process.cwd(), 'SIEV_ESCRITOS')
//     valor = Resultado_Excel.ObtenerValorCelda('Asignacion de responsables',2,3)
//     // valor_texto = valor.toString()
//     // console.log(valor_texto.trim())
    
//     // await Resultado_Excel.GuardarExcel(process.cwd(), 'SIEV_ESCRITOS')
//     // Resultado_Excel.ObtenerHojaExcel('Asignacion de responsables')
//     // Resultado_Excel.agregarValorATabla('Asignacion de responsables', 'TablaAsignar',4,6); // Reemplaza con el nombre de tu tabla
//     // console.log(tabla)



// }
    
// prueba()







/* async function prueba() {
    const Resultado_Excel = new ExcelFileManager()

    await Resultado_Excel.AbrirDocumentoExcel(process.cwd(), 'RESULTADO_ECHASKI')

    //Resultado_Excel.ObtenerHojaExcel('CONSULTA_ECHASKI')

    const resultado_memo = {tipo_documento:"MEMORANDUM"}
    const resultado_final = {
        ...resultado_memo,
        numero_documento:"74549754"
    }

    Resultado_Excel.AgregarFilaHojaExcel("CONSULTA_ECHASKI", resultado_final)

    Resultado_Excel.GuardarExcel(process.cwd(),'RESULTADO_ECHASKI')


    //const indice = Resultado_Excel.ObtenerUnaCeldaUltimaFila("CONSULTA_ECHASKI", 'A')

    //console.log(indice)

}

prueba() */


//const indice = Resultado_Excel.ObtenerUnaCeldaUltimaFila("CONSULTA_ECHASKI", 'A')

//console.log(indice)


/* const Resultado_Excel = new ExcelFileManager()

Resultado_Excel.AgregarHojaExcel("CONSULTA")
Resultado_Excel.AgregarHojaExcel("RESULTADOS")

const Encabeazados = [
    {header: 'TIPO DOCUMENTO', key: 'tipo_documento', width:25},
    {header: 'NUMERO DOCUMENTO', key: 'numero_documento', width:30},
    {header: 'FECHA GENERACIÓN', key: 'fecha_generacion', width:25},
    {header: 'DERIVADO POR', key: 'derivador_por', width:25},
    {header: 'FECHA ULT. DERIVACIÓN', key: 'fecha_ult_derivacion', width:25},
    {header: 'ASUNTO', key: 'asunto', width:25},
    {header: 'ESTADO', key: 'estado', width:25},
    {header: 'REC ENCONTRADA', key: 'rec_encontrada', width:25},
]

const resultado_memo = {tipo_documento:"MEMORANDUM"}
const resultado_final = {
    ...resultado_memo,
    numero_documento:"74549754"
}


//Resultado_Excel.ObtenerHojaExcel("CONSULTA")
Resultado_Excel.AgregarEncabezadosHojaExcel("CONSULTA",Encabeazados )
Resultado_Excel.AgregarFilaHojaExcel("CONSULTA", resultado_final)


Resultado_Excel.GuardarExcel(process.cwd(),'Resutaldos')
 */
