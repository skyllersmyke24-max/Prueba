import subprocess
import ctypes
import os
import platform

def limpiar_consola():
    # Limpia la consola dependiendo del sistema operativo
    if platform.system() == "Windows":
        os.system('cls')  # Comando para Windows
    else:
        os.system('clear')  # Comando para Unix/Linux/Mac

def limpiar_salida(salida):
    # Decodificar la salida
    salida = salida.encode('latin1').decode('utf-8', 'ignore')
    return salida


def ejecutar_programa_js(usuario, contraseña, ruta_programa_js):
    limpiar_consola()

    args = [usuario, contraseña]
    resultado = subprocess.Popen(
        [ruta_programa_js] + args,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        bufsize=1,
        text=True
    )

    # codigo Funcional
    for line in resultado.stdout:
        # print(line, end="")
        salida_limpia = limpiar_salida(line)
        print(salida_limpia, end="")

    for line in resultado.stderr:
        # print(line, end="")
        error_limpio = limpiar_salida(line)
        print(error_limpio, end="")

    resultado.wait()

    # Mostrar una alerta en el sistema usando ctypes todo correcto
    if resultado.returncode == 0:
        ctypes.windll.user32.MessageBoxW(0, "El proceso ha culminado exitosamente.", "Proceso Completo", 0x40)

    else:
        ctypes.windll.user32.MessageBoxW(0, "El proceso ha culminado con errores.", "Proceso Incompleto", 0x10)