import flet as ft

def texto_titulo(mensaje):
    texto = ft.Container(
        content=ft.Text(
            value=mensaje,
            size=20,
            italic=True,
            # color=color_mensaje,
            weight=ft.FontWeight.W_500,
        ),
        alignment=ft.alignment.center
    )

    return texto
