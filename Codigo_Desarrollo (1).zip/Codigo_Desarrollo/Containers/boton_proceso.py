import flet as ft

def boton_proceso(nombre_proceso, nombre_icono, proceso_boton):
    boton = ft.Container(
        content=ft.Row(
            controls=[
                ft.Icon(name=nombre_icono, color=ft.Colors.WHITE),
                ft.Text(
                    value=nombre_proceso,
                    size=16,
                    color=ft.Colors.WHITE,
                    weight=ft.FontWeight.W_500,
                ),
            ],
        ),
        padding=10,
        bgcolor=ft.Colors.INDIGO_900,
        border_radius=10,
        # disabled=estado_acceso,
        # border=ft.border.all(2, ft.Colors.BLACK),
        on_click = proceso_boton
    )

    return boton
            

