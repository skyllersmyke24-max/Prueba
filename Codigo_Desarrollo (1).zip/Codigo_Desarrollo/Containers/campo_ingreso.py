import flet as ft


def campo_de_texto(etiqueta_texto, nombre_icono, activar_contraseña=False):
    campo_texto = ft.Container(
        content=ft.TextField(
            prefix_icon=ft.Icon(name=nombre_icono, color=ft.Colors.BLACK, size=30),
            color=ft.Colors.BLACK,
            label=etiqueta_texto,
            label_style=ft.TextStyle(color=ft.Colors.BLACK),
            # border = ft.border.all(color=ft.Colors.BLACK, width=2),
            border_color=ft.Colors.BLACK,
            # autofocus=True,
            focused_border_color=ft.Colors.INDIGO_900,
            password=activar_contraseña,
        ),
        margin=ft.margin.symmetric(vertical=3),
        padding=ft.padding.symmetric(horizontal=150, vertical=3),
    )
    return campo_texto
