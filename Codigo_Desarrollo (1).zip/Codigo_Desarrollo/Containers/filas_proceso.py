import flet as ft

def fila_proceso():
    fila = ft.Container(
        content=ft.Row(
            controls=[],
            alignment=ft.MainAxisAlignment.CENTER,
            # spacing=20,
        )
    )

    return fila