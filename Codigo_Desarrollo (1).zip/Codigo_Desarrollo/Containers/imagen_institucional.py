import flet as ft

def imagen_institucional():
    imagen = ft.Container(
        content=ft.Image(
            src="../assets/img/sunat.png",
            width=300,
            height=100,
            fit=ft.ImageFit.CONTAIN,
            # color=ft.Colors.YELLOW
            # fit=ft.ImageFit.CONTAIN,
        ),
        # border=ft.border.all(2, ft.Colors.BLACK),
        margin=ft.margin.symmetric(horizontal=200, vertical=0),
        alignment=ft.alignment.center,
        # padding=0,
        # bgcolor=ft.Colors.RED
        # alignment=ft.alignment.center,
        # padding=ft.padding.only(top=20, bottom=20),
    )
    return imagen
