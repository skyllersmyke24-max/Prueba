#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import time
import json
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from webdriver_manager.chrome import ChromeDriverManager

class SUNATBot:
    def __init__(self):
        """Inicializa el bot"""
        self.driver = None
        self.wait = None
        self.usuario = ""
        self.clave = ""
        self.url_base = "https://intranet.sunat.peru/cl-at-iamenu/"
        
    def leer_credenciales(self):
        """Lee las credenciales desde los archivos usuario.txt y clave.txt"""
        try:
            # Leer usuario
            with open('usuario.txt', 'r', encoding='utf-8') as f:
                self.usuario = f.read().strip()
            
            # Leer clave
            with open('clave.txt', 'r', encoding='utf-8') as f:
                self.clave = f.read().strip()
                
            if not self.usuario or not self.clave:
                raise ValueError("Usuario o clave están vacíos")
                
            print(f" Credenciales cargadas correctamente para usuario: {self.usuario}")
            return True
            
        except FileNotFoundError as e:
            print(f" Error: No se encontró el archivo {e.filename}")
            print("Asegúrate de tener los archivos 'usuario.txt' y 'clave.txt' en el directorio actual")
            return False
        except Exception as e:
            print(f" Error leyendo credenciales: {str(e)}")
            return False
    
    def configurar_navegador(self):
        """Configura y lanza el navegador Chrome"""
        try:
            # Opciones de Chrome
            chrome_options = Options()
            chrome_options.add_argument("--disable-web-security")
            chrome_options.add_argument("--allow-running-insecure-content")
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            # chrome_options.add_argument("--headless")  # Descomenta para modo headless
            
            # Configurar el driver
            service = Service(ChromeDriverManager().install())
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.driver.maximize_window()
            
            # Configurar wait
            self.wait = WebDriverWait(self.driver, 20)
            
            print(" Navegador configurado correctamente")
            return True
            
        except Exception as e:
            print(f" Error configurando navegador: {str(e)}")
            return False
    
    def realizar_login(self):
        """Realiza el proceso de login en SUNAT"""
        try:
            print(" Accediendo a la página de login...")
            self.driver.get(self.url_base)
            
            # Esperar a que cargue la página
            time.sleep(3)
            
            # Buscar campos de usuario y clave
            print(" Buscando campos de login...")
            campo_usuario = self.wait.until(
                EC.presence_of_element_located((By.NAME, "cuenta"))
            )
            campo_clave = self.driver.find_element(By.NAME, "password")
            
            # Ingresar credenciales
            print(" Ingresando credenciales...")
            campo_usuario.clear()
            campo_usuario.send_keys(self.usuario)
            
            campo_clave.clear()
            campo_clave.send_keys(self.clave)
            
            # Hacer clic en el botón de login
            boton_login = self.driver.find_element(By.CSS_SELECTOR, "input[value='Iniciar Sesion']")
            boton_login.click()
            
            print(" Login realizado, esperando redirección...")
            
            # Esperar a que se complete el login (puede cambiar la URL o aparecer nuevo contenido)
            time.sleep(5)
            
            # Verificar si el login fue exitoso
            if "menuS01Alias" in self.driver.current_url:
                print(" Login exitoso")
                return True
            else:
                print(" El login podría haber fallado")
                return False
                
        except Exception as e:
            print(f" Error durante el login: {str(e)}")
            return False
    
    def navegar_a_sistema_notificaciones(self):
        """Navega directamente al Sistema de Notificaciones desde la página principal"""
        try:
            print(" Buscando enlace directo a 'Sistema de Notificaciones'...")
            
            # Buscar el enlace directo de Sistema de Notificaciones en la página principal
            # Según el HTML: javascript:x1('0:104')
            sistema_notif_link = self.wait.until(
                EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Sistema de Notificaciones"))
            )
            sistema_notif_link.click()
            
            print(" Clic en Sistema de Notificaciones exitoso")
            time.sleep(3)
            
            # Verificar si se abrió una nueva ventana/pestaña
            if len(self.driver.window_handles) > 1:
                # Cambiar a la nueva ventana
                self.driver.switch_to.window(self.driver.window_handles[-1])
                print(" Cambiado a nueva ventana del Sistema de Notificaciones")
            
            return True
            
        except Exception as e:
            print(f" Error navegando al Sistema de Notificaciones: {str(e)}")
            # Método alternativo usando JavaScript
            try:
                print(" Intentando método alternativo...")
                self.driver.execute_script("x1('0:104')")
                time.sleep(3)
                if len(self.driver.window_handles) > 1:
                    self.driver.switch_to.window(self.driver.window_handles[-1])
                return True
            except:
                return False
    
    def navegar_en_sistema_notificaciones(self):
        """Navega dentro del Sistema de Notificaciones hacia Seguimiento"""
        try:
            print(" Esperando que cargue el Sistema de Notificaciones...")
            time.sleep(5)
            
            # Buscar opciones de navegación en la nueva página
            print(" Buscando opciones de Seguimiento de Notificaciones...")
            
            # Intentar varios selectores para encontrar el menú de navegación
            seguimiento_selectors = [
                "//a[contains(text(), 'Seguimiento')]",
                "//li[contains(text(), 'Seguimiento')]",
                "//span[contains(text(), 'Seguimiento')]",
                "//div[contains(text(), 'Seguimiento')]",
                "//a[@href*='seguimiento' or @onclick*='seguimiento']",
                "//a[contains(@class, 'nivel') and contains(text(), 'Seguimiento')]"
            ]
            
            seguimiento_element = None
            for selector in seguimiento_selectors:
                try:
                    seguimiento_element = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    break
                except:
                    continue
            
            if seguimiento_element:
                seguimiento_element.click()
                print(" Navegación a Seguimiento exitosa")
                time.sleep(3)
                return True
            else:
                print(" No se encontró enlace específico de Seguimiento, continuando...")
                return True
                
        except Exception as e:
            print(f" Error navegando en Sistema de Notificaciones: {str(e)}")
            return False
    
    def acceder_registro_manual(self):
        """Accede directamente al Registro Manual de Pedido de Notificación"""
        try:
            print(" Buscando 'Registro Manual de Pedido de Notificación'...")
            
            # Intentar múltiples selectores para encontrar el enlace
            registro_selectors = [
                "//a[contains(text(), 'Registro Manual de Pedido')]",
                "//a[contains(text(), 'Registro Manual')]",
                "//li[contains(text(), 'Registro Manual')]",
                "//span[contains(text(), 'Registro Manual')]",
                "//a[@href*='registro' or @onclick*='registro']",
                "//a[contains(@class, 'nivel') and contains(text(), 'Registro')]"
            ]
            
            registro_element = None
            for selector in registro_selectors:
                try:
                    print(f" Intentando selector: {selector}")
                    registro_element = self.wait.until(EC.element_to_be_clickable((By.XPATH, selector)))
                    break
                except:
                    continue
            
            if registro_element:
                print(" Elemento encontrado, haciendo clic...")
                self.driver.execute_script("arguments[0].click();", registro_element)
                time.sleep(5)
                
                # Verificar si llegamos a la página correcta
                if "Registro Manual de Pedido de Notificación" in self.driver.page_source:
                    print(" Llegamos a la página de Registro Manual")
                    return True
                else:
                    print(" Página cargada pero verificando contenido...")
                    return True
            else:
                # Si no encontramos el enlace directo, buscar en menús desplegables
                print("🔄 Buscando en menús desplegables...")
                return self.buscar_en_menu_lateral()
                
        except Exception as e:
            print(f" Error accediendo a Registro Manual: {str(e)}")
            return self.buscar_en_menu_lateral()
    
    def buscar_en_menu_lateral(self):
        """Busca en el menú lateral del sistema de notificaciones"""
        try:
            print("🔄 Explorando menú lateral...")
            
            # Buscar elementos de menú lateral
            menu_items = self.driver.find_elements(By.XPATH, "//ul[@class='ulMenu']//li | //div[@class='liOpcion']//a | //ul[@id='ulSubmenu']//li")
            
            for item in menu_items:
                try:
                    texto = item.text.strip()
                    if "registro" in texto.lower() and "manual" in texto.lower():
                        print(f" Encontrado elemento del menú: {texto}")
                        self.driver.execute_script("arguments[0].click();", item)
                        time.sleep(3)
                        return True
                except:
                    continue
            
            print(" Continuando con la extracción en la página actual...")
            return True
            
        except Exception as e:
            print(f" Error buscando en menú lateral: {str(e)}")
            return True
    
    def verificar_pagina_registro_manual(self):
        """Verifica que estamos en la página correcta y extrae título"""
        try:
            print("🔄 Verificando página actual...")
            
            # Buscar el título específico de la página
            titulos_posibles = [
                "Registro Manual de Pedido de Notificaciones",
                "Registro Manual de Pedido de Notificación",
                "Sistema de Notificaciones"
            ]
            
            titulo_encontrado = None
            for titulo in titulos_posibles:
                if titulo in self.driver.page_source:
                    titulo_encontrado = titulo
                    break
            
            if titulo_encontrado:
                print(f" Página verificada: {titulo_encontrado}")
                return True
            else:
                print(" Título específico no encontrado, pero continuando con la extracción...")
                return True
                
        except Exception as e:
            print(f" Error verificando página: {str(e)}")
            return True
    
    def extraer_informacion_completa(self):
        """Extrae toda la información disponible en la página de Registro Manual"""
        try:
            print("🔄 Extrayendo información detallada de la página...")
            
            informacion = {
                'timestamp': datetime.now().isoformat(),
                'url_actual': self.driver.current_url,
                'titulo_pagina': self.driver.title,
                'titulo_seccion': self.extraer_titulo_seccion(),
                'campos_formulario': [],
                'dropdowns': [],
                'campos_texto': [],
                'botones_accion': [],
                'botones_archivo': [],
                'etiquetas_campos': [],
                'valores_actuales': [],
                'elementos_interactivos': [],
                'estructura_formulario': {},
                'validaciones': []
            }
            
            # Extraer título de la sección principal
            print("  Extrayendo título de la sección...")
            informacion['titulo_seccion'] = self.extraer_titulo_seccion()
            
            # Extraer campos del formulario específicos de la imagen
            print("  Extrayendo campos específicos del formulario...")
            informacion['campos_formulario'] = self.extraer_campos_formulario_especificos()
            
            # Extraer dropdowns/selectores
            print("  Extrayendo dropdowns...")
            informacion['dropdowns'] = self.extraer_dropdowns_detallados()
            
            # Extraer campos de texto
            print("  Extrayendo campos de texto...")
            informacion['campos_texto'] = self.extraer_campos_texto_detallados()
            
            # Extraer botones de acción
            print("  Extrayendo botones de acción...")
            informacion['botones_accion'] = self.extraer_botones_accion()
            
            # Extraer botones de archivo
            print("  Extrayendo botones de archivo...")
            informacion['botones_archivo'] = self.extraer_botones_archivo()
            
            # Extraer etiquetas de campos
            print("  Extrayendo etiquetas de campos...")
            informacion['etiquetas_campos'] = self.extraer_etiquetas_campos()
            
            # Extraer valores actuales
            print("  Extrayendo valores actuales...")
            informacion['valores_actuales'] = self.extraer_valores_actuales()
            
            # Extraer todos los elementos interactivos
            print("  Extrayendo elementos interactivos...")
            informacion['elementos_interactivos'] = self.extraer_elementos_interactivos()
            
            # Analizar estructura del formulario
            print("  Analizando estructura del formulario...")
            informacion['estructura_formulario'] = self.analizar_estructura_formulario()
            
            # Extraer todos los enlaces
            print("  Extrayendo enlaces...")
            enlaces = self.driver.find_elements(By.TAG_NAME, "a")
            for enlace in enlaces:
                try:
                    info_enlace = {
                        'texto': enlace.text.strip(),
                        'href': enlace.get_attribute('href') or '',
                        'id': enlace.get_attribute('id') or '',
                        'class': enlace.get_attribute('class') or '',
                        'onclick': enlace.get_attribute('onclick') or '',
                        'visible': enlace.is_displayed()
                    }
                    if info_enlace['texto'] or info_enlace['href']:
                        informacion['enlaces'].append(info_enlace)
                except:
                    continue
            
            # Extraer formularios
            print("  Extrayendo formularios...")
            formularios = self.driver.find_elements(By.TAG_NAME, "form")
            for form in formularios:
                try:
                    info_form = {
                        'id': form.get_attribute('id') or '',
                        'name': form.get_attribute('name') or '',
                        'action': form.get_attribute('action') or '',
                        'method': form.get_attribute('method') or '',
                        'class': form.get_attribute('class') or ''
                    }
                    informacion['formularios'].append(info_form)
                except:
                    continue
            
            # Extraer campos de input
            print("   Extrayendo campos de entrada...")
            inputs = self.driver.find_elements(By.TAG_NAME, "input")
            for inp in inputs:
                try:
                    info_input = {
                        'type': inp.get_attribute('type') or '',
                        'name': inp.get_attribute('name') or '',
                        'id': inp.get_attribute('id') or '',
                        'placeholder': inp.get_attribute('placeholder') or '',
                        'value': inp.get_attribute('value') or '',
                        'class': inp.get_attribute('class') or '',
                        'required': inp.get_attribute('required') or False,
                        'visible': inp.is_displayed(),
                        'habilitado': inp.is_enabled()
                    }
                    if info_input['type'] not in ['hidden']:
                        informacion['campos_input'].append(info_input)
                except:
                    continue
            
            # Extraer selectores (dropdown)
            print(" Extrayendo selectores...")
            selects = self.driver.find_elements(By.TAG_NAME, "select")
            for select in selects:
                try:
                    opciones = []
                    options = select.find_elements(By.TAG_NAME, "option")
                    for opt in options:
                        opciones.append({
                            'text': opt.text,
                            'value': opt.get_attribute('value') or '',
                            'selected': opt.is_selected()
                        })
                    
                    info_select = {
                        'id': select.get_attribute('id') or '',
                        'name': select.get_attribute('name') or '',
                        'class': select.get_attribute('class') or '',
                        'opciones': opciones,
                        'visible': select.is_displayed(),
                        'habilitado': select.is_enabled()
                    }
                    informacion['selectores'].append(info_select)
                except:
                    continue
            
            # Extraer tablas
            print("  Extrayendo tablas...")
            tablas = self.driver.find_elements(By.TAG_NAME, "table")
            for i, tabla in enumerate(tablas):
                try:
                    filas = tabla.find_elements(By.TAG_NAME, "tr")
                    info_tabla = {
                        'indice': i,
                        'id': tabla.get_attribute('id') or '',
                        'class': tabla.get_attribute('class') or '',
                        'filas': len(filas),
                        'visible': tabla.is_displayed()
                    }
                    
                    # Extraer encabezados si existen
                    headers = tabla.find_elements(By.TAG_NAME, "th")
                    if headers:
                        info_tabla['encabezados'] = [h.text.strip() for h in headers]
                    
                    informacion['tablas'].append(info_tabla)
                except:
                    continue
            
            # Extraer divs principales
            print("  Extrayendo contenedores principales...")
            divs = self.driver.find_elements(By.TAG_NAME, "div")
            for div in divs:
                try:
                    div_id = div.get_attribute('id') or ''
                    div_class = div.get_attribute('class') or ''
                    
                    if div_id or 'container' in div_class.lower() or 'main' in div_class.lower():
                        info_div = {
                            'id': div_id,
                            'class': div_class,
                            'visible': div.is_displayed()
                        }
                        informacion['divs_principales'].append(info_div)
                except:
                    continue
            
            # Extraer texto visible importante
            print("   Extrayendo texto visible...")
            elementos_texto = self.driver.find_elements(By.XPATH, "//h1 | //h2 | //h3 | //h4 | //h5 | //h6 | //p | //span | //label")
            for elemento in elementos_texto:
                try:
                    texto = elemento.text.strip()
                    if texto and len(texto) > 3 and elemento.is_displayed():
                        informacion['texto_visible'].append({
                            'tag': elemento.tag_name,
                            'texto': texto,
                            'id': elemento.get_attribute('id') or '',
                            'class': elemento.get_attribute('class') or ''
                        })
                except:
                    continue
            
            print(" Extracción de información completada exitosamente")
            return informacion
            
        except Exception as e:
            print(f" Error extrayendo información: {str(e)}")
            return None
    
    def extraer_titulo_seccion(self):
        """Extrae el título principal de la sección"""
        try:
            # Buscar el título en diferentes ubicaciones posibles
            titulos_selectores = [
                "//h1", "//h2", "//h3", 
                "//div[contains(@class, 'titulo')]",
                "//span[contains(text(), 'Registro Manual')]",
                "//td[contains(text(), 'Registro Manual')]"
            ]
            
            for selector in titulos_selectores:
                try:
                    elemento = self.driver.find_element(By.XPATH, selector)
                    if "registro" in elemento.text.lower() and "manual" in elemento.text.lower():
                        return elemento.text.strip()
                except:
                    continue
            return "Título no encontrado"
        except:
            return "Error extrayendo título"
    
    def extraer_campos_formulario_especificos(self):
        """Extrae los campos específicos vistos en la imagen"""
        campos_especificos = []
        try:
            # Lista de campos específicos que esperamos encontrar
            campos_esperados = [
                "Dependencia", "Clase de Documento", "Tipo de Documento",
                "Número de proceso SNIE", "Responsable SNIE", "Encargado",
                "UU.OO Responsable", "Archivo Seleccionado"
            ]
            
            for campo in campos_esperados:
                campo_info = self.buscar_campo_por_etiqueta(campo)
                if campo_info:
                    campos_especificos.append(campo_info)
                    
        except Exception as e:
            print(f"Error extrayendo campos específicos: {str(e)}")
        
        return campos_especificos
    
    def buscar_campo_por_etiqueta(self, etiqueta):
        """Busca un campo específico por su etiqueta"""
        try:
            # Buscar la etiqueta
            etiqueta_element = None
            etiqueta_selectores = [
                f"//td[contains(text(), '{etiqueta}')]",
                f"//label[contains(text(), '{etiqueta}')]",
                f"//span[contains(text(), '{etiqueta}')]",
                f"//th[contains(text(), '{etiqueta}')]"
            ]
            
            for selector in etiqueta_selectores:
                try:
                    etiqueta_element = self.driver.find_element(By.XPATH, selector)
                    break
                except:
                    continue
            
            if not etiqueta_element:
                return None
            
            # Buscar el campo asociado (input o select)
            campo_element = None
            campo_selectores = [
                ".//following-sibling::td//input",
                ".//following-sibling::td//select", 
                ".//parent::td//following-sibling::td//input",
                ".//parent::td//following-sibling::td//select",
                ".//following::input[1]",
                ".//following::select[1]"
            ]
            
            for selector in campo_selectores:
                try:
                    campo_element = etiqueta_element.find_element(By.XPATH, selector)
                    break
                except:
                    continue
            
            if campo_element:
                tipo_campo = campo_element.tag_name
                info_campo = {
                    'etiqueta': etiqueta,
                    'tipo': tipo_campo,
                    'id': campo_element.get_attribute('id') or '',
                    'name': campo_element.get_attribute('name') or '',
                    'class': campo_element.get_attribute('class') or '',
                    'value': campo_element.get_attribute('value') or '',
                    'placeholder': campo_element.get_attribute('placeholder') or '',
                    'required': bool(campo_element.get_attribute('required')),
                    'readonly': bool(campo_element.get_attribute('readonly')),
                    'disabled': not campo_element.is_enabled(),
                    'visible': campo_element.is_displayed()
                }
                
                # Si es un select, obtener las opciones
                if tipo_campo == 'select':
                    opciones = []
                    try:
                        option_elements = campo_element.find_elements(By.TAG_NAME, 'option')
                        for option in option_elements:
                            opciones.append({
                                'text': option.text,
                                'value': option.get_attribute('value') or '',
                                'selected': option.is_selected()
                            })
                        info_campo['opciones'] = opciones
                    except:
                        info_campo['opciones'] = []
                
                return info_campo
            
        except Exception as e:
            print(f"Error buscando campo {etiqueta}: {str(e)}")
        
        return None
    
    def extraer_dropdowns_detallados(self):
        """Extrae información detallada de todos los dropdowns"""
        dropdowns = []
        try:
            select_elements = self.driver.find_elements(By.TAG_NAME, 'select')
            
            for i, select in enumerate(select_elements):
                try:
                    if select.is_displayed():
                        opciones = []
                        option_elements = select.find_elements(By.TAG_NAME, 'option')
                        
                        for option in option_elements:
                            opciones.append({
                                'text': option.text.strip(),
                                'value': option.get_attribute('value') or '',
                                'selected': option.is_selected()
                            })
                        
                        dropdown_info = {
                            'indice': i,
                            'id': select.get_attribute('id') or '',
                            'name': select.get_attribute('name') or '',
                            'class': select.get_attribute('class') or '',
                            'total_opciones': len(opciones),
                            'opcion_seleccionada': next((opt['text'] for opt in opciones if opt['selected']), 'Ninguna'),
                            'todas_las_opciones': opciones,
                            'habilitado': select.is_enabled(),
                            'etiqueta_asociada': self.buscar_etiqueta_asociada(select)
                        }
                        
                        dropdowns.append(dropdown_info)
                        
                except Exception as e:
                    print(f"Error procesando dropdown {i}: {str(e)}")
                    
        except Exception as e:
            print(f"Error extrayendo dropdowns: {str(e)}")
        
        return dropdowns
    
    def extraer_campos_texto_detallados(self):
        """Extrae información detallada de campos de texto"""
        campos_texto = []
        try:
            input_elements = self.driver.find_elements(By.TAG_NAME, 'input')
            
            for i, input_elem in enumerate(input_elements):
                try:
                    tipo = input_elem.get_attribute('type') or 'text'
                    
                    if tipo in ['text', 'password', 'email', 'number', 'search'] and input_elem.is_displayed():
                        campo_info = {
                            'indice': i,
                            'tipo': tipo,
                            'id': input_elem.get_attribute('id') or '',
                            'name': input_elem.get_attribute('name') or '',
                            'class': input_elem.get_attribute('class') or '',
                            'value': input_elem.get_attribute('value') or '',
                            'placeholder': input_elem.get_attribute('placeholder') or '',
                            'maxlength': input_elem.get_attribute('maxlength') or '',
                            'readonly': bool(input_elem.get_attribute('readonly')),
                            'required': bool(input_elem.get_attribute('required')),
                            'disabled': not input_elem.is_enabled(),
                            'etiqueta_asociada': self.buscar_etiqueta_asociada(input_elem)
                        }
                        
                        campos_texto.append(campo_info)
                        
                except Exception as e:
                    print(f"Error procesando campo de texto {i}: {str(e)}")
                    
        except Exception as e:
            print(f"Error extrayendo campos de texto: {str(e)}")
        
        return campos_texto
    
    def extraer_botones_accion(self):
        """Extrae botones de acción como 'Registrar Pedido'"""
        botones_accion = []
        try:
            # Buscar diferentes tipos de botones
            button_selectors = [
                "//button",
                "//input[@type='button']",
                "//input[@type='submit']",
                "//a[contains(@class, 'btn')]"
            ]
            for selector in button_selectors:
                try:
                    elements = self.driver.find_elements(By.XPATH, selector)
                    for elem in elements:
                        if elem.is_displayed():
                            texto = elem.text or elem.get_attribute('value') or elem.get_attribute('title') or ''
                            
                            if texto.strip():
                                boton_info = {
                                    'texto': texto.strip(),
                                    'tag': elem.tag_name,
                                    'tipo': elem.get_attribute('type') or '',
                                    'id': elem.get_attribute('id') or '',
                                    'class': elem.get_attribute('class') or '',
                                    'name': elem.get_attribute('name') or '',
                                    'onclick': elem.get_attribute('onclick') or '',
                                    'href': elem.get_attribute('href') or '',
                                    'habilitado': elem.is_enabled(),
                                    'color_clase': self.detectar_color_boton(elem)
                                }                   
                                botones_accion.append(boton_info)
                except Exception as e:
                    continue
        except Exception as e:
            print(f"Error extrayendo botones de acción: {str(e)}")
        return botones_accion
    def extraer_botones_archivo(self):
        """Extrae botones de selección de archivos"""
        botones_archivo = []
        try:
            file_inputs = self.driver.find_elements(By.CSS_SELECTOR, "input[type='file']")
            for i, file_input in enumerate(file_inputs):
                try:
                    if file_input.is_displayed():
                        boton_info = {
                            'indice': i,
                            'id': file_input.get_attribute('id') or '',
                            'name': file_input.get_attribute('name') or '',
                            'class': file_input.get_attribute('class') or '',
                            'accept': file_input.get_attribute('accept') or '',
                            'multiple': bool(file_input.get_attribute('multiple')),
                            'required': bool(file_input.get_attribute('required')),
                            'habilitado': file_input.is_enabled(),
                            'etiqueta_asociada': self.buscar_etiqueta_asociada(file_input)
                        }
                        botones_archivo.append(boton_info)
                except Exception as e:
                    print(f"Error procesando botón de archivo {i}: {str(e)}")
        except Exception as e:
            print(f"Error extrayendo botones de archivo: {str(e)}")
        return botones_archivo
    def extraer_etiquetas_campos(self):
        """Extrae todas las etiquetas de campos del formulario"""
        etiquetas = []
        try:
            label_selectors = [
                "//label",
                "//td[contains(@class, 'label') or position()=1]",
                "//th",
                "//span[contains(@class, 'label')]"
            ]
            for selector in label_selectors:
                try:
                    elements = self.driver.find_elements(By.XPATH, selector)
                    for elem in elements:
                        texto = elem.text.strip()
                        if texto and len(texto) > 1 and texto != ':':
                            etiqueta_info = {
                                'texto': texto,
                                'tag': elem.tag_name,
                                'id': elem.get_attribute('id') or '',
                                'class': elem.get_attribute('class') or '',
                                'for': elem.get_attribute('for') or '',
                                'posicion': elem.location
                            }
                            etiquetas.append(etiqueta_info)
                except:
                    continue       
        except Exception as e:
            print(f"Error extrayendo etiquetas: {str(e)}")
        return etiquetas
    def extraer_valores_actuales(self):
        """Extrae los valores actuales de todos los campos"""
        valores = {}
        try:
            # Valores de inputs
            inputs = self.driver.find_elements(By.TAG_NAME, 'input')
            for inp in inputs:
                try:
                    name = inp.get_attribute('name')
                    value = inp.get_attribute('value')
                    if name and value:
                        valores[name] = value
                except:
                    continue
            # Valores seleccionados en dropdowns
            selects = self.driver.find_elements(By.TAG_NAME, 'select')
            for sel in selects:
                try:
                    name = sel.get_attribute('name')
                    if name:
                        selected_option = sel.find_element(By.CSS_SELECTOR, 'option:checked')
                        valores[name] = selected_option.text
                except:
                    continue             
        except Exception as e:
            print(f"Error extrayendo valores actuales: {str(e)}")
        return valores
    def extraer_elementos_interactivos(self):
        """Extrae todos los elementos con los que se puede interactuar"""
        elementos = []
        try:
            interactive_selectors = [
                "//input", "//select", "//button", "//a", "//textarea"
            ]
            for selector in interactive_selectors:
                try:
                    elements = self.driver.find_elements(By.XPATH, selector)
                    for elem in elements:
                        if elem.is_displayed():
                            elemento_info = {
                                'tag': elem.tag_name,
                                'tipo': elem.get_attribute('type') or '',
                                'id': elem.get_attribute('id') or '',
                                'name': elem.get_attribute('name') or '',
                                'class': elem.get_attribute('class') or '',
                                'texto': elem.text or elem.get_attribute('value') or '',
                                'habilitado': elem.is_enabled(),
                                'posicion': elem.location,
                                'tamaño': elem.size
                            }
                            elementos.append(elemento_info)
                except:
                    continue       
        except Exception as e:
            print(f"Error extrayendo elementos interactivos: {str(e)}")
        return elementos
    def analizar_estructura_formulario(self):
        """Analiza la estructura general del formulario"""
        estructura = {}
        try:
            # Buscar formularios
            forms = self.driver.find_elements(By.TAG_NAME, 'form')
            estructura['numero_formularios'] = len(forms)
            # Buscar tablas (estructura común en páginas gubernamentales)
            tables = self.driver.find_elements(By.TAG_NAME, 'table')
            estructura['numero_tablas'] = len(tables)
            # Contar elementos por tipo
            estructura['elementos_por_tipo'] = {
                'inputs': len(self.driver.find_elements(By.TAG_NAME, 'input')),
                'selects': len(self.driver.find_elements(By.TAG_NAME, 'select')),
                'buttons': len(self.driver.find_elements(By.TAG_NAME, 'button')),
                'textareas': len(self.driver.find_elements(By.TAG_NAME, 'textarea'))
            }
            # Detectar si usa Bootstrap u otro framework
            if self.driver.find_elements(By.CSS_SELECTOR, '[class*="bootstrap"], [class*="btn"], [class*="form-"]'):
                estructura['framework_css'] = 'Bootstrap detectado'
            else:
                estructura['framework_css'] = 'Framework personalizado o nativo'   
        except Exception as e:
            print(f"Error analizando estructura: {str(e)}")
        return estructura
    def buscar_etiqueta_asociada(self, element):
        """Busca la etiqueta asociada a un elemento"""
        try:
            # Buscar en la celda anterior (estructura de tabla)
            parent_td = element.find_element(By.XPATH, './ancestor::td[1]')
            prev_td = parent_td.find_element(By.XPATH, './preceding-sibling::td[1]')
            return prev_td.text.strip()
        except:
            try:
                # Buscar label con atributo 'for'
                element_id = element.get_attribute('id')
                if element_id:
                    label = self.driver.find_element(By.CSS_SELECTOR, f'label[for="{element_id}"]')
                    return label.text.strip()
            except:
                try:
                    # Buscar en elementos anteriores
                    prev_elements = element.find_elements(By.XPATH, './preceding-sibling::*')
                    for prev in reversed(prev_elements[-3:]):  # Últimos 3 elementos anteriores
                        text = prev.text.strip()
                        if text and ':' in text:
                            return text
                except:
                    pass
        return "Sin etiqueta"
    
    def detectar_color_boton(self, element):
        """Detecta el color o clase de un botón"""
        try:
            class_attr = element.get_attribute('class') or ''
            style_attr = element.get_attribute('style') or ''
            # Detectar clases comunes de colores
            if 'success' in class_attr or 'green' in class_attr:
                return 'Verde/Success'
            elif 'danger' in class_attr or 'red' in class_attr:
                return 'Rojo/Danger'
            elif 'warning' in class_attr or 'yellow' in class_attr:
                return 'Amarillo/Warning'
            elif 'primary' in class_attr or 'blue' in class_attr:
                return 'Azul/Primary'
            elif 'background' in style_attr or 'color' in style_attr:
                return 'Color personalizado'
            else:
                return 'Color por defecto'
        except:
            return 'No determinado'
    
    def guardar_informacion(self, informacion):
        """Guarda la información extraída en archivos JSON y texto"""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            # Guardar en JSON
            archivo_json = f"sunat_info_{timestamp}.json"
            with open(archivo_json, 'w', encoding='utf-8') as f:
                json.dump(informacion, f, indent=2, ensure_ascii=False)
            
            # Crear resumen en texto plano
            archivo_txt = f"sunat_resumen_{timestamp}.txt"
            with open(archivo_txt, 'w', encoding='utf-8') as f:
                f.write("ANÁLISIS DETALLADO - REGISTRO MANUAL DE PEDIDO DE NOTIFICACIÓN\n")
                f.write("=" * 70 + "\n\n")
                f.write(f"Fecha/Hora: {informacion['timestamp']}\n")
                f.write(f"URL: {informacion['url_actual']}\n")
                f.write(f"Título página: {informacion['titulo_pagina']}\n")
                f.write(f"Título sección: {informacion.get('titulo_seccion', 'N/A')}\n\n")
                
                # Campos específicos del formulario
                f.write(f"CAMPOS ESPECÍFICOS DEL FORMULARIO ({len(informacion.get('campos_formulario', []))}):\n")
                f.write("-" * 50 + "\n")
                for i, campo in enumerate(informacion.get('campos_formulario', []), 1):
                    f.write(f"{i}. {campo['etiqueta']}\n")
                    f.write(f"   Tipo: {campo['tipo'].upper()}\n")
                    f.write(f"   ID: {campo.get('id', 'N/A')}\n")
                    f.write(f"   Valor actual: {campo.get('value', 'Vacío')}\n")
                    f.write(f"   Habilitado: {'Sí' if not campo.get('disabled', False) else 'No'}\n")
                    if campo.get('opciones'):
                        f.write(f"   Opciones disponibles: {len(campo['opciones'])}\n")
                    f.write("\n")
                
                # Dropdowns detallados
                f.write(f"DROPDOWNS/SELECTORES ({len(informacion.get('dropdowns', []))}):\n")
                f.write("-" * 40 + "\n")
                for i, dropdown in enumerate(informacion.get('dropdowns', []), 1):
                    f.write(f"{i}. {dropdown.get('etiqueta_asociada', 'Sin etiqueta')}\n")
                    f.write(f"   ID/Name: {dropdown.get('id', dropdown.get('name', 'N/A'))}\n")
                    f.write(f"   Opciones: {dropdown.get('total_opciones', 0)}\n")
                    f.write(f"   Seleccionado: {dropdown.get('opcion_seleccionada', 'Ninguna')}\n")
                    f.write(f"   Todas las opciones:\n")
                    for opt in dropdown.get('todas_las_opciones', [])[:10]:  # Primeras 10
                        selected = " (SELECCIONADO)" if opt.get('selected') else ""
                        f.write(f"     - {opt.get('text', '')} {selected}\n")
                    if dropdown.get('total_opciones', 0) > 10:
                        f.write(f"     ... y {dropdown.get('total_opciones') - 10} más\n")
                    f.write("\n")
                
                # Campos de texto
                f.write(f"CAMPOS DE TEXTO ({len(informacion.get('campos_texto', []))}):\n")
                f.write("-" * 35 + "\n")
                for i, campo in enumerate(informacion.get('campos_texto', []), 1):
                    f.write(f"{i}. {campo.get('etiqueta_asociada', 'Sin etiqueta')}\n")
                    f.write(f"   Tipo: {campo.get('tipo', 'text').upper()}\n")
                    f.write(f"   ID/Name: {campo.get('id', campo.get('name', 'N/A'))}\n")
                    f.write(f"   Valor: {campo.get('value', 'Vacío')}\n")
                    f.write(f"   Solo lectura: {'Sí' if campo.get('readonly') else 'No'}\n")
                    f.write(f"   Requerido: {'Sí' if campo.get('required') else 'No'}\n\n")
                
                # Botones de acción
                f.write(f"BOTONES DE ACCIÓN ({len(informacion.get('botones_accion', []))}):\n")
                f.write("-" * 35 + "\n")
                for i, boton in enumerate(informacion.get('botones_accion', []), 1):
                    f.write(f"{i}. \"{boton.get('texto', 'Sin texto')}\"\n")
                    f.write(f"   Tipo: {boton.get('tag', 'N/A')} ({boton.get('tipo', 'N/A')})\n")
                    f.write(f"   Color/Estilo: {boton.get('color_clase', 'N/A')}\n")
                    f.write(f"   ID: {boton.get('id', 'N/A')}\n")
                    f.write(f"   Habilitado: {'Sí' if boton.get('habilitado') else 'No'}\n\n")
                
                # Botones de archivo
                f.write(f"BOTONES DE ARCHIVO ({len(informacion.get('botones_archivo', []))}):\n")
                f.write("-" * 35 + "\n")
                for i, boton in enumerate(informacion.get('botones_archivo', []), 1):
                    f.write(f"{i}. {boton.get('etiqueta_asociada', 'Seleccionar archivo')}\n")
                    f.write(f"   ID/Name: {boton.get('id', boton.get('name', 'N/A'))}\n")
                    f.write(f"   Acepta: {boton.get('accept', 'Cualquier archivo')}\n")
                    f.write(f"   Múltiples: {'Sí' if boton.get('multiple') else 'No'}\n\n")
                
                # Valores actuales
                f.write("VALORES ACTUALES DE CAMPOS:\n")
                f.write("-" * 30 + "\n")
                for campo, valor in informacion.get('valores_actuales', {}).items():
                    f.write(f"• {campo}: {valor}\n")
                
                # Estructura del formulario
                f.write(f"\nESTRUCTURA DEL FORMULARIO:\n")
                f.write("-" * 30 + "\n")
                estructura = informacion.get('estructura_formulario', {})
                f.write(f"Formularios: {estructura.get('numero_formularios', 0)}\n")
                f.write(f"Tablas: {estructura.get('numero_tablas', 0)}\n")
                f.write(f"Framework CSS: {estructura.get('framework_css', 'No detectado')}\n")
                elementos = estructura.get('elementos_por_tipo', {})
                for tipo, cantidad in elementos.items():
                    f.write(f"{tipo.capitalize()}: {cantidad}\n")
            
            print(f" Información guardada en:")
            print(f"  - {archivo_json}")
            print(f"  - {archivo_txt}")
            
        except Exception as e:
            print(f" Error guardando información: {str(e)}")
    
    def cerrar(self):
        """Cierra el navegador"""
        if self.driver:
            self.driver.quit()
            print(" Navegador cerrado")
    
    def ejecutar_proceso_completo(self):
        """Ejecuta el proceso completo de automatización"""
        try:
            print(" Iniciando bot de SUNAT...")
            print("=" * 50)
            
            # Paso 1: Leer credenciales
            if not self.leer_credenciales():
                return False
            
            # Paso 2: Configurar navegador
            if not self.configurar_navegador():
                return False
            
            # Paso 3: Realizar login
            if not self.realizar_login():
                return False
            
            # Paso 4: Navegar directamente al Sistema de Notificaciones
            if not self.navegar_a_sistema_notificaciones():
                return False
            
            # Paso 5: Navegar dentro del sistema hacia Seguimiento
            if not self.navegar_en_sistema_notificaciones():
                return False
            
            # Paso 6: Acceder al Registro Manual de Pedido de Notificación
            if not self.acceder_registro_manual():
                return False
            
            # Paso 7: Verificar que estamos en la página correcta
            if not self.verificar_pagina_registro_manual():
                return False
            
            # Paso 8: Extraer información
            informacion = self.extraer_informacion_completa()
            if informacion:
                self.guardar_informacion(informacion)
                print("🎉 Proceso completado exitosamente!")
                return True
            else:
                print(" No se pudo extraer la información")
                return False
                
        except Exception as e:
            print(f" Error en el proceso: {str(e)}")
            return False
        finally:
            # Mantener el navegador abierto por 10 segundos para verificación
            print(" Manteniendo navegador abierto por 10 segundos para verificación...")
            time.sleep(10)
            self.cerrar()

def main():
    """Función principal"""
    bot = SUNATBot()
    bot.ejecutar_proceso_completo()

if __name__ == "__main__":
    main()