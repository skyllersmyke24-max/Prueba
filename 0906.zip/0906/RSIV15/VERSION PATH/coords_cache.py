
import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict


class CoordsCache:
    
    def __init__(self, cache_path: Optional[Path] = None):

        self.cache_path = cache_path
        self.cache = {}
        if self.cache_path:
            self.load_from_json()
    
    def get(self, element_name: str, dependencia: str) -> Optional[Dict]:
        try:
            dep_key = f"dep_{dependencia}"
            
            # Intento 1: Buscar en memoria
            if dep_key in self.cache and element_name in self.cache[dep_key]:
                return self.cache[dep_key][element_name]
            if self.cache_path:
                self.load_from_json()  # Recargar desde DISK
                if dep_key in self.cache and element_name in self.cache[dep_key]:
                    return self.cache[dep_key][element_name]
        
        except Exception:
            pass
        
        return None
    
    def set(self, element_name: str, dependencia: str, x: int, y: int) -> None:

        dep_key = f"dep_{dependencia}"
        
        if dep_key not in self.cache:
            self.cache[dep_key] = {}
        
        self.cache[dep_key][element_name] = {
            "x": x,
            "y": y,
            "timestamp": datetime.now().isoformat(),
            "success_count": 1
        }
        
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando coords: {e}")
    
    def increment_success(self, element_name: str, dependencia: str) -> None:
  
        dep_key = f"dep_{dependencia}"
        if dep_key in self.cache and element_name in self.cache[dep_key]:
            self.cache[dep_key][element_name]["success_count"] = \
                self.cache[dep_key][element_name].get("success_count", 0) + 1
            
            # AUTOGUARDADO EN DISK (fuente única de verdad)
            if self.cache_path:
                try:
                    self.save_to_json(self.cache_path)
                except Exception as e:
                    print(f"[CACHÉ] Error autoguardando success_count: {e}")
    
    def clear_by_dependencia(self, dependencia: str) -> None:

        dep_key = f"dep_{dependencia}"
        if dep_key in self.cache:
            del self.cache[dep_key]
        
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando al limpiar dependencia: {e}")
    
    def clear_all(self) -> None:

        self.cache = {}
        if self.cache_path:
            try:
                self.save_to_json(self.cache_path)
            except Exception as e:
                print(f"[CACHÉ] Error autoguardando al limpiar todo: {e}")
    
    def save_to_json(self, path: Path) -> None:

        try:
            path = Path(path)  # Convertir a Path si viene como string
            
            path.parent.mkdir(parents=True, exist_ok=True)
            
            temp_path = Path(str(path) + ".tmp")
            with open(temp_path, 'w', encoding='utf-8') as f:
                json.dump(self.cache, f, indent=2, default=str)
            
            temp_path.replace(path)
            
        except Exception as e:
            print(f"[CACHÉ] Error guardando JSON en {path}: {e}")
    
    def load_from_json(self) -> None:
        try:
            if self.cache_path:
                cache_path = Path(self.cache_path)
                if cache_path.exists():
                    with open(cache_path, 'r', encoding='utf-8') as f:
                        loaded_cache = json.load(f)
                        self.cache.update(loaded_cache)
        except json.JSONDecodeError as e:
            print(f"[CACHÉ] JSON corrupto en {self.cache_path}: {e}")
            print(f"[CACHÉ] Comenzando con caché vacío")
            self.cache = {}
        except Exception as e:
            print(f"[CACHÉ] Error cargando desde {self.cache_path}: {e}")
