
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Dict, Callable, Optional
import logging
import pandas as pd
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app_driver import AppDriver


# ENUMS Y DATACLASSES
class Outcome(Enum):
    OK_RC = auto()                          # Éxito: RC grabada
    SKIP_EXP_INVALIDO = auto()              # Expediente inválido en RSIRAT
    SKIP_INTERVENTOR_INVALIDO = auto()      # Código de interventor inválido (IEI)
    SKIP_MONTO_MAYOR = auto()               # Monto excede saldo (DSE)
    FAIL_LOGIN_PASSWORD = auto()             # Contraseña incorrecta (crítico)
    FAIL_UI = auto()                        # Error UI inesperado
    SKIP_DATA_INCOMPLETE = auto()            # Datos incompletos en Excel


def outcome_to_label(outcome: Outcome) -> str:
    mapping = {
        Outcome.OK_RC: "OK_RC",
        Outcome.SKIP_EXP_INVALIDO: "EXP INVALIDO",
        Outcome.SKIP_INTERVENTOR_INVALIDO: "INTERVENTOR INVALIDO",
        Outcome.SKIP_MONTO_MAYOR: "MONTO MAYOR",
        Outcome.SKIP_DATA_INCOMPLETE: "DATOS INCOMPLETOS",
        Outcome.FAIL_LOGIN_PASSWORD: "CONTRASEÑA INCORRECTA",
        Outcome.FAIL_UI: "FAIL_UI",
    }
    return mapping.get(outcome, outcome.name)


@dataclass
class ContextoExpediente:
    expediente: str
    row_idx: int
    dependencia: str
    tipo_medida: str  # "IEI" o "DSE"
    interventor: Optional[str] = None
    plazo: Optional[int] = None
    monto: Optional[float] = None


@dataclass
class ProcessOutcome:
    expediente: str
    row_idx: int
    dependencia: str
    outcome: Outcome
    rc_number: Optional[str] = None
    reason: str = ""
    error_detail: str = ""

def validate_expediente_row(row: pd.Series, row_idx: int) -> tuple[bool, str]:

    dependencia = str(row.get("DEPENDENCIA", "")).strip()
    tipo = str(row.get("MEDIDA", "")).strip().upper()
    interventor = str(row.get("INTERVENTOR", "")).strip()
    plazo = str(row.get("PLAZO", "")).strip()
    monto = str(row.get("MONTO", "")).strip()
    
    # Validar DEPENDENCIA
    if not dependencia or dependencia == "nan":
        return False, "Falta DEPENDENCIA"
    
    # Validar MEDIDA
    if not tipo or tipo == "NAN":
        return False, "Falta MEDIDA"
    
    if tipo not in ["IEI", "DSE"]:
        return False, f"MEDIDA debe ser IEI o DSE, encontrado: {tipo}"
    
    # Validar según tipo
    if "IEI" in tipo:
        if not interventor or interventor == "nan":
            return False, "IEI requiere INTERVENTOR"
        if not plazo or plazo == "nan":
            return False, "IEI requiere PLAZO"
    
    elif "DSE" in tipo:
        if not monto or monto == "nan":
            return False, "DSE requiere MONTO"
    
    return True, ""


def process_dependency(
    dependencia: str,
    indices: List[int],
    df: pd.DataFrame,
    driver: "AppDriver",
    update_result_fn: Callable,
    is_first: bool,
    is_last: bool,
    logger: logging.Logger,
    password: str
) -> List[ProcessOutcome]:

    outcomes = []
    has_active_expediente = False
    
    logger.info(f"Iniciando procesamiento de {len(indices)} expediente(s)...")
    
    if is_first:
        logger.info("Abriendo aplicación...")
        if not driver.open_app():
            logger.error("   No se pudo abrir la aplicación")
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo abrir aplicación"
                ))
            return outcomes
        
        login_outcome = driver.login(dependencia, password)
        if login_outcome != Outcome.OK_RC:
            logger.error(f"   Login falló: {login_outcome.name}")
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=login_outcome,
                    reason="Fallo en login"
                ))

            try:
                if login_outcome == Outcome.FAIL_LOGIN_PASSWORD and len(indices) > 0:
                    first_row = indices[0]
                    update_result_fn(first_row, "CONTRASEÑA INCORRECTA")
            except Exception as e:
                logger.warning(f"No se pudo actualizar Excel (primer fila) por fallo de login: {e}")

            return outcomes
        
        logger.info("   Login exitoso")
        
        logger.info("[NAV] Navegando a módulo base...")
        if not driver.navigate_to_module():
            logger.error("   No se pudo navegar al módulo")
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo navegar al módulo"
                ))
            return outcomes
        
        logger.info("   Módulo listo")
    
    for pos, row_idx in enumerate(indices, 1):
        logger.info(f"\n[EXP {pos}/{len(indices)}] Procesando fila {row_idx + 1}...")
        
        row = df.iloc[row_idx]
        expediente = str(row["EXPEDIENTE"]).strip()
        
        is_valid, error_msg = validate_expediente_row(row, row_idx)
        if not is_valid:
            logger.warning(f"   Datos incompletos: {error_msg}")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.SKIP_DATA_INCOMPLETE,
                reason=error_msg
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, error_msg)
            continue
        
        interventor_val = None
        if "INTERVENTOR" in row.index:
            iv_raw = row.get("INTERVENTOR", "")
            if pd.notna(iv_raw):
                s_iv = str(iv_raw).strip()
                if s_iv != "":
                    interventor_val = s_iv

        plazo_val = None
        if "PLAZO" in row.index:
            raw_plazo = row["PLAZO"]
            if pd.notna(raw_plazo):
                s_plazo = str(raw_plazo).strip()
                if s_plazo != "":
                    try:
                        plazo_val = int(float(s_plazo))
                    except Exception:
                        plazo_val = None

        monto_val = None
        if "MONTO" in row.index:
            raw_monto = row["MONTO"]
            if pd.notna(raw_monto):
                s_monto = str(raw_monto).strip()
                if s_monto != "":
                    try:
                        monto_val = float(s_monto)
                    except Exception:
                        monto_val = None

        ctx = ContextoExpediente(
            expediente=expediente,
            row_idx=row_idx,
            dependencia=dependencia,
            tipo_medida=str(row["MEDIDA"]).strip().upper(),
            interventor=interventor_val,
            plazo=plazo_val,
            monto=monto_val
        )
        if pos > 1 and has_active_expediente:  # pos > 1 = 2° expediente; has_active_expediente = anterior fue válido
            logger.info(f"  Preparando pantalla para expediente siguiente (mismo dep)...")
            if not driver.reset_to_individual_form(dependencia=dependencia):
                logger.error(f"    No se pudo resetear pantalla para siguiente expediente")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo resetear pantalla (no se encontró Exp. Individual)"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_RESET_MENU")
                continue
            logger.info(f"   Pantalla reseteada correctamente")
        
        # -------- Ingresar expediente --------
        logger.info(f"  Ingresando expediente inicial...")
        outcome, rc = driver.enter_expediente_initial(ctx.expediente)
        
        # -------- Procesar resultado de ingreso de expediente --------
        if outcome == Outcome.OK_RC:
            logger.info(f"   Expediente válido encontrado")
        else:
            # El expediente no fue válido (SKIP_EXP_INVALIDO u otro error)
            logger.info(f"   Expediente fue rechazado")
            has_active_expediente = False
        
        # IMPORTANTE: Si expediente fue validado (OK_RC), enviar Alt+A para continuar con embargo
        # Alt+A acepta el expediente y permite continuar al siguiente paso (Trabar Embargo)
        if outcome == Outcome.OK_RC:
            logger.info(f"  Enviando Alt+A para aceptar expediente y continuar...")
            import pyautogui
            import time as time_module
            pyautogui.hotkey('alt', 'a')
            time_module.sleep(1.5)  # Tiempo para que app procese el cambio
            
            logger.info(f"  Enfocando ventana SIRAT...")
            t0_enfoque = time_module.time()
            driver.ensure_sirat_focus()
            t1_enfoque = time_module.time()
            logger.info(f"  [TIMER] ensure_sirat_focus() completó en {t1_enfoque - t0_enfoque:.3f}s")
            time_module.sleep(0.3)
            
            logger.info(f"  Navegando a 'Trabar Embargo'...")
            if not driver.go_to_trabar_embargo():
                logger.error("   No se pudo navegar a Trabar Embargo")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo navegar a Trabar Embargo"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_EMBARGO_NAV")
                has_active_expediente = False  
                continue
            
            logger.info(f"   Seleccionando tipo de medida: {ctx.tipo_medida}...")
            select_result = driver.select_embargo_type(ctx.tipo_medida, dependencia=dependencia)
            logger.info(f"      Resultado select_embargo_type: {select_result}")
            
            if not select_result:
                logger.error(f"    No se pudo seleccionar tipo {ctx.tipo_medida}")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason=f"No se pudo seleccionar tipo {ctx.tipo_medida}"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, f"FAIL_{ctx.tipo_medida}_SELECT")
                has_active_expediente = False  # Resetear para siguiente expediente
                continue
            
            logger.info(f"      Tipo {ctx.tipo_medida} seleccionado correctamente")
            
            has_active_expediente = True
            logger.info(f"  has_active_expediente establecida a TRUE")
            
            logger.info(f"  Presionando ENTER para confirmar tipo de medida y renderizar campo...")
            pyautogui.press('return')
            time_module.sleep(1)  # Timeout de 1s para renderizado
            logger.info(f"  ENTER presionado y campo listo para datos")
        
        if outcome == Outcome.SKIP_EXP_INVALIDO:
            logger.warning(f"   Expediente inválido")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome,
                reason="Expediente no válido en RSIRAT"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, "EXP_INVALIDO")
            has_active_expediente = False
            continue
        
        if outcome != Outcome.OK_RC or not has_active_expediente:
            # Error inesperado - debugging detallado
            logger.error(f"    ERROR AL INGRESAR EXPEDIENTE - DEBUG INFO:")
            logger.error(f"      - outcome: {outcome}")
            logger.error(f"      - outcome == OK_RC: {outcome == Outcome.OK_RC}")
            logger.error(f"      - has_active_expediente: {has_active_expediente}")
            logger.error(f"      - tipo_medida: {ctx.tipo_medida}")
            logger.error(f"      - expediente: {expediente}")
            logger.error(f"      - Razón: {'outcome no es OK_RC' if outcome != Outcome.OK_RC else 'no hay expediente activo'}")
            
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome if outcome else Outcome.FAIL_UI,
                reason="Error al ingresar expediente"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome))
            has_active_expediente = False  # Resetear para siguiente expediente
            continue
        
        # -------- Procesar según tipo --------
        logger.info(f"   PROCESANDO EXPEDIENTE: {ctx.tipo_medida}")
        logger.info(f"     - Expediente: {expediente}")
        logger.info(f"     - Dependencia: {dependencia}")
        logger.info(f"     - Fila: {row_idx}")
        
        if "IEI" in ctx.tipo_medida:
            logger.info(f"   Ejecutando process_iei()...")
            outcome_obj = process_iei(ctx, driver, logger)
            logger.info(f"   process_iei() retornó: {outcome_obj.outcome} | RC: {outcome_obj.rc_number}")
        elif "DSE" in ctx.tipo_medida:
            logger.info(f"   Ejecutando process_dse()...")
            outcome_obj = process_dse(ctx, driver, logger)
            logger.info(f"   process_dse() retornó: {outcome_obj.outcome} | RC: {outcome_obj.rc_number}")
        else:
            logger.error(f"   Tipo desconocido: {ctx.tipo_medida}")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.FAIL_UI,
                reason=f"Tipo desconocido: {ctx.tipo_medida}"
            )
        
        outcomes.append(outcome_obj)
        
        # Actualizar Excel
        if outcome_obj.outcome == Outcome.OK_RC and outcome_obj.rc_number:
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome), outcome_obj.rc_number)
            logger.info(f"   RC guardada: {outcome_obj.rc_number}")
        else:
            update_result_fn(row_idx, outcome_to_label(outcome_obj.outcome))
            logger.warning(f"   {outcome_to_label(outcome_obj.outcome)}: {outcome_obj.reason}")
        
        
    # -------- FASE 3: Cerrar app (solo si es última dependencia) --------
    if is_last:
        logger.info("\n[CLOSE] Cerrando aplicación...")
        driver.close_app()
        logger.info("   Aplicación cerrada")
    
    logger.info(f"\nDependencia {dependencia} completada: {len(outcomes)} expediente(s) procesado(s)")
    return outcomes


# PROCESOS ESPECÍFICOS POR TIPO
def process_iei(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:
    logger.info(f"  [IEI]  INICIANDO PROCESO IEI")
    logger.info(f"       - Expediente: {ctx.expediente}")
    logger.info(f"       - Interventor: {ctx.interventor}")
    logger.info(f"       - Plazo: {ctx.plazo}")
    
    # 1. Ingresar INTERVENTOR
    logger.info(f"  [IEI] PASO 1: Ingresando INTERVENTOR = '{ctx.interventor}'...")
    outcome_int = driver.iei_enter_interventor(ctx.interventor)
    if outcome_int != Outcome.OK_RC:
        logger.error(f"        INTERVENTOR FALLÓ: {outcome_int.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_int,
            reason="Código de interventor inválido"
        )
    logger.info(f"        INTERVENTOR ingresado correctamente")
    
    # 2. Ingresar PLAZO y confirmar
    logger.info(f"  [IEI] PASO 2: Ingresando PLAZO = {ctx.plazo}...")
    outcome_plazo, rc = driver.iei_set_plazo_and_confirm(ctx.plazo)
    if outcome_plazo != Outcome.OK_RC:
        logger.error(f"        PLAZO FALLÓ: {outcome_plazo.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_plazo,
            reason="Error al setear plazo o confirmar RC"
        )
    logger.info(f"        PLAZO ingresado y confirmado")
    
    logger.info(f"  [IEI]  Completado exitosamente con RC={rc}")
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="IEI completado exitosamente"
    )


def process_dse(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:

    logger.info(f"  [DSE]  INICIANDO PROCESO DSE")
    logger.info(f"       - Expediente: {ctx.expediente}")
    logger.info(f"       - Monto: {ctx.monto}")
    logger.info(f"  [DSE] Iniciando proceso...")
    
    # 1. Ingresar MONTO y confirmar
    logger.info(f"  [DSE] PASO 1: Ingresando MONTO = {ctx.monto}...")
    outcome_monto, rc = driver.dse_set_monto_and_confirm(ctx.monto)
    logger.info(f"       dse_set_monto_and_confirm() retornó: outcome={outcome_monto.name}, rc={rc}")
    
    if outcome_monto == Outcome.SKIP_MONTO_MAYOR:
        logger.warning(f"        MONTO RECHAZADO: Excede saldo disponible")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Monto excede saldo disponible o límites permitidos"
        )
    
    if outcome_monto != Outcome.OK_RC:
        logger.error(f"        ERROR EN MONTO: {outcome_monto.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Error al procesar monto"
        )
    
    logger.info(f"        MONTO ingresado correctamente")
    logger.info(f"  [DSE]  Completado exitosamente con RC={rc}")
    
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="DSE completado exitosamente"
    )
