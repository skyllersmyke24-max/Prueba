
import time
import logging
import os
import re
import ctypes
from pathlib import Path
from typing import Optional, Tuple

import pyautogui
import cv2
import numpy as np
from PIL import ImageGrab
from pywinauto import Application, Desktop, findwindows

from logica import Outcome
from coords_cache import CoordsCache


# CONSTANTES Y SELECTORES
RSIRAT_WINDOW_PATTERNS = [
    "SIRAT"
]
RSIRAT_WAIT_TIMEOUT = 30
UI_WAIT_SMALL = 0.5
UI_WAIT_MEDIUM = 1.0
UI_WAIT_LARGE = 2.0
DETECT_TIMEOUT = 2.0
MSAA_BACKEND = "uia"


# APP DRIVER CLASS
class AppDriver:
    
    def __init__(self, logger: logging.Logger, shortcut_path: Path, img_dir: Path = None, cache_path: Path = None):
        self.logger = logger
        self.shortcut_path = shortcut_path
        self.img_dir = img_dir
        
        self.app = None
        self.main_window = None
        self.coords_cache = CoordsCache(cache_path=cache_path)
    
    
    def find_and_fill_dependencia_field(self, dependencia: str) -> bool:
        try:
            self.logger.info("Buscando campo DEPENDENCIA usando imagen 001.png (OpenCV)...")
            
            image_path = self.img_dir / "001.png"
                        
            if not image_path.exists():
                self.logger.error(f"Imagen no encontrada: {image_path}")
                return False
                        
            template = cv2.imread(str(image_path))
            if template is None:
                self.logger.error(f"No se pudo cargar la imagen: {image_path}")
                return False
            
            template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            
            screen = np.array(ImageGrab.grab())
            screen_cv2 = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
            
            screen_gray = cv2.cvtColor(screen_cv2, cv2.COLOR_BGR2GRAY)
            
            result = cv2.matchTemplate(screen_gray, template_gray, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(result)
            
            threshold = 0.65
            if max_val >= threshold:
                self.logger.info(f" Imagen encontrada con similitud: {max_val:.2%}")
                
                # Calcular centro de la imagen
                h, w = template_gray.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                
                # Click en el campo
                self.logger.info(f"Haciendo clic en coordenadas: ({center_x}, {center_y})")
                pyautogui.click(center_x, center_y)
                time.sleep(0.3)
                
                # Limpiar campo con 15× SUPR y 15× BORRADO (BackSpace)           
                self.logger.info("Limpiando campo")
                for _ in range(25):
                    pyautogui.press('backspace')
                    time.sleep(0.01)
                
                time.sleep(0.3)
                
                # Digitar dependencia
                self.logger.info(f"Digitando dependencia: {dependencia}")
                pyautogui.write(dependencia, interval=0.01)
                time.sleep(0.3)
                
                # Presionar TAB para avanzar a contraseña
                self.logger.info("Presionando TAB para avanzar al campo contraseña...")
                pyautogui.press('tab')
                time.sleep(0.5)
                
                self.logger.info(" Campo DEPENDENCIA completado")
                return True
            else:
                self.logger.error(f"Similitud insuficiente: {max_val:.2%} (requerido: {threshold:.0%})")
                return False
                
        except Exception as e:
            self.logger.error(f"Error en find_and_fill_dependencia_field: {e}")
            return False
    
    
    def open_app(self) -> bool:
        try:
            os.startfile(str(self.shortcut_path))
            self.logger.info(f" Aplicación abierta exitosamente")
            return True
        except Exception as e:

            self.logger.error(f" Error abriendo aplicación: {e}")
            return False
    
    def close_app(self) -> bool:
        try:
            self.logger.info("[ACCIÓN] Cerrando aplicación...")
            pyautogui.hotkey('alt', 'f4')
            time.sleep(2)
            self.logger.info(" Aplicación cerrada")
            return True
        except Exception as e:
            self.logger.error(f" Error cerrando aplicación: {e}")
            return False
    
    def check_app_window_exists(self) -> bool:
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            try:
                windows = desktop.windows()
                for window in windows:
                    try:
                        title = str(window.element_info.name or "")
                        if title == "SIRAT":
                            return True
                    except Exception:
                        continue
            except Exception:
                pass
            
            self.logger.warning("[ALERTA] Ventana SIRAT NO encontrada - Aplicación posiblemente cerrada/crasheada")
            return False
        
        except Exception as e:
            self.logger.error(f"Error verificando ventana SIRAT: {e}")
            return False
    
    
    def check_and_disable_capslock(self):

        try:
            import ctypes
            capslock_state = ctypes.windll.user32.GetKeyState(0x14)
            
            if capslock_state % 2 == 1:
                self.logger.info("  Desactivando Bloq Mayús...")
                pyautogui.press('capslock')
                time.sleep(0.5)
        except Exception as e:
            self.logger.warning(f"No se pudo verificar Bloq Mayús: {e}")
    
    
    def ensure_sirat_focus(self):
        try:
            if self.app is not None:
                try:
                    if self.app.exists():
                        self.app.set_focus()
                        self.logger.debug("[ensure_sirat_focus] Cache válido, ventana enfocada")
                        self.logger.info("[ESTRATEGIA 1 FUNCIONÓ] Cache local válido - ventana enfocada")
                    return self.app
                except Exception:
                    self.app = None  # Invalidar cache si falla
                    self.logger.debug("[ESTRATEGIA 1 FALLÓ] Cache inválido")
            
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.window(title="SIRAT")
                if app and app.exists(timeout=1):
                    app.set_focus()
                    self.app = app  # Actualizar cache
                    self.logger.debug("[ensure_sirat_focus] Ventana SIRAT encontrada por título exacto")
                    self.logger.info("[ESTRATEGIA 2 FUNCIONÓ] Ventana encontrada por título exacto - enfocada")
                    return app
            except Exception:
                self.logger.debug("[ESTRATEGIA 2 FALLÓ] No se encontró ventana por título exacto")
                pass
            
            try:
                desktop = Desktop(backend=MSAA_BACKEND)
                app = desktop.active()
                if app:
                    title = app.window_title().lower()
                    # Validar que sea SIRAT (por título o clase)
                    if "sirat" in title or "rsirat" in title or "cobranza" in title:
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana activa validada como SIRAT: '{title}'")
                        self.logger.info(f"[ESTRATEGIA 3 FUNCIONÓ] Ventana activa validada ('{title}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ESTRATEGIA 3 FALLÓ] No se validó ventana activa como SIRAT")
                pass
            
            try:
                for pattern in RSIRAT_WINDOW_PATTERNS:
                    windows = findwindows.find_windows(title_re=f".*{pattern}.*")
                    if windows:
                        app = Application(backend=MSAA_BACKEND).connect(
                            handle=windows[0]
                        ).top_window()
                        app.set_focus()
                        self.app = app
                        self.logger.debug(f"[ensure_sirat_focus] Ventana encontrada por patrón '{pattern}'")
                        self.logger.info(f"[ESTRATEGIA 4 FUNCIONÓ] Ventana encontrada por patrón ('{pattern}') - enfocada")
                        return app
            except Exception:
                self.logger.debug("[ESTRATEGIA 4 FALLÓ] No se encontró ventana por patrón")
                pass
            
            self.logger.error("[ensure_sirat_focus] No se pudo encontrar/enfocar ventana SIRAT después de 4 intentos")
            self.app = None
            return None
        
        except Exception as e:
            self.logger.error(f"[ensure_sirat_focus] Error general: {e}")
            self.app = None
            return None
    
    def find_sirat_window(self):
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            sirat_window = desktop.window(title="SIRAT")
            
            if sirat_window.exists(timeout=1):
                return sirat_window
            
            return None
        
        except Exception as e:
            self.logger.debug(f"find_sirat_window() error: {e}")
            return None
    
    
    def login(self, dependencia: str, password: str) -> Outcome:
        try:
            self.logger.info("Iniciando proceso de login...")
            
            dlg = None
            
            desktop = Desktop(backend=MSAA_BACKEND)
            start_time = time.time()
            timeout = 60  
            
            while time.time() - start_time < timeout:
                try:
                    windows = desktop.windows()
                    
                    for window in windows:
                        try:
                            title = str(window.element_info.name or "")
                            if title == "SIRAT":
                                dlg = window
                                break
                        except Exception:
                            continue
                    
                    if dlg:
                        break
                    
                except Exception as e:
                    self.logger.debug(f"Error buscando ventana SIRAT: {e}")
                    pass
                
                time.sleep(0.5)
            
            if dlg is None:
                self.logger.error("No se pudo encontrar la ventana SIRAT después de 60 segundos")
                return Outcome.FAIL_UI
            
            time.sleep(1)
            
            self.logger.info("Completando DEPENDENCIA...")
            
            dep_code = str(dependencia).strip()
            dep_map = {
                "21": "0021 I.R. Lima - PRICO",
                "23": "0023 I.R. Lima - MEPECO",
            }
            login_dep = dep_map.get(dep_code, dependencia)
            
            success = self.find_and_fill_dependencia_field(login_dep)
            
            if not success:
                self.logger.error("Falló llenado de DEPENDENCIA con OpenCV. Retornando FAIL_UI")
                return Outcome.FAIL_UI
            
            self.logger.info("DEPENDENCIA completada exitosamente")

            self.check_and_disable_capslock()
            
            time.sleep(0.2)  
            
            self.logger.info(f"Escribiendo contraseña")
            pyautogui.write(password, interval=0.02)
            time.sleep(0.2)
            
            self.logger.info("Presionando ENTER para confirmar login...")
            pyautogui.press('return')
            
            time.sleep(0.5)
            
            pwd_err, pwd_msg = self.detect_password_error(timeout=0.5)
            if pwd_err:
                self.logger.error(f" Contraseña incorrecta.")
                time.sleep(0.5)
                pyautogui.press('return')
                time.sleep(0.5)
                self.logger.info("  Presionando ALT+C para cancelar login y cerrar la app...")
                try:
                    pyautogui.hotkey('alt', 'c')
                except Exception:
                    pyautogui.keyDown('alt')
                    pyautogui.press('c')
                    pyautogui.keyUp('alt')
                time.sleep(1)
                self.logger.info(" Cerrando aplicación debido a credenciales inválidas")
                return Outcome.FAIL_LOGIN_PASSWORD
            
            self.logger.info(" Login completado exitosamente")
            return Outcome.OK_RC
        
        except Exception as e:
            self.logger.error(f"Error en login: {e}")
            return Outcome.FAIL_UI

    def detect_password_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "no puede ser accedido",
                                            "estimado usuario",
                                            "aplicativo",
                                            "credenciales",
                                            "error en las credenciales",
                                            "error numero"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.error(f"Mensaje de error detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_password_error: {e}")
            return False, ""

    def detect_monto_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de aviso del MONTO...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        palabras_clave = [
                                            "monto",
                                            "excede",
                                            "saldo",
                                            "expediente",
                                            "aviso",
                                            "error"
                                        ]
                                        if any(palabra in texto_lower for palabra in palabras_clave):
                                            self.logger.info(f"Mensaje de aviso detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_monto_aviso: {e}")
            return False, ""

    def detect_expediente_error(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de error de expediente...")
            desktop = Desktop(backend=MSAA_BACKEND)
            
            # Buscar ventana SIRAT primero (enfoque robusto)
            sirat_window = None
            try:
                sirat_window = desktop.window(title="SIRAT")
                if not sirat_window.exists(timeout=1):
                    sirat_window = None
            except Exception:
                sirat_window = None
            
            # Si no encuentra SIRAT, buscar todas las ventanas
            windows_to_check = [sirat_window] if sirat_window else desktop.windows()
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    for win in windows_to_check:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_lower = texto.lower()
                                        # Buscar SOLO el mensaje específico de expediente inválido
                                        # y evitar texto muy largo (falsos positivos)
                                        if len(texto) < 200 and "expediente" in texto_lower and ("válido" in texto_lower or "no es valido" in texto_lower):
                                            self.logger.warning(f"Error de expediente detectado: {texto}")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_error: {e}")
            return False, ""

    def detect_expediente_aviso(self, timeout=2):
        """
        Detecta el aviso de embargos activos en DSE.
        Patrón: "El Expediente [NUM] correspondiente al RUC [NUM] tiene [NUM] Embargos activos..."
        Los números pueden variar, busca las palabras clave.
        """
        try:
            self.logger.info("Verificando aviso de embargos activos (expediente+ruc+embargo)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    texto = str(desc.window_text() or "").strip()
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón: debe contener las 4 palabras clave
                                    # (independiente de números específicos)
                                    if ("expediente" in texto_lower and 
                                        "ruc" in texto_lower and 
                                        "embargo" in texto_lower and 
                                        "activo" in texto_lower):
                                        self.logger.info(f" Aviso embargos activos: {texto[:80]}...")
                                        return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_expediente_aviso: {e}")
            return False, ""

    def handle_dse_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en DSE que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (DSE)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_dse_embargo_aviso: {e}")
            return False

    def handle_iei_embargo_aviso(self, timeout=2) -> bool:
        """
        Detecta el aviso de embargos activos en IEI que aparece después del doble clic.
        Mensaje esperado: "El Expediente XXX correspondiente al RUC xxx tiene x Embargos activos..."
        Si se detecta, presiona Alt+S para continuar.
        
        Returns:
            True si se detectó y respondió al aviso (o no hay aviso)
            False si hay un error crítico
        """
        try:
            self.logger.info("Verificando si hay aviso de embargos activos (IEI)...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        texto_strip = texto.strip()
                                        # Búsqueda: comienza con "El Expediente" y contiene "embargo"
                                        if (texto_strip.startswith("El Expediente") and 
                                            "embargo" in texto_strip.lower() and
                                            "activo" in texto_strip.lower()):
                                            self.logger.info(f" Aviso de embargos activos detectado (IEI)")
                                            self.logger.info(f"Mensaje: {texto_strip[:100]}...")
                                            # Presionar Alt+S para continuar
                                            self.logger.info("Presionando Alt+S para continuar...")
                                            pyautogui.hotkey('alt', 's')
                                            time.sleep(1)
                                            self.logger.info(" Alt+S presionado")
                                            return True
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            
            # No se detectó aviso (es normal si no hay embargos activos)
            self.logger.info("No se detectó aviso de embargos activos (IEI)")
            return True
        
        except Exception as e:
            self.logger.error(f"Error en handle_iei_embargo_aviso: {e}")
            return False

    def extract_ruc_from_message(self, mensaje):
        try:
            self.logger.info("Extrayendo RUC del mensaje...")
            ruc_index = mensaje.upper().find("RUC")
            if ruc_index == -1:
                self.logger.warning("No se encontró 'RUC' en el mensaje")
                return ""
            texto_despues_ruc = mensaje[ruc_index + 3:].strip()
            self.logger.info(f"Texto después de 'RUC': '{texto_despues_ruc[:50]}'")
            ruc = ""
            for caracter in texto_despues_ruc:
                if caracter.isdigit():
                    ruc += caracter
                elif ruc:
                    break
            if ruc:
                self.logger.info(f" RUC extraído: {ruc}")
                return ruc
            else:
                self.logger.warning("No se encontraron dígitos después de 'RUC'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo RUC: {e}")
            return ""

    def detect_resolucion_coactiva_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje de Resolución Coactiva...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    all_windows = desktop.windows()
                    for win in all_windows:
                        try:
                            all_descendants = list(win.descendants())
                            for desc in all_descendants:
                                try:
                                    control_type = None
                                    texto = ""
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    if control_type == "Text" and texto and len(texto.strip()) > 0:
                                        if "se grabó" in texto.lower() and "resolución coactiva" in texto.lower():
                                            self.logger.warning(f" MENSAJE DE RESOLUCIÓN COACTIVA DETECTADO: {texto[:100]}...")
                                            return True, texto
                                except:
                                    pass
                        except:
                            pass
                except:
                    pass
                time.sleep(0.3)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_resolucion_coactiva_aviso: {e}")
            return False, ""

    def extract_resolucion_coactiva_number(self, mensaje):
        try:
            self.logger.info("Extrayendo número de Resolución Coactiva del mensaje...")
            numero_index = mensaje.lower().find("número")
            if numero_index == -1:
                self.logger.warning("No se encontró 'palabra 'número' en el mensaje")
                return ""
            texto_despues_numero = mensaje[numero_index + 6:].strip()
            self.logger.info(f"Texto después de 'número': '{texto_despues_numero[:50]}'")
            rc_number = ""
            for caracter in texto_despues_numero:
                if caracter.isdigit():
                    rc_number += caracter
                elif rc_number:
                    break
            if rc_number:
                self.logger.info(f" Número de RC extraído: {rc_number}")
                return rc_number
            else:
                self.logger.warning("No se encontraron dígitos después de 'número'")
                return ""
        except Exception as e:
            self.logger.error(f"Error extrayendo número de RC: {e}")
            return ""

    def detect_desea_continuar_aviso(self, timeout=2):
        try:
            self.logger.info("Verificando si hay mensaje '¿ Desea Continuar ?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    dlgs = desktop.windows()
                    for dlg in dlgs:
                        try:
                            descendants = dlg.descendants()
                            for desc in descendants:
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = desc.window_text()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        if "desea" in texto_lower and "continuar" in texto_lower:
                                            self.logger.warning(f"Aviso '¿ Desea Continuar ?' detectado")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.1)
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_continuar_aviso: {e}")
            return False, ""

    def detect_interventor_error(self, timeout=2):
        """
        OPTIMIZADO: Detecta error de interventor buscando SOLO en SIRAT + controles Text
        
        PROBLEMA ORIGINAL:
        - Buscaba en TODO desktop (10+ ventanas) + ALL descendants (100+)
        - En producción: 24 segundos (bloqueaba digitación de PLAZO)
        
        SOLUCIÓN:
        - Busca SOLO en ventana SIRAT (confirmado via test_descendientes.py)
        - Busca SOLO en controles de tipo "Text" (más preciso y rápido)
        - Timeout: 0.5s (suficiente para detectar mensaje)
        - Esperado: 0.5 segundos vs 24 segundos
        
        Retorna: (True, "mensaje") si error detectado, (False, "") si no
        """
        try:
            self.logger.info(f"Verificando error 'Código de Interventor incorrecto' en controles Text (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # OPTIMIZACIÓN CLAVE: Solo buscar en SIRAT (no todo desktop)
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.05)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        descendants = sirat_window.descendants()
                        for desc in descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # FILTRO: Solo controles de tipo "Text" con contenido
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    # Búsqueda de 3 palabras clave
                                    if ("codigo" in texto_lower and 
                                        "interventor" in texto_lower and 
                                        "incorrecto" in texto_lower):
                                        self.logger.warning(f" Error INTERVENTOR detectado: '{texto}'")
                                        return True, texto
                            except Exception:
                                pass
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.05)  # Polling rápido (50ms intervals)
            
            self.logger.info("No hay error de INTERVENTOR")
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_interventor_error: {e}")
            return False, ""

    def detect_aviso_monto_excede_20pct(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto ingresado excede en mas del [X]% el Saldo del Expediente"
        Tolerante con cualquier porcentaje (20%, 10%, 15%, X%, etc).
        """
        try:
            self.logger.info("Verificando aviso 'monto excede porcentaje'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante con expresión regular para cualquier porcentaje
                                        import re
                                        has_excede = "excede" in texto_lower
                                        has_percent = bool(re.search(r'\d+\s*%', texto))
                                        has_saldo = "saldo" in texto_lower
                                        has_expediente = "expediente" in texto_lower
                                        
                                        if has_excede and has_percent and has_saldo and has_expediente:
                                            self.logger.info(f" Aviso monto excede: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_excede_20pct: {e}")
            return False, ""

    def detect_aviso_monto_supera_saldo(self, timeout=2):
        """
        Detecta el aviso de monto excesivo en controles de tipo "Text":
        "El monto de embargo ingresado supera el saldo embargable del expediente..."
        Tolerante con variación de texto y números.
        """
        try:
            self.logger.info("Verificando aviso 'monto supera saldo'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("monto" in texto_lower and
                                            "embargo" in texto_lower and
                                            "supera" in texto_lower and 
                                            "saldo" in texto_lower):
                                            self.logger.info(f" Aviso monto supera saldo: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_aviso_monto_supera_saldo: {e}")
            return False, ""

    def detect_desea_grabar_resolucion(self, timeout=2):
        try:
            self.logger.info("Verificando aviso '¿Desea grabar Resolución?'...")
            desktop = Desktop(backend=MSAA_BACKEND)
            end_time = time.time() + timeout
            
            while time.time() < end_time:
                try:
                    for win in desktop.windows():
                        try:
                            for desc in win.descendants():
                                try:
                                    # Filtrar solo controles de tipo "Text"
                                    control_type = None
                                    texto = ""
                                    
                                    try:
                                        if hasattr(desc, 'element_info'):
                                            control_type = desc.element_info.control_type
                                    except:
                                        pass
                                    
                                    try:
                                        texto = str(desc.window_text() or "").strip()
                                    except:
                                        pass
                                    
                                    # Solo procesar controles de tipo "Text"
                                    if control_type == "Text" and texto:
                                        texto_lower = texto.lower()
                                        
                                        # Búsqueda tolerante: palabras clave
                                        if ("desea" in texto_lower and 
                                            "grabar" in texto_lower and 
                                            "resolu" in texto_lower):  # resolu cubre resolución, resolucion
                                            self.logger.info(f" Aviso grabar Resolución: {texto[:80]}...")
                                            return True, texto
                                except Exception:
                                    pass
                        except Exception:
                            pass
                except Exception:
                    pass
                time.sleep(0.3)
            
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_desea_grabar_resolucion: {e}")
            return False, ""

    def detect_first_aviso(self, timeout=2):
        try:
            self.logger.info(f"Detectando PRIMER AVISO/MENSAJE (timeout={timeout}s)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    # Buscar en ventana SIRAT
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.1)
                        continue
                    
                    # Iterar descendants
                    try:
                        all_descendants = list(sirat_window.descendants())
                        
                        for desc in all_descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # CRITERIO: Controles de tipo "Text" con contenido (excluyendo etiquetas muy cortas)
                                if control_type == "Text" and texto and len(texto.strip()) > 3:
                                    self.logger.info(f"[ PRIMER AVISO DETECTADO] {texto[:100]}")
                                    return True, texto
                            
                            except Exception:
                                pass
                    
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.2)
            
            self.logger.warning("No se detectó primer aviso/mensaje")
            return False, ""
        except Exception as e:
            self.logger.error(f"Error en detect_first_aviso: {e}")
            return False, ""

    def detect_rc_message(self, timeout=3):
        try:
            self.logger.info(f"Buscando RC en SIRAT: 'Se grabó la Resolución Coactiva' (timeout={timeout}s OPTIMIZADO)...")
            
            end_time = time.time() + timeout
            while time.time() < end_time:
                try:
                    sirat_window = self.find_sirat_window()
                    if not sirat_window:
                        time.sleep(0.1)
                        continue
                    
                    # Buscar descendants solo dentro de SIRAT
                    try:
                        all_descendants = list(sirat_window.descendants())
                        
                        for desc in all_descendants:
                            try:
                                control_type = None
                                texto = ""
                                
                                # Obtener tipo de control
                                try:
                                    if hasattr(desc, 'element_info'):
                                        control_type = desc.element_info.control_type
                                except Exception:
                                    pass
                                
                                # Obtener texto
                                try:
                                    texto = desc.window_text()
                                except Exception:
                                    pass
                                
                                # Filtrar: solo controles de tipo "Text" que contengan el patrón
                                if control_type == "Text" and texto and len(texto.strip()) > 0:
                                    texto_lower = texto.lower()
                                    
                                    # Buscar patrón "Se grabó la Resolución Coactiva"
                                    if "se grabó" in texto_lower and "resolución coactiva" in texto_lower:
                                        self.logger.info(f" Mensaje RC detectado: {texto[:100]}...")
                                        
                                        # Extraer número después de "número"
                                        numero_index = texto_lower.find("número")
                                        if numero_index >= 0:
                                            texto_despues = texto[numero_index + 6:].strip()
                                            
                                            # Extraer dígitos consecutivos
                                            rc_number = ""
                                            for char in texto_despues:
                                                if char.isdigit():
                                                    rc_number += char
                                                elif rc_number:  # Ya tenemos dígitos, paramos en primer no-dígito
                                                    break
                                            
                                            if rc_number:
                                                self.logger.info(f" RC extraída como STRING: {rc_number}")
                                                return True, rc_number
                            
                            except Exception:
                                pass
                    
                    except Exception:
                        pass
                
                except Exception:
                    pass
                
                time.sleep(0.1)
            
            self.logger.warning(f"No se detectó RC después de {timeout} segundos")
            return False, ""
        
        except Exception as e:
            self.logger.error(f"Error en detect_rc_message: {e}")
            return False, ""
    
    
    def navigate_to_module(self) -> bool:
        try:
            self.logger.info("Buscando 'Cobranza Coactiva' dentro de ventana SIRAT...")
            
            timeout_segundos = 360
            tiempo_inicio = time.time()
            intento = 0
            
            while time.time() - tiempo_inicio < timeout_segundos:
                intento += 1
                tiempo_transcurrido = int(time.time() - tiempo_inicio)
                self.logger.info(f"Intento {intento} (tiempo: {tiempo_transcurrido}/{timeout_segundos}s)")
                
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    
                    app = desktop.window(title="SIRAT")
                    if not app.exists(timeout=2):
                        self.logger.info(f"Intento {intento}: ventana SIRAT no disponible, reintentando...")
                        time.sleep(2)
                        continue
                    
                    encontrado = False
                    
                    try:
                        descendants = app.descendants()
                        for descendant in descendants:
                            try:
                                texto = (descendant.window_text() or "").strip()
                                if texto == "Cobranza Coactiva":
                                    self.logger.info("Elemento 'Cobranza Coactiva' encontrado, haciendo clic...")
                                    rect = descendant.rectangle()
                                    center_x = (rect.left + rect.right) // 2
                                    center_y = (rect.top + rect.bottom) // 2
                                    pyautogui.click(center_x, center_y)
                                    time.sleep(1)
                                    encontrado = True
                                    break
                            except Exception:
                                pass
                    except Exception as e:
                        self.logger.debug(f"Error buscando en descendientes: {e}")
                    
                    if encontrado:
                        self.logger.info(" Clic en 'Cobranza Coactiva' completado")
                        time.sleep(1)
                        ok = self.click_exp_individual(app)
                        if ok:
                            return True
                        else:
                            self.logger.warning("No se pudo seleccionar 'Exp. Cob. Coactiva - Individual'")
                            return False
                    
                    self.logger.debug(f"Intento {intento}: 'Cobranza Coactiva' no encontrada en descendientes")
                    
                except Exception as e:
                    self.logger.debug(f"Error en intento {intento}: {e}")
                
                time.sleep(2)
            
            self.logger.error(f"Timeout alcanzado ({timeout_segundos}s) buscando 'Cobranza Coactiva'")
            return False
            
        except Exception as e:
            self.logger.error(f"Error navegando al módulo: {e}")
            return False
    
    def click_exp_individual(self, app=None):
        try:
            self.logger.info("Haciendo 4 clics en 'Exp. Cob. Coactiva - Individual'...")
            
            if not app:
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    app = desktop.window(title="SIRAT")
                    if not app.exists(timeout=2):
                        self.logger.error("No se encontró ventana SIRAT")
                        return False
                except Exception:
                    self.logger.error("Error obteniendo ventana SIRAT")
                    return False
            
            target_element = None
            try:
                descendants = app.descendants()
                for element in descendants:
                    try:
                        texto = (element.window_text() or "").strip()
                        if texto == "Exp. Cob. Coactiva - Individual":
                            target_element = element
                            break
                    except Exception:
                        continue
            except Exception as e:
                self.logger.debug(f"Error buscando en descendientes: {e}")

            if not target_element:
                self.logger.warning("'Exp. Cob. Coactiva - Individual' no encontrado en ventana SIRAT")
                return False

            try:
                rect = target_element.rectangle()
                center_x = (rect.left + rect.right) // 2
                center_y = (rect.top + rect.bottom) // 2
            except Exception:
                self.logger.warning("No se pudieron obtener coordenadas del control 'Exp. Individual'")
                return False

            self.logger.info(f"Encontrado: {target_element.window_text() or ''}")

            for i in range(4):
                pyautogui.click(center_x, center_y)
                self.logger.info(f"Clic {i+1}/4")
                time.sleep(0.01)

            self.logger.info(" Se completaron 4 clics en 'Exp. Cob. Coactiva - Individual'")
            return True

        except Exception as e:
            self.logger.error(f"Error en click_exp_individual: {e}")
            return False
    
    def reset_to_individual_form(self, dependencia: str) -> bool:
        try:
            self.logger.info("═" * 70)
            self.logger.info("Reseteando pantalla para siguiente expediente (misma dependencia)...")
            self.logger.info("═" * 70)
            
            # PASO 1: VALIDACIÓN INICIAL
            if not self.check_app_window_exists():
                self.logger.error("Ventana SIRAT cerrada, limpiando caché")
                self.coords_cache.clear_by_dependencia(dependencia)
                self.logger.info("═" * 70)
                return False
            
            # PASO 2: BUSCAR Y CLICKEAR "Cobranza Coactiva"
            self.logger.info("Buscando 'Cobranza Coactiva'...")
            cobranza_found = self._find_and_click_element(
                element_name="Cobranza Coactiva",
                cache_key="cobranza_coactiva",
                dependencia=dependencia,
                max_attempts=1
            )
            
            if not cobranza_found:
                self.logger.error(" No se pudo encontrar 'Cobranza Coactiva'")
                self.logger.info("═" * 70)
                return False
            
            time.sleep(1)
            
            # PASO 3: BUSCAR Y CLICKEAR "Exp. Cob. Coactiva - Individual" (4 clics)
            self.logger.info("Buscando 'Exp. Cob. Coactiva - Individual'...")
            individual_found = self._find_and_click_element(
                element_name="Exp. Cob. Coactiva - Individual",
                cache_key="exp_cob_individual",
                dependencia=dependencia,
                num_clicks=4,
                max_attempts=1
            )
            
            if not individual_found:
                self.logger.error(" No se pudo encontrar 'Exp. Cob. Coactiva - Individual'")
                self.logger.info("═" * 70)
                return False
            
            self.logger.info(" Pantalla reseteada correctamente para siguiente expediente")
            self.logger.info("═" * 70)
            return True
            
        except Exception as e:
            self.logger.error(f"Error en reset_to_individual_form: {e}")
            self.logger.info("═" * 70)
            return False
    
    def _find_and_click_element(self, element_name: str, cache_key: str, dependencia: str,
                                 num_clicks: int = 1, max_attempts: int = 1, 
                                 double_click: bool = False, partial_match: bool = False) -> bool:
        try:
            # ESTRATEGIA 1: INTENTAR CON CACHÉ
            cached_coords = self.coords_cache.get(cache_key, dependencia)
            if cached_coords:
                self.logger.info(f"Intentando con coords guardadas: ({cached_coords['x']}, {cached_coords['y']})")
                try:
                    if double_click:
                        pyautogui.doubleClick(cached_coords['x'], cached_coords['y'])
                        time.sleep(0.5)
                        pyautogui.press('return')
                        time.sleep(0.5)
                    else:
                        for i in range(num_clicks):
                            pyautogui.click(cached_coords['x'], cached_coords['y'])
                            time.sleep(0.1)
                    
                    # Verificar que app sigue respondiendo
                    if self.check_app_window_exists():
                        self.logger.info(f"Funcionó con coords cacheadas")
                        self.coords_cache.increment_success(cache_key, dependencia)
                        return True
                    else:
                        self.logger.warning(f"Falló - app no responde después de clic")
                except Exception as e:
                    self.logger.debug(f"Error durante clic: {e}")
            
            # ESTRATEGIA 2: BÚSQUEDA COMPLETA (si caché no existe o falló)
            self.logger.info(f"[BÚSQUEDA] Buscando '{element_name}' en descendientes...")
            
            for attempt in range(max_attempts):
                try:
                    desktop = Desktop(backend=MSAA_BACKEND)
                    app = desktop.window(title="SIRAT")
                    
                    if not app.exists(timeout=2):
                        self.logger.debug(f"Intento {attempt+1}: Ventana SIRAT no disponible")
                        time.sleep(1)
                        continue
                    
                    # Buscar element_name en descendientes
                    target_element = None
                    try:
                        descendants = app.descendants()
                        for descendant in descendants:
                            try:
                                texto = (descendant.window_text() or "").strip()
                                
                                if partial_match:
                                    # Búsqueda parcial: contiene la cadena (case-insensitive)
                                    if element_name.lower() in texto.lower():
                                        target_element = descendant
                                        break
                                else:
                                    # Búsqueda exacta
                                    if texto == element_name:
                                        target_element = descendant
                                        break
                            except Exception:
                                pass
                    except Exception as e:
                        self.logger.debug(f"Error iterando descendientes: {e}")
                    
                    if target_element:
                        # Obtener coordenadas
                        rect = target_element.rectangle()
                        center_x = (rect.left + rect.right) // 2
                        center_y = (rect.top + rect.bottom) // 2
                        
                        accion = "doble clic" if double_click else f"{num_clicks} clic(s)"
                        self.logger.info(f"[BÚSQUEDA] Encontrado en ({center_x}, {center_y}), haciendo {accion}...")
                        
                        # Hacer clics
                        if double_click:
                            pyautogui.doubleClick(center_x, center_y)
                            time.sleep(0.5)
                            pyautogui.press('return')
                            time.sleep(0.5)
                        else:
                            for i in range(num_clicks):
                                pyautogui.click(center_x, center_y)
                                time.sleep(0.1)
                        
                        self.coords_cache.set(cache_key, dependencia, center_x, center_y)
                        self.logger.info(f"[BÚSQUEDA] Coords guardadas en caché: {cache_key}")
                        
                        return True
                    
                except Exception as e:
                    self.logger.debug(f"Error en intento {attempt+1}: {e}")
                
                time.sleep(1)
            
            # Sin caché ni búsqueda tuvo éxito
            self.logger.error(f"[FALLO] No se encontró '{element_name}' después de intentos")
            return False
            
        except Exception as e:
            self.logger.error(f"Error en _find_and_click_element: {e}")
            return False
    
    
    
    def enter_expediente_initial(self, expediente: str) -> Tuple[Outcome, Optional[str]]:
        try:
            self.logger.info(f"Ingresando expediente inicial: {expediente}")
            
            if not self.check_app_window_exists():
                self.logger.error("[CRÍTICO] SIRAT se cerró o crasheó antes de ingresar expediente")
                return (Outcome.FAIL_UI, None)
            
            numero_field = self._find_pbedit_field()
            
            if not numero_field:
                self.logger.error("No se encontró campo PBEDIT")
                return (Outcome.FAIL_UI, None)
            
            numero_field.set_focus()
            time.sleep(0.3)
            for _ in range(15):
                pyautogui.hotkey('ctrl', 'backspace')
                time.sleep(0.02)
            time.sleep(0.3)
            
            self.logger.info(f"Escribiendo expediente: {expediente}")
            self._type_string_preserving_zeros(expediente)
            time.sleep(0.5)
            
            # Presionar ENTER
            pyautogui.press('return')
            time.sleep(0.5)
            
            # Detectar error de expediente 
            exp_err, exp_msg = self.detect_expediente_error(timeout=0.5)
            if exp_err:
                self.logger.warning(f"Expediente inválido: {exp_msg}")
                self.logger.info("Limpiando campo para ingresar siguiente expediente...")
                self.clear_expediente_field()
                time.sleep(0.5)
                return (Outcome.SKIP_EXP_INVALIDO, None)
            
            self.logger.info(f"Expediente ingresado: {expediente}")
            return (Outcome.OK_RC, None)  
        
        except Exception as e:
            self.logger.error(f"Error ingresando expediente inicial: {e}")
            return (Outcome.FAIL_UI, None)
    
    
    def iter_all_descendants(self):
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            try:
                app = desktop.window(title="SIRAT")
                if app.exists(timeout=1):
                    for desc in app.descendants():
                        yield desc
            except Exception:
                pass
        except Exception:
            return
    
    def _find_pbedit_field(self) -> Optional[object]:
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            try:
                app = desktop.window(title="SIRAT")
                if not app.exists(timeout=1):
                    return None
            except Exception:
                return None
            
            descendants = list(app.descendants())
            
            self.logger.info("Buscando PBEDIT125 (campo estándar para expedientes)...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name == "PBEDIT125":
                        self.logger.info(f"  {class_name} encontrado (estándar para expedientes)")
                        self.logger.info("[ ESTRATEGIA 1 FUNCIONÓ] PBEDIT125 encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 1 FALLÓ] PBEDIT125 no encontrado")
            
            self.logger.info("PBEDIT125 no encontrado, buscando otro PBEDIT*...")
            for element in descendants:
                try:
                    class_name = str(element.element_info.class_name or "").strip()
                    if class_name.startswith("PBEDIT"):
                        self.logger.info(f"  {class_name} encontrado (variante)")
                        self.logger.info(f"[ ESTRATEGIA 2 FUNCIONÓ] {class_name} encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 2 FALLÓ] Ningún PBEDIT* encontrado")
            
            self.logger.info("PBEDIT* no encontrado, usando fallback (campo Edit)...")
            for element in descendants:
                try:
                    control_type = str(element.element_info.control_type or "")
                    if "Edit" in control_type or "text" in control_type.lower():
                        self.logger.info(f"  Campo editable encontrado por tipo: {control_type}")
                        self.logger.info("[ ESTRATEGIA 3 FUNCIONÓ] Campo Edit encontrado - retornando")
                        return element
                except Exception:
                    continue
            self.logger.debug("[ ESTRATEGIA 3 FALLÓ] Ningún campo Edit encontrado")
            
            return None
        except Exception as e:
            self.logger.debug(f"Error en _find_pbedit_field: {e}")
            return None
    
    def _type_string_preserving_zeros(self, text: str) -> None:
        text_str = str(text)  # Asegurar que es string
        for char in text_str:
            pyautogui.typewrite(char, interval=0.02)  # typewrite es más seguro para caracteres
        time.sleep(0.2)

    def clear_expediente_field(self) -> bool:
        try:
            self.logger.info("[LIMPIAR CAMPO] Borrando contenido del campo de expediente...")
            
            pyautogui.hotkey('ctrl', 'a')
            time.sleep(0.1)
            
            pyautogui.press('delete')
            time.sleep(0.3)
            
            self.logger.info("[LIMPIAR CAMPO] Campo limpiado exitosamente (foco preservado)")
            return True
            
        except Exception as e:
            self.logger.error(f"Error limpiando campo: {e}")
            return False
    
    def click_proceso_embargo(self) -> bool:
        try:
            cached_coords = self.coords_cache.get("proceso_embargo", "21")
            if cached_coords:
                self.logger.info(f"[JSON] Encontrado en caché: ({cached_coords['x']}, {cached_coords['y']})")
                try:
                    pyautogui.click(cached_coords['x'], cached_coords['y'])
                    time.sleep(0.5)
                    if self.check_app_window_exists():
                        self.logger.info(f" Clic en Proceso de Embargo completado (desde JSON)")
                        time.sleep(1.5)  # Esperar a que se expanda menú
                        return True
                except Exception as e:
                    self.logger.warning(f"[JSON] Falló al usar coords cacheadas: {e}")
        except Exception as e:
            self.logger.debug(f"[JSON] Error consultando caché: {e}")
        
        self.logger.info("Buscando 'Proceso de Embargo' en el menú...")
        
        try:
            desktop = Desktop(backend="uia")
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*Menú.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.window(title_re=".*SIRAT.*")
                    if not app.exists(timeout=2):
                        app = None
                except:
                    app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    for idx, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            
                            # Búsqueda exacta: "Proceso de Embargo"
                            if desc_text == "Proceso de Embargo":
                                self.logger.info(f" 'Proceso de Embargo' encontrado en índice {idx}")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    
                                    # ★ GUARDAR EN JSON (ÚNICA fuente de coords)
                                    try:
                                        self.coords_cache.set("proceso_embargo", "21", click_x, click_y)
                                        self.logger.info(f" Coords guardadas en JSON")
                                    except Exception as e:
                                        self.logger.warning(f"Error guardando en JSON: {e}")
                                    
                                    pyautogui.click(click_x, click_y)
                                    self.logger.info("Esperando 2 segundos para que se expanda el menú...")
                                    time.sleep(2)
                                    self.logger.info(" Clic en Proceso de Embargo completado")
                                    return True
                        
                        except Exception:
                            pass
                
                except Exception as e:
                    self.logger.warning(f"Error iterando descendientes: {e}")
            
            self.logger.warning("No se pudo encontrar 'Proceso de Embargo'")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_proceso_embargo: {e}")
            return False
    
    def click_trabar_embargo(self) -> bool:
        try:
            cached_coords = self.coords_cache.get("trabar_embargo", "21")
            if cached_coords:
                self.logger.info(f"[JSON] Encontrado en caché: ({cached_coords['x']}, {cached_coords['y']})")
                try:
                    pyautogui.click(cached_coords['x'], cached_coords['y'])
                    time.sleep(0.5)
                    if self.check_app_window_exists():
                        self.logger.info(f" Clic en Trabar Embargo completado (desde JSON)")
                        time.sleep(1)  # Esperar a que se renderice
                        return True
                except Exception as e:
                    self.logger.warning(f"[JSON] Falló al usar coords cacheadas: {e}")
        except Exception as e:
            self.logger.debug(f"[JSON] Error consultando caché: {e}")
        
        self.logger.info("Buscando 'Trabar Embargo' (usando patrón de descendientes)...")
        
        try:
            desktop = Desktop(backend="uia")
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*SIRAT.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"Total de descendientes: {len(descendants)}")
                    
                    # Iterar todos los descendientes y buscar "Trabar Embargo"
                    for i, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            
                            # Búsqueda exacta con strip()
                            if desc_text == "Trabar Embargo":
                                self.logger.info(f" 'Trabar Embargo' encontrado (exacto) en índice {i}")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"Coordenadas válidas: ({click_x}, {click_y})")
                                    
                                    # ★ GUARDAR EN JSON (ÚNICA fuente de coords)
                                    try:
                                        self.coords_cache.set("trabar_embargo", "21", click_x, click_y)
                                        self.logger.info(f" Coords guardadas en JSON")
                                    except Exception as e:
                                        self.logger.warning(f"Error guardando en JSON: {e}")
                                    
                                    self.logger.info(f"Haciendo clic en: ({click_x}, {click_y})")
                                    pyautogui.click(click_x, click_y)
                                    time.sleep(1)
                                    self.logger.info(" Clic completado exitosamente")
                                    return True
                                else:
                                    # Intentar invoke si no tiene coordenadas válidas
                                    self.logger.info("Coordenadas inválidas, intentando invoke...")
                                    try:
                                        descendant.invoke()
                                        time.sleep(1)
                                        self.logger.info(" Invocado correctamente")
                                        return True
                                    except:
                                        pyautogui.press('return')
                                        time.sleep(1)
                                        self.logger.info(" Enter presionado")
                                        return True
                        
                        except Exception:
                            pass
                    
                    # Si no se encontró
                    self.logger.warning("'Trabar Embargo' NO encontrado en descendientes")
                
                except Exception as e:
                    self.logger.error(f"Error iterando descendientes: {e}")
            
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_trabar_embargo: {e}")
            return False
    
    
    def go_to_trabar_embargo(self) -> bool:
        self.logger.info("\n" + "=" * 70)
        self.logger.info("NAVEGANDO A TRABAR EMBARGO")
        self.logger.info("=" * 70)
        
        # PASO 1: Hacer clic en "Proceso de Embargo"
        if not self.click_proceso_embargo():
            self.logger.error("No se pudo hacer clic en 'Proceso de Embargo'")
            return False
        
        # PASO 2: Hacer clic en "Trabar Embargo"
        if not self.click_trabar_embargo():
            self.logger.error("No se pudo hacer clic en 'Trabar Embargo'")
            return False
        
        self.logger.info(" Navegación a Trabar Embargo completada")
        return True
    
    
    def click_trabar_intervencion(self, dependencia: str) -> bool:
        try:
            # ESPERAR A QUE MENÚ SE EXPANDA
            time.sleep(1)
            
            return self._find_and_click_element(
                element_name="Trabar Intervención en Información",
                cache_key="trabar_intervencion",
                dependencia=dependencia,
                max_attempts=1,
                double_click=True,
                partial_match=True  # Busca elementos que contengan "intervención"
            )
            
        except Exception as e:
            self.logger.error(f"Error en click_trabar_intervencion: {str(e)}")
            return False
    
    def iei_enter_interventor(self, interventor: str) -> Outcome:
        try:
            self.logger.info(f"Ingresando INTERVENTOR: {interventor}")
            
            time.sleep(0.5)
            
            self.logger.info(f"Digitando INTERVENTOR: '{interventor}'")
            pyautogui.write(str(interventor), interval=0.05)
            time.sleep(0.3)
            
            # Presionar TAB para pasar al campo PLAZO
            self.logger.info("Presionando TAB para pasar al campo PLAZO...")
            pyautogui.press('tab')
            time.sleep(0.3)
            
            self.logger.info(f" INTERVENTOR ingresado correctamente (sin validación)")
            return Outcome.OK_RC
                    
        except Exception as e:
            self.logger.error(f"Error ingresando interventor: {e}")
            return Outcome.FAIL_UI
    
    def iei_set_plazo_and_confirm(self, plazo: int) -> Tuple[Outcome, Optional[str]]:
        try:
            self.logger.info(f"Ingresando PLAZO: {plazo}")
            
            # Digitar PLAZO directamente
            self.logger.info(f"Digitando PLAZO: '{plazo}'")
            pyautogui.write(str(plazo), interval=0.05)
            time.sleep(0.3)
            
            # Presionar ALT+A para confirmar pantalla
            self.logger.info("Presionando ALT+A para confirmar PLAZO...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            
            # PRIMER ALT+S (primer aviso)
            self.logger.info("Presionando ALT+S (primer aviso)...")
            pyautogui.hotkey('alt', 's')
            time.sleep(1)
            
            # SEGUNDO ALT+S (segundo aviso)
            self.logger.info("Presionando ALT+S (segundo aviso)...")
            pyautogui.hotkey('alt', 's')
            time.sleep(0.5)
            
            # Buscar RC "Se grabó la Resolución Coactiva con número..."
            self.logger.info("Buscando RC...")
            rc_det, rc_num = self.detect_rc_message(timeout=3.0)
            
            if rc_det and rc_num:
                self.logger.info(f" RC DETECTADA (IEI): {rc_num}")
                
                # Presionar ENTER para cerrar mensaje
                self.logger.info("Presionando ENTER para cerrar mensaje...")
                pyautogui.press('return')
                time.sleep(0.5)
                
                # Presionar ALT+C para cerrar ventana
                self.logger.info("Presionando ALT+C para cerrar ventana...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                
                # Presionar ALT+C ADICIONAL para reiniciar flujo del siguiente expediente
                self.logger.info("Presionando ALT+C adicional para reiniciar flujo del siguiente expediente...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                self.logger.info("Flujo reiniciado para siguiente expediente")
                
                return (Outcome.OK_RC, rc_num)
            else:
                self.logger.warning("RC no detectada después de confirmación")
                return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en iei_set_plazo_and_confirm: {e}")
            return (Outcome.FAIL_UI, None)
    
    
    def select_embargo_type(self, tipo_medida: str, dependencia: str) -> bool:
        MAX_REINTENTOS = 3
        
        for intento in range(1, MAX_REINTENTOS + 1):
            try:
                tipo_upper = str(tipo_medida).strip().upper()
                
                if "IEI" in tipo_upper:
                    self.logger.info(f"[Intento {intento}/{MAX_REINTENTOS}] Seleccionando IEI (Intervención)...")
                    if self.click_trabar_intervencion(dependencia=dependencia):
                        return True
                    else:
                        self.logger.warning(f"Intento {intento}: No se pudo seleccionar IEI")
                        if intento < MAX_REINTENTOS:
                            time.sleep(0.5)
                            continue
                        return False
                elif "DSE" in tipo_upper:
                    self.logger.info(f"[Intento {intento}/{MAX_REINTENTOS}] Seleccionando DSE (Depósito)...")
                    if self.click_trabar_deposito(dependencia=dependencia):
                        return True
                    else:
                        self.logger.warning(f"Intento {intento}: No se pudo seleccionar DSE")
                        if intento < MAX_REINTENTOS:
                            time.sleep(0.5)
                            continue
                        return False
                else:
                    self.logger.error(f"Tipo de medida no válido: {tipo_medida}")
                    return False
            
            except Exception as e:
                self.logger.error(f"Intento {intento}: Error seleccionando tipo de embargo: {e}")
                if intento < MAX_REINTENTOS:
                    time.sleep(0.5)
                    continue
                return False
        
        return False
    
    # DSE (DEPÓSITO)
    
    def click_trabar_deposito(self, dependencia: str) -> bool:
        try:
            return self._find_and_click_element(
                element_name="sin extracción",
                cache_key="trabar_deposito",
                dependencia=dependencia,
                max_attempts=3,
                double_click=True,
                partial_match=True  # Busca elementos que contengan "sin extracción"
            )
            
        except Exception as e:
            self.logger.error(f"Error en click_trabar_deposito: {str(e)}")
            return False
    
    def dse_set_monto_and_confirm(self, monto: float) -> Tuple[Outcome, Optional[str]]:
        try:
            self.logger.info(f"Ingresando MONTO: {monto}")
            
            # PASO 1: Escribir MONTO
            monto_str = str(monto).replace(',', '.')
            self.logger.info(f"Paso 1: Escribiendo monto: {monto_str}")
            pyautogui.write(monto_str, interval=0.05)
            time.sleep(0.5)
            
            # PASO 2: Presionar ALT+A para confirmar monto
            self.logger.info("Paso 2: Presionando ALT+A para confirmar monto...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            
            # PASO 3: Comparar con 003.png usando OpenCV (DETECCIÓN POR IMAGEN)
            self.logger.info("Paso 3: Detectando tipo de aviso mediante comparación de imagen 003.png...")
            
            # Intentar cargar 003.png
            image_003_path = self.img_dir / "003.png" if self.img_dir else None
            monto_mayor_detectado = False
            
            if image_003_path and image_003_path.exists():
                try:
                    # Cargar template
                    template = cv2.imread(str(image_003_path))
                    if template is None:
                        self.logger.warning("No se pudo cargar 003.png, usando fallback a texto")
                    else:
                        template_gray = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
                        
                        # Buscar coincidencia dentro de 1.5 segundos
                        start_time = time.time()
                        while time.time() - start_time < 1.5:
                            try:
                                screen = np.array(ImageGrab.grab())
                                screen_cv2 = cv2.cvtColor(screen, cv2.COLOR_RGB2BGR)
                                screen_gray = cv2.cvtColor(screen_cv2, cv2.COLOR_BGR2GRAY)
                                
                                result = cv2.matchTemplate(screen_gray, template_gray, cv2.TM_CCOEFF_NORMED)
                                _, max_val, _, _ = cv2.minMaxLoc(result)
                                
                                # Threshold: 0.75 (75% similitud)
                                if max_val >= 0.75:
                                    self.logger.info(f" [IMAGEN] Coincidencia detectada: {max_val:.2%}")
                                    self.logger.info("[ MONTO MAYOR DETECTADO POR IMAGEN]")
                                    monto_mayor_detectado = True
                                    break
                                
                                time.sleep(0.2)
                            except Exception as e:
                                self.logger.debug(f"Error en comparación OpenCV: {e}")
                                break
                        
                        if not monto_mayor_detectado:
                            self.logger.info(" [IMAGEN] No se detectó coincidencia en 1.5s → MONTO VÁLIDO")
                except Exception as e:
                    self.logger.warning(f"Error en detección por imagen: {e}")
            else:
                self.logger.warning("003.png no encontrado, usando fallback a detectores textuales")
            
            # PASO 4: Si no se detectó por imagen, usar fallback a detección textual
            if not monto_mayor_detectado:
                try:
                    aviso_detectado, primer_aviso = self.detect_first_aviso(timeout=1.0)
                    if aviso_detectado and primer_aviso:
                        primer_aviso = str(primer_aviso).strip()
                        self.logger.info(f"Aviso detectado (fallback): '{primer_aviso[:80]}'")
                        if primer_aviso.startswith("El monto"):
                            monto_mayor_detectado = True
                            self.logger.info(" [TEXTO] Coincidencia detectada: 'El monto'")
                except Exception as e:
                    self.logger.debug(f"Error en fallback textual: {e}")
            
            # PASO 5: Procesar según resultado de detección
            if monto_mayor_detectado:
                self.logger.warning(f"[ MONTO MAYOR CONFIRMADO]")
                self.logger.info("  Ruta: ENTER → 1s → ENTER → ALT+C")
                
                # ENTER para cerrar primer aviso
                pyautogui.press('return')
                time.sleep(1)
                
                # ENTER para cerrar segundo aviso (si existe)
                pyautogui.press('return')
                time.sleep(1)
                
                # ALT+C para cancelar
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                
                # Presionar ALT+C ADICIONAL para reiniciar flujo del siguiente expediente
                self.logger.info("Presionando ALT+C adicional para reiniciar flujo del siguiente expediente...")
                pyautogui.hotkey('alt', 'c')
                time.sleep(1)
                self.logger.info("Flujo reiniciado para siguiente expediente")
                
                self.logger.info("Monto rechazado por excesivo. Retornando SKIP_MONTO_MAYOR")
                return (Outcome.SKIP_MONTO_MAYOR, None)
            
            # PASO 6: Monto Válido - Usar ALT+S secuencia TRIPLE
            else:
                self.logger.info(f"[ MONTO VÁLIDO]")
                self.logger.info("  Ruta: ALT+S → 1s → ALT+S → 1s → ALT+S → buscar RC")
                
                # Primer ALT+S (cierra "¿Desea Continuar?" o similar)
                pyautogui.hotkey('alt', 's')
                self.logger.info("  ALT+S #1 enviado")
                time.sleep(1)
                
                # Segundo ALT+S (cierra "¿Desea grabar Resolución?" o similar)
                pyautogui.hotkey('alt', 's')
                self.logger.info("  ALT+S #2 enviado")
                time.sleep(1)
                
                # Tercer ALT+S (seguridad, por si hay aviso adicional)
                pyautogui.hotkey('alt', 's')
                self.logger.info("  ALT+S #3 enviado (seguridad)")
                time.sleep(1)
                
                # Buscar el mensaje de RC
                self.logger.info("Buscando mensaje de RC...")
                rc_detectado, rc_num = self.detect_rc_message(timeout=3.0)
                
                if rc_detectado and rc_num:
                    rc_number = str(rc_num).strip()
                    self.logger.info(f"[ RC ENCONTRADA] {rc_number}")
                    
                    # ENTER y ALT+C para cerrar
                    pyautogui.press('return')
                    time.sleep(1)
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    
                    # Presionar ALT+C ADICIONAL para reiniciar flujo del siguiente expediente
                    self.logger.info("Presionando ALT+C adicional para reiniciar flujo del siguiente expediente...")
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    self.logger.info("Flujo reiniciado para siguiente expediente")
                    
                    return (Outcome.OK_RC, rc_number)
                else:
                    self.logger.warning("No se detectó RC final. Cerrando...")
                    pyautogui.press('return')
                    time.sleep(1)
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    
                    # Presionar ALT+C ADICIONAL para reiniciar flujo del siguiente expediente
                    self.logger.info("Presionando ALT+C adicional para reiniciar flujo del siguiente expediente...")
                    pyautogui.hotkey('alt', 'c')
                    time.sleep(1)
                    self.logger.info("Flujo reiniciado para siguiente expediente")
                    
                    return (Outcome.OK_RC, None)
        
        except Exception as e:
            self.logger.error(f"Error en dse_set_monto_and_confirm: {e}", exc_info=True)
            return (Outcome.FAIL_UI, None)
    
    
    def click_proceso_embargo_for_restart(self) -> bool:

        self.logger.info("  [1/3] Buscando 'Proceso de Embargo' en el menú (restart)...")
        
        try:
            desktop = Desktop(backend="uia")
            
            # Buscar ventana SIRAT
            app = None
            try:
                app = desktop.window(title_re=".*Menú.*")
                if not app.exists(timeout=2):
                    app = None
            except:
                app = None
            
            if not app:
                try:
                    app = desktop.window(title_re=".*SIRAT.*")
                    if not app.exists(timeout=2):
                        app = None
                except:
                    app = None
            
            if not app:
                try:
                    app = desktop.active()
                except:
                    app = None
            
            if app:
                self.logger.info("  Ventana encontrada, iterando descendientes...")
                
                try:
                    descendants = app.descendants()
                    self.logger.info(f"  Total de descendientes: {len(descendants)}")
                    
                    for idx, descendant in enumerate(descendants):
                        try:
                            desc_text = descendant.window_text().strip()
                            
                            # Búsqueda exacta: "Proceso de Embargo"
                            if desc_text == "Proceso de Embargo":
                                self.logger.info(f"  'Proceso de Embargo' encontrado en índice {idx}")
                                rect = descendant.rectangle()
                                
                                if rect.width() > 0 and rect.height() > 0:
                                    click_x = (rect.left + rect.right) // 2
                                    click_y = (rect.top + rect.bottom) // 2
                                    self.logger.info(f"  Coordenadas válidas: ({click_x}, {click_y})")
                                    pyautogui.click(click_x, click_y)
                                    self.logger.info("  Esperando 2 segundos para que se expanda el menú...")
                                    time.sleep(2)
                                    self.logger.info("  [1/3] Clic en Proceso de Embargo completado")
                                    return True
                        
                        except Exception:
                            pass
                
                except Exception as e:
                    self.logger.warning(f"Error iterando descendientes: {e}")
            
            self.logger.warning("  No se pudo encontrar 'Proceso de Embargo'")
            return False
        
        except Exception as e:
            self.logger.error(f"Error en click_proceso_embargo_for_restart: {e}")
            return False
    
    
    def fill_monto(self, monto_value: str) -> bool:
        self.logger.info("Rellenando campo de MONTO...")
        
        try:
            # ============================================================
            # PASO 1: Esperar 0.5s y digitar MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 1: Esperando 0.5s y digitando MONTO")
            self.logger.info("=" * 70)
            
            # Esperar 0.5 segundos antes de digitar MONTO
            self.logger.info("Esperando 0.5 segundos antes de digitar MONTO...")
            time.sleep(0.5)
            
            # Digitar MONTO directamente con intervalo entre caracteres
            self.logger.info(f"Digitando MONTO: '{monto_value}'")
            pyautogui.write(monto_value, interval=0.05)
            time.sleep(0.3)
            
            # ============================================================
            # PASO 2: Presionar ALT+A para confirmar
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 2: Presionando ALT+A para confirmar MONTO")
            self.logger.info("=" * 70)
            
            self.logger.info("Presionando ALT+A...")
            pyautogui.hotkey('alt', 'a')
            time.sleep(1)
            self.logger.info(" ALT+A presionado correctamente")
            
            # ============================================================
            # PASO 3: Detectar mensaje de aviso del MONTO
            # ============================================================
            self.logger.info("=" * 70)
            self.logger.info("PASO 3: Detectando posible mensaje de aviso del MONTO")
            self.logger.info("=" * 70)
            
            self.logger.info("Aviso (si existe) será detectado en paso posterior")
            
            self.logger.info("=" * 70)
            self.logger.info(" CAMPO MONTO COMPLETADO EXITOSAMENTE")
            self.logger.info("=" * 70)
            
            return True
        
        except Exception as e:
            self.logger.error(f"Error en fill_monto: {str(e)}")
            return False
    
    # EXTRACCIÓN DE RC
    
    def _extract_rc_from_dialog(self) -> Optional[str]:
        try:
            desktop = Desktop(backend=MSAA_BACKEND)
            
            for element in self.iter_all_descendants():
                try:
                    text = str(element.element_info.name or "").lower()
                    
                    if "se grabó" in text and "resolución" in text and "número" in text:
                        # Encontrado el mensaje, extraer número
                        full_text = str(element.element_info.name or "")
                        
                        # Buscar la palabra "número" y extraer dígitos después
                        idx = full_text.lower().find("número")
                        if idx >= 0:
                            after_numero = full_text[idx + 6:]
                            # Extraer dígitos consecutivos
                            rc = ""
                            for char in after_numero:
                                if char.isdigit():
                                    rc += char
                                elif rc:  # Si ya tenemos dígitos y encontramos no-dígito, terminar
                                    break
                            
                            if rc:
                                return rc
                except Exception:
                    continue
            
            return None
        
        except Exception as e:
            self.logger.warning(f"Error extrayendo RC: {e}")
            return None
