"""
main.py - Orquestación principal de la automatización RSIRAT
Responsabilidades:
  1. Cargar Excel (EXPEDIENTES.xlsx)
  2. Agrupar expedientes por DEPENDENCIA
  3. Determinar orden (mayor cantidad primero)
  4. Inicializar logger y AppDriver
  5. Llamar workflow.process_dependency por cada dependencia
  6. Guardar resultados en R_EXPEDIENTES.xlsx
  7. Finalizar limpiamente
"""
import logging
import sys
from pathlib import Path
from datetime import datetime
import shutil
import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

from app_driver import AppDriver
from logica import process_dependency, Outcome


# CONSTANTES
SCRIPT_DIR = Path(__file__).parent if getattr(sys, 'frozen', False) == False else Path(sys.executable).parent
EXCEL_INPUT = SCRIPT_DIR / "EXPEDIENTES.xlsx"
PASSWORD_FILE = SCRIPT_DIR / "contraseña.txt"
SHORTCUT_PATH = SCRIPT_DIR / "Actualiza RSIRAT.lnk"
IMG_DIR = SCRIPT_DIR / "IMG"

# Directorio de resultados con timestamp
def _get_results_dir():
    now = datetime.now()
    timestamp_str = now.strftime("%d")  # Día con D
    timestamp_str += now.strftime("D_%m").replace("_", "M_")  # Mes con M
    timestamp_str = now.strftime("%dD_%mM_%YY_%HH_%MM_%SS")
    
    timestamp_str = now.strftime("%d").zfill(2) + "D_" + \
                    now.strftime("%m").zfill(2) + "M_" + \
                    now.strftime("%Y") + "_" + \
                    now.strftime("%H").zfill(2) + "H_" + \
                    now.strftime("%M").zfill(2) + "M_" + \
                    now.strftime("%S").zfill(2) + "S"
    
    folder_name = f"RESULTADO_RSIRAT-PRUEBA_{timestamp_str}"
    results_dir = SCRIPT_DIR / folder_name
    results_dir.mkdir(exist_ok=True)
    return results_dir

RESULTS_DIR = _get_results_dir()
EXCEL_OUTPUT = RESULTS_DIR / "R_EXPEDIENTES.xlsx"
LOG_FILE = RESULTS_DIR / "proceso_log32.txt"


# UTILIDADES LOGGER
class SimpleFormatter(logging.Formatter):
    """Formatter simple que PRESERVA tildes y diacríticos."""
    def format(self, record):
        try:
            # No remover tildes - preservar el texto original
            # Los tildes son información importante para búsqueda de elementos en MSAA
            pass
        except Exception:
            pass
        return super().format(record)


def setup_logger():
    """Configura logger con archivo y consola."""
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    
    # File handler
    file_handler = logging.FileHandler(LOG_FILE, encoding='utf-8')
    file_handler.setLevel(logging.INFO)
    
    # Stream handler (consola)
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    
    # Formatter
    fmt = '%(asctime)s - %(levelname)s - %(message)s'
    formatter = SimpleFormatter(fmt)
    file_handler.setFormatter(formatter)
    stream_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    
    return logger


# CARGA Y VALIDACIÓN EXCEL
def load_excel_expedientes():
    """Carga EXPEDIENTES.xlsx y retorna DataFrame."""
    if not EXCEL_INPUT.exists():
        raise FileNotFoundError(f"No existe {EXCEL_INPUT}")
    
    # Leer la columna EXPEDIENTE como texto para preservar ceros iniciales
    try:
        df = pd.read_excel(EXCEL_INPUT, dtype={"EXPEDIENTE": str}, keep_default_na=False)
    except Exception:
        # Fallback genérico
        df = pd.read_excel(EXCEL_INPUT)
    
    # Limpiar caracteres de control (\r, \n) de todas las columnas de texto
    # Esto es critico porque algunos Excel pueden tener saltos de linea embebidos
    for col in df.columns:
        if df[col].dtype == 'object':  # String/object columns
            df[col] = df[col].apply(lambda x: x.replace('\r', '').replace('\n', '').strip() if isinstance(x, str) else x)
    
    # Validar columnas obligatorias
    required_cols = ["DEPENDENCIA", "MEDIDA", "INTERVENTOR", "PLAZO", "MONTO", "EXPEDIENTE"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas: {missing}")
    
    return df


def load_password():
    if not PASSWORD_FILE.exists():
        raise FileNotFoundError(f"No existe {PASSWORD_FILE}")
    
    with open(PASSWORD_FILE, "r", encoding="utf-8") as f:
        return f.read().strip()


def group_by_dependencia(df):
    """
    Agrupa expedientes por DEPENDENCIA.
    Retorna dict: {"21": [indices], "23": [indices]}
    Orden: dependencia con más expedientes primero.
    """
    dep_21 = df[df["DEPENDENCIA"].astype(str).str.strip() == "21"].index.tolist()
    dep_23 = df[df["DEPENDENCIA"].astype(str).str.strip() == "23"].index.tolist()
    
    result = {}
    if dep_21:
        result["21"] = dep_21
    if dep_23:
        result["23"] = dep_23
    
    # Ordenar por cantidad (descendente): mayor cantidad primero
    sorted_deps = sorted(result.keys(), key=lambda d: len(result[d]), reverse=True)
    
    return {d: result[d] for d in sorted_deps}


# ACTUALIZACIÓN RESULTADOS EXCEL
def ensure_r_expedientes_exists(df_original):
    """
    Si R_EXPEDIENTES.xlsx no existe, lo crea como copia de EXPEDIENTES.xlsx.
    Preserva:
      - Ancho de columnas
      - Colores de celdas
      - Filtros
    Luego agrega la columna RESULTADO si no existe.
    """
    if not EXCEL_OUTPUT.exists():
        # Copiar archivo base completo
        shutil.copy(EXCEL_INPUT, EXCEL_OUTPUT)
        logger = logging.getLogger(__name__)
        
        # Cargar el workbook copiado
        try:
            wb = load_workbook(EXCEL_OUTPUT)
            ws = wb.active
            
            # Obtener headers para encontrar si existe RESULTADO
            headers = {}
            for idx, cell in enumerate(ws[1], 1):
                if cell.value:
                    headers[cell.value] = idx
            
            # Si no existe RESULTADO, agregarlo
            if "RESULTADO" not in headers:
                resultado_col = len(headers) + 1
                ws.cell(row=1, column=resultado_col, value="RESULTADO")
                logger.info(f"   Columna RESULTADO agregada en columna {get_column_letter(resultado_col)}")
            
            # Aplicar formato de texto a todas las celdas para consistencia
            for row in ws.iter_rows():
                for cell in row:
                    try:
                        if cell.number_format is None or cell.number_format == 'General':
                            cell.number_format = '@'
                    except Exception:
                        pass
            
            wb.save(EXCEL_OUTPUT)
        
        except Exception as e:
            logger = logging.getLogger(__name__)
            logger.warning(f"   No se pudieron preservar formatos completamente: {e}")


def update_result_in_excel(row_idx, outcome_str, rc_number=None):
    """
    Actualiza la columna RESULTADO en R_EXPEDIENTES.xlsx.
    
    Args:
        row_idx: índice 0-based de la fila (será row_idx + 2 en Excel)
        outcome_str: descripción del resultado (ej: "OK_RC", "EXP_INVALIDO", etc.)
        rc_number: número de RC si aplica (se guarda como STRING para preservar 0s)
    """
    try:
        logger = logging.getLogger(__name__)
        wb = load_workbook(EXCEL_OUTPUT)
        ws = wb.active
        
        # Crear columa RESULTADO si no existe
        headers = {cell.value: idx for idx, cell in enumerate(ws[1], 1) if cell.value}
        if "RESULTADO" not in headers:
            resultado_col = len(headers) + 1
            ws.cell(row=1, column=resultado_col, value="RESULTADO")
        else:
            resultado_col = headers["RESULTADO"]
        
        # Escribir resultado
        target_row = row_idx + 2  # +1 header, +1 0-based
        
        if rc_number:
            # Si tenemos RC, guardarlo como TEXTO (string) para preservar 0s iniciales
            # Ejemplo: "00123456" no "123456"
            result_value = str(rc_number)
            cell = ws.cell(row=target_row, column=resultado_col, value=result_value)
            
            # Forzar formato texto en la celda (openpyxl)
            # data_type='s' indica que es un STRING en openpyxl
            cell.data_type = 's'
            
            # También aplicar formato de celda como texto
            cell.number_format = '@'
            
            logger.info(f"  RC guardada como TEXTO en Excel (fila {target_row}): '{result_value}'")
        else:
            # Si no hay RC, guardar el mensaje de outcome
            result_value = outcome_str
            cell = ws.cell(row=target_row, column=resultado_col, value=result_value)
            logger.info(f"  Resultado guardado en Excel (fila {target_row}): '{result_value}'")
        
        wb.save(EXCEL_OUTPUT)
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error actualizando Excel fila {row_idx + 1}: {e}")


def auto_fit_excel_columns():
    """Ajusta solo el ancho de la columna RESULTADO sin modificar las demás."""
    try:
        wb = load_workbook(EXCEL_OUTPUT)
        ws = wb.active
        
        # Encontrar la columna RESULTADO
        headers = {}
        for idx, cell in enumerate(ws[1], 1):
            if cell.value:
                headers[cell.value] = idx
        
        if "RESULTADO" in headers:
            resultado_col_idx = headers["RESULTADO"]
            resultado_col_letter = get_column_letter(resultado_col_idx)
            
            # Calcular ancho apropiado para RESULTADO
            max_length = len("RESULTADO")  # Header
            for row_idx in range(2, ws.max_row + 1):
                cell = ws.cell(row=row_idx, column=resultado_col_idx)
                if cell.value:
                    cell_length = len(str(cell.value))
                    if cell_length > max_length:
                        max_length = cell_length
            
            # Ajustar ancho de RESULTADO con margen
            adjusted_width = min(max_length + 2, 30)  # Máximo 30 de ancho
            ws.column_dimensions[resultado_col_letter].width = adjusted_width
            
            wb.save(EXCEL_OUTPUT)
            logger = logging.getLogger(__name__)
        else:
            logger = logging.getLogger(__name__)
            logger.info("  Columna RESULTADO no encontrada, sin ajustes")
    
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error(f"Error ajustando ancho de RESULTADO: {e}")


# MAIN
def main():
    """Orquestación principal."""
    logger = setup_logger()
    
    logger.info("=" * 70)
    logger.info("INICIANDO AUTOMATIZACIÓN RSIRAT")
    logger.info("=" * 70)
    logger.info(f"Directorio de trabajo: {SCRIPT_DIR}")
    
    try:
        # -------- Cargar datos --------
        df_expedientes = load_excel_expedientes()
        password = load_password()
        logger.info(f"   Cargados {len(df_expedientes)} expedientes")
        
        # -------- Agrupar por dependencia --------
        deps_items = group_by_dependencia(df_expedientes)
        
        if not deps_items:
            logger.error("No hay expedientes válidos (DEPENDENCIA vacía)")
            return False
        
        logger.info(f"   {len(deps_items)} dependencia(s) encontrada(s)")
        for dep, indices in deps_items.items():
            logger.info(f"    - Dependencia {dep}: {len(indices)} expediente(s)")
        
        # -------- Crear archivo de salida --------
        ensure_r_expedientes_exists(df_expedientes)        
        
        # Configurar ruta del JSON de caché (en RESULTS_DIR para acceso en ejecutable)
        cache_json_path = RESULTS_DIR / "coords_cache.json"
        
        driver = AppDriver(logger, SHORTCUT_PATH, img_dir=IMG_DIR, cache_path=cache_json_path)
        
        # -------- Procesar cada dependencia --------
        all_outcomes = []
        for dep_order, (dependencia, indices) in enumerate(deps_items.items(), 1):
            logger.info("\n" + "=" * 70)
            logger.info(f"[DEPENDENCIA {dep_order}/{len(deps_items)}] Procesando DEP={dependencia}")
            logger.info("=" * 70)
            
            # Siempre abrir la app para cada dependencia (se cierra entre dependencias)
            is_first = True
            is_last = (dep_order == len(deps_items))
            
            # Procesar dependencia
            outcomes = process_dependency(
                dependencia=dependencia,
                indices=indices,
                df=df_expedientes,
                driver=driver,
                update_result_fn=update_result_in_excel,
                is_first=is_first,
                is_last=is_last,
                logger=logger,
                password=password
            )
            
            all_outcomes.extend(outcomes)
            
            # Si hubo FAIL_LOGIN_PASSWORD, detener todo
            if any(o.outcome == Outcome.FAIL_LOGIN_PASSWORD for o in outcomes):
                break
            
            # Si no es la última, cerrar app (Alt+F4) antes de siguiente dependencia
            if not is_last:
                logger.info("\nCerrando aplicación para cambiar de dependencia...")
                driver.close_app()
        
        # -------- Resumen final --------
        logger.info("\n" + "=" * 70)
        logger.info("RESUMEN FINAL")
        logger.info("=" * 70)
        
        success_count = sum(1 for o in all_outcomes if o.outcome == Outcome.OK_RC)
        skip_count = sum(1 for o in all_outcomes if "SKIP" in o.outcome.name)
        fail_count = sum(1 for o in all_outcomes if "FAIL" in o.outcome.name)
        
        logger.info(f"  Éxito (RC grabada):     {success_count}")
        logger.info(f"  Saltos (inválidos):     {skip_count}")
        logger.info(f"  Fallos (UI/config):     {fail_count}")
        logger.info(f"  TOTAL:                  {len(all_outcomes)}")
        
        # -------- Guardar caché de coordenadas --------
        driver.coords_cache.save_to_json(cache_json_path)
        
        # -------- Auto-ajustar columnas en Excel --------
        auto_fit_excel_columns()
        
        logger.info("\n Proceso completado")
        return True
    
    except Exception as e:
        logger.error(f"\n[CRÍTICO] Error no controlado: {e}", exc_info=True)
        return False
    
    finally:
        logger.info("=" * 70)


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)