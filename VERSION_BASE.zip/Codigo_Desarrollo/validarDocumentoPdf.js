const fs = require('fs/promises');
const path = require('path');

async function obtenerRutaDocumentoPdf(carpetaRutaDescarga) {
    // const rutaDocumentoPdf = path.join(carpetaRutaDescarga, nombreDocumento);
    try {

        let estado = false
        let tiempoAcumulado = 0 //segundos de espera
        let tiempoEspera = 5000

        while (estado == false) {
            await new Promise(resolve => setTimeout(resolve, tiempoEspera));
            tiempoAcumulado += tiempoEspera

            // Leer el contenido de la carpeta
            const archivos = await fs.readdir(carpetaRutaDescarga);

            // Encontrar el archivo PDF
            const archivoPDF = archivos.find(archivo => path.extname(archivo).toLowerCase() === '.pdf');
            // const archivoExcel = archivos.find(archivo => path.extname(archivo).toLowerCase() === '.xlsx');

            if (archivoPDF) {

                const rutaDocumentoPdf = path.join(carpetaRutaDescarga, archivoPDF);
                //console.log(`---> Documento ${archivoPDF} renombrado y movido a ${nuevaRutaCompleta}`);
                estado = true

                //console.log(rutaDocumentoPdf)

                return rutaDocumentoPdf
            // }
            //estado = true
            // } else {
            //     console.log('-> Consultando ...')
            //     if (archivoExcel) {
            //         const rutaDocumentoExcel = path.join(carpetaRutaDescarga, archivoExcel)
            //         await fs.unlink(rutaDocumentoExcel);
            //         return false
            //     }

            } if (tiempoAcumulado >= 180000) { // 3 minutos
                throw new Error('Tiempo de espera acumulado excedido. Cerrando el navegador.');
            }
        }



    } catch (error) {
        console.error('---> Error al renombrar y mover el documento:', error);
    }


}

module.exports = obtenerRutaDocumentoPdf