const fs = require('fs/promises')
const pdf = require('pdf-parse');

async function ObtenerLiquidacionMemo(pdfPath) {

    try {

        const dataBuffer = await fs.readFile(pdfPath)
        const pdfData = await pdf(dataBuffer)
        const text = pdfData.text

        // console.log(text)

        if (text) {

            const numeroLiquidacion = text.match(/Cobranza.\s*(\d{3}-(\d{4}|\d{3}|\d{2})-(\d{6}|\d{5}))/);

            const totalDigitosNumeroLiquidacion = numeroLiquidacion[1].length

            // console.log(totalDigitosNumeroLiquidacion)

            let numeroLiquidacionValidada = numeroLiquidacion[1]

            if(totalDigitosNumeroLiquidacion === 14){
                
                const codigoAduana = numeroLiquidacion[1].split('-')[0]
                const anio = numeroLiquidacion[1].split('-')[1]
                const numeroLiquidacionCobranza = numeroLiquidacion[1].split('-')[2]
                
                numeroLiquidacionValidada = `${codigoAduana}-${anio}-0${numeroLiquidacionCobranza}`
            }

            return numeroLiquidacionValidada ? numeroLiquidacionValidada : false;
        }

    } catch (error) {

        console.log('No se encontro coincidencia')

        return false

    }
}

module.exports = ObtenerLiquidacionMemo;


// const datafile = 'Memo.pdf'
// const datafile = 'nuevo_caso.pdf'
// const datafile = 'rec_extensa1.pdf'
// const datafile = 'test.pdf'
// const datafile = 'primerFiltro.pdf'
// const datafile = 'filtro.pdf'
// const datafile = "Analisis.pdf"


// async function basic(){

//     const Resultados = await ObtenerLiquidacionMemo(datafile);

//     // console.log(Resultados.length)

//     console.log(Resultados)

//     // await fs.unlink(datafile);
// }

// basic()

