const puppeteer = require('puppeteer')
const selectorIntranet = require('./loginIntranet.json')
const selectoreChaski = require('./eChaski.json')

const ExcelService = require('./excelService')
const ExtraerDatosPdf = require('./echaskiModelo')
const getChromeExecutablePath = require('./rutaChrome')
const CrearDirectorioDescargas = require('./directorioResultado')
const obtenerRutaDocumentoPdf = require('./validarDocumentoPdf')
const loadUserAccountFile = require('./leerCredenciales')
const obtenerlc = require('./validarlc')

const path = require('path')
const fs = require('fs/promises')

let carpetaRutaDescarga

async function eChaskiIntranet() {

    let browser

    try {

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: true,
            defaultViewport: false,
            slowMo: 50,
            args: ['--start-maximized'],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await eChaskiIntranet();
            });
        }

        //Encabezados Temporales
        const EncabeazadosConsultaEChaski = [
            { header: 'NUMERO CONSULTA', key: 'numero_consulta', width: 4 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento', width: 17 },
            { header: 'NUMERO DOCUMENTO', key: 'numero_documento', width: 25 },
            { header: 'FECHA GENERACIÓN', key: 'fecha_generacion', width: 18 },
            { header: 'DERIVADO POR', key: 'derivador_por', width: 35 },
            { header: 'FECHA ULT. DERIVACIÓN', key: 'fecha_ult_derivacion', width: 21 },
            { header: 'ASUNTO', key: 'asunto', width: 56 },
            { header: 'ESTADO', key: 'estado', width: 9 },
            { header: 'REC ENCONTRADA', key: 'rec_encontrada', width: 16 }
        ]

        const EncabezadosConsultaREC = [
            { header: 'NUMERO CONSULTA', key: 'numero_consulta', width: 4 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento', width: 17 },
            { header: 'NUMERO DOCUMENTO', key: 'numero_documento', width: 25 },
            { header: 'FECHA GENERACIÓN', key: 'fecha_generacion', width: 18 },
            { header: 'DERIVADO POR', key: 'derivador_por', width: 35 },
            { header: 'FECHA ULT. DERIVACIÓN', key: 'fecha_ult_derivacion', width: 21 },
            { header: 'ASUNTO', key: 'asunto', width: 56 },
            { header: 'ESTADO', key: 'estado', width: 9 },
            { header: 'CODIGO ADUANA', key: 'codigo_aduana', width: 10 },
            { header: 'AÑO', key: 'anio', width: 4 },
            { header: 'NÚMERO LIQUIDACIÓN', key: 'numero_liquidacion', width: 20 },
            { header: 'NÚMERO LIQUIDACIÓN COMPLETO', key: 'numero_liquidacion_unico', width: 30 },
            { header: 'NÚMERO EXPEDIENTE', key: 'numero_expediente', width: 19 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento_rec', width: 16 },
            { header: 'NÚMERO DOCUMENTO', key: 'numero_documento_rec', width: 20 },
            { header: 'RAZÓN SOCIAL', key: 'razon_social', width: 41 },
        ]

        const rutaArchivoUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')
        const rutaArchivoContrasena = path.resolve(process.cwd(), 'Credenciales', 'contraseña.txt')

        const textoUsuario = await loadUserAccountFile(rutaArchivoUsuario)
        const textoPassword = await loadUserAccountFile(rutaArchivoContrasena)

        console.clear()
        console.log("******** CONSULTA Echaski - MEMORÁNDUM ********")

        const page = await browser.newPage()

        await page.goto(selectorIntranet.URLIntranet)

        console.log("Digitando Usuario ...")

        const campoUsuario = await page.waitForSelector(selectorIntranet.campoUsuario, { waitUntil: "networkidle0" })

        await campoUsuario.type(textoUsuario)

        console.log("Digitando Contraseña ...")

        const campoContraseña = await page.waitForSelector(selectorIntranet.campoClave, { waitUntil: "networkidle0" })

        await campoContraseña.type(textoPassword)

        console.log("Iniciando Sesión ...")

        const botonIniciarSesion = await page.waitForSelector(selectorIntranet.botonIniciarSesion, { waitUntil: "networkidle0" })

        await botonIniciarSesion.click()

        await new Promise((resolve) => setTimeout(resolve, 3000))

        const excelResultados = new ExcelService()

        let indiceConsulta

        const validarExcel = await excelResultados.AbrirDocumentoExcel(carpetaRutaDescarga, 'RESULTADO_CONSULTA_ECHASKI')

        if (validarExcel) {

            // console.log(`Valida excel: True`)

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_ECHASKI', EncabeazadosConsultaEChaski)

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_REC', EncabezadosConsultaREC)

            indiceConsulta = excelResultados.ObtenerUnaCeldaUltimaFila('CONSULTA_ECHASKI', 'A')


        } else {
            // console.log(`Valida excel: False`)

            excelResultados.AgregarHojaExcel('CONSULTA_ECHASKI')

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_ECHASKI', EncabeazadosConsultaEChaski)

            excelResultados.AgregarHojaExcel('CONSULTA_REC')

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_REC', EncabezadosConsultaREC)

            indiceConsulta = 0

        }

        await page.goto(selectoreChaski.URLeChaski)

        // Enable CDP
        const client = await page.target().createCDPSession();

        await client.send('Page.setDownloadBehavior', {
            behavior: 'allow',
            downloadPath: carpetaRutaDescarga
        });

        const opcionSelecionarMiBandeja = await page.waitForSelector(selectoreChaski.SeleccionarMiBandeja, { waitUntil: "networkidle0" })

        await opcionSelecionarMiBandeja.click()

        const opcionSelecionarBandejaDocumentos = await page.waitForSelector(selectoreChaski.SeleccionarBandejaDocumentos, { waitUntil: "networkidle0" })

        await opcionSelecionarBandejaDocumentos.click()

        await new Promise((resolve) => setTimeout(resolve, 5000))

        //Vamos a capturar los frames presentes en la plataforma web

        let framesDet = await page.waitForFrame(async frame => { return frame.name() === selectoreChaski.FrameDet })

        const opcionMostrarRegistros = await framesDet.waitForSelector('select[name="tblSolicitudGenerada_length"]')

        await opcionMostrarRegistros.type('100')

        await framesDet.waitForSelector(selectoreChaski.ListadoDeDocumentosPendientes)

        const documentosAdjuntos = await framesDet.$$(selectoreChaski.ListadoDeDocumentosPendientes)

        //console.log(`Número total de consultas ${documentosAdjuntos}`)

        for (const [index, documentoAdjunto] of documentosAdjuntos.entries()) {

            console.log(`-> Numero de consulta ${index + 1} de ${documentosAdjuntos.length} `)

            if (index >= indiceConsulta) {

                let resultadoConsulta = {}

                const documento = await documentoAdjunto.evaluate((elemento) => {
                    const tipoDocumento = elemento.querySelector("td:nth-child(2) > p")
                    const numeroDocumento = elemento.querySelector("td:nth-child(3) > a")
                    const fechaGeneracion = elemento.querySelector("td:nth-child(4)")
                    const derivadoPor = elemento.querySelector("td:nth-child(5) > p")
                    const fechaUltimaDerivacion = elemento.querySelector("td.centered.sorting_1")
                    const asunto = elemento.querySelector("td:nth-child(7) > p")
                    const estado = elemento.querySelector("td:nth-child(8)")

                    //const numeroDocumento = elemento.querySelector(selectoreChaski.NumeroDocumento)

                    return {
                        tipoDocumento: tipoDocumento ? tipoDocumento.innerText : null,
                        numeroDocumento: numeroDocumento ? numeroDocumento.innerText : null,
                        fechaGeneracion: fechaGeneracion ? fechaGeneracion.innerText : null,
                        derivadoPor: derivadoPor ? derivadoPor.innerText : null,
                        fechaUltimaDerivacion: fechaUltimaDerivacion ? fechaUltimaDerivacion.innerText : null,
                        asunto: asunto ? asunto.getAttribute('data-content') : null,
                        estado: estado ? estado.innerText : null
                    }
                })

                resultadoConsulta = {
                    numero_consulta: index + 1,
                    tipo_documento: documento.tipoDocumento,
                    numero_documento: documento.numeroDocumento,
                    fecha_generacion: documento.fechaGeneracion,
                    derivador_por: documento.derivadoPor,
                    fecha_ult_derivacion: documento.fechaUltimaDerivacion,
                    asunto: documento.asunto,
                    estado: documento.estado,
                }

                // SE ACEPTA EL CASO FIRMADO
                const CASO_ESTADO_FIRMADO = "FIRMADO"
                const CASO_ESTADO_REVISION = "EN REVISIÓN"
                const CASO_ESTADO_SEGUIMIENTO = "EN SEGUIMIENTO"

                // const archivoAdjunto = await documentoAdjunto.waitForSelector(selectoreChaski.ArchivoAdjunto)

                // await archivoAdjunto.click()

                await documentoAdjunto.$eval(selectoreChaski.ArchivoAdjunto, elemento => elemento.click())

                const documentosAdjuntoSeg = await framesDet.waitForSelector("#tabs > li:nth-child(2) > a")

                await documentosAdjuntoSeg.click()

                // Futura implementacion de reconocmiento

                // let validarNumeroRegistro

                // try{

                //     validarNumeroRegistro = await framesDet.waitForSelector(botonListaFilas, {visible:true, timeout:5000})

                //     const botonCantidadRegistros = await framesDet.waitForSelector(botonListaFilas)

                //     await botonCantidadRegistros.click()

                //     await framesDet.waitForSelector(RutasDeLasFilas)

                //     const elementosArreglo = await framesDet.$$(RutasDeLasFilas)

                //     console.log(elementosArreglo)



                // }catch(e){

                //     validarNumeroRegistro = false

                // }

                let numeroLc

                await framesDet.waitForSelector(selectoreChaski.ListaDocumentosAdjuntos)

                const tablaDocumentosAdjuntos = await framesDet.$$(selectoreChaski.ListaDocumentosAdjuntos)

                // console.log("Tabla de documentos adjuntos : ", tablaDocumentosAdjuntos)

                // console.log(tablaDocumentosAdjuntos.length)

                for (const filaDocumentoAdjunto of tablaDocumentosAdjuntos) {

                    const clipVerDocumento = await filaDocumentoAdjunto.$("a[aria-label='Ver']")

                    //console.log(index, '|', clipVerDocumento)

                    if (clipVerDocumento) {

                        await filaDocumentoAdjunto.$eval("a[aria-label='Ver']", elemento => elemento.click())

                        //await clipVerDocumento.click()

                        // const verDocumento = await filaDocumentoAdjunto.waitForSelector("a[aria-label='Ver']")

                        // await verDocumento.click()

                        await new Promise((resolve) => setTimeout(resolve, 5000))

                        await framesDet.waitForSelector("#tblDocumentosSeguimPopup > tbody > tr")

                        const tablaDocumentosAdjuntos2 = await framesDet.$$("#tblDocumentosSeguimPopup > tbody > tr")

                        for (const filaDescargaDocumento of tablaDocumentosAdjuntos2) {

                            const textoREC = await filaDescargaDocumento.evaluate((elemento) => {
                                // const descripcion = elemento.querySelector('td:nth-child(1)')
                                const texto = elemento.querySelector('td:nth-child(1)')
                                const nombreDocumento = elemento.querySelector('td:nth-child(2)')
                                return {
                                    texto: texto ? texto.innerText : null,
                                    nombreDocumento: nombreDocumento ? nombreDocumento.innerText : null
                                }
                            })

                            console.log(textoREC.texto)

                            if (textoREC.nombreDocumento.toLowerCase().trim().includes('.pdf') && (textoREC.texto.toLowerCase().trim().includes('firmado') || textoREC.texto.toLowerCase().trim().includes('rec'))) {

                                const botonDescargar = await filaDescargaDocumento.waitForSelector('td:nth-child(4) > a')
                                await botonDescargar.click()

                                // await filaDocumentoAdjunto.$eval("td:nth-child(4) > a", elemento => elemento.click())

                                // Monitor download progress
                                client.on('Page.downloadProgress', (event) => {
                                    if (event.state === 'completed') {
                                        console.log('Download completed');
                                    }
                                });

                                const rutaDocumentoPdf = await obtenerRutaDocumentoPdf(carpetaRutaDescarga);

                                // console.log(rutaDocumentoPdf)    

                                let consulta_rec = {}
                                let diccionarioMemo = {}
                                let consultaLc

                                // console.log()

                                if (textoREC.texto.toLowerCase().trim().includes('firmado')) {

                                    numeroLc = await obtenerlc(rutaDocumentoPdf)

                                    // console.log(numeroLc)

                                    consultaLc = true

                                    await fs.unlink(rutaDocumentoPdf);

                                } else {

                                    consultaLc = false

                                    resultadoConsulta = {
                                        ...resultadoConsulta,
                                        "rec_encontrada": "No"
                                    }

                                    // await fs.unlink(rutaDocumentoPdf);
                                }

                                // const numeroLc = await obtenerlc(rutaDocumentoPdf)

                                // console.log(numeroLc)

                                console.log('El valor de la LC es', numeroLc)

                                // if (numeroLc && !consultaLc) {
                                if (textoREC.texto.toLowerCase().trim().includes('rec')) {
                                    const informacionMemo = await ExtraerDatosPdf(rutaDocumentoPdf, numeroLc);

                                    console.log(`resultado Memo: ${informacionMemo}`)

                                    if (informacionMemo) {

                                        console.log('--> REC encontrada')

                                        resultadoConsulta = {
                                            ...resultadoConsulta,
                                            "rec_encontrada": "Sí"
                                        }

                                        console.log('---> Analizando Documento')

                                        if (resultadoConsulta["rec_encontrada"] == "Sí") {
                                            for (const datoMemo of informacionMemo) {

                                                diccionarioMemo["codigo_aduana"] = datoMemo["codigoAduana"]
                                                diccionarioMemo["anio"] = datoMemo["anio"]
                                                diccionarioMemo["numero_liquidacion"] = datoMemo["numeroLiquidacion"]
                                                diccionarioMemo["numero_liquidacion_unico"] = datoMemo["numeroLiquidacionUnico"]
                                                diccionarioMemo["numero_expediente"] = datoMemo["numeroExpediente"]
                                                diccionarioMemo["tipo_documento_rec"] = datoMemo["tipoDocumento"]
                                                diccionarioMemo["numero_documento_rec"] = datoMemo["numeroDocumento"]
                                                diccionarioMemo["razon_social"] = datoMemo["razonSocial"]

                                                consulta_rec = {
                                                    ...resultadoConsulta,
                                                    ...diccionarioMemo
                                                }

                                                excelResultados.AgregarFilaHojaExcel('CONSULTA_REC', consulta_rec)
                                            }

                                        }


                                    } else {

                                        console.log('--> REC no encontrada')

                                        resultadoConsulta = {
                                            ...resultadoConsulta,
                                            "rec_encontrada": "No"
                                        }
                                    }

                                    // await fs.unlink(rutaDocumentoPdf);
                                }

                            }

                        }

                        const botonCerrrarDocumentosAdjuntos = await framesDet.waitForSelector('::-p-xpath(//*[@id="divDocumentosSeguim"]/div[2]/div/div[1]/button)')

                        await botonCerrrarDocumentosAdjuntos.click()
                    }

                }

                excelResultados.AgregarFilaHojaExcel('CONSULTA_ECHASKI', resultadoConsulta)

                await excelResultados.GuardarExcel(carpetaRutaDescarga, 'RESULTADO_CONSULTA_ECHASKI')

                await framesDet.$eval("::-p-xpath(//*[@id='divAdjuntoResol']/div[2]/div/div[1]/button)", elemento => elemento.click())

                if (index + 1 == documentosAdjuntos.length) {
                    await browser.close()
                    console.log("******** CONSULTA TERMINADA ********")
                }


            } else {
                console.log('Siguiente Consulta')
                console.clear()
            }

            if (index + 1 == documentosAdjuntos.length) {
                await browser.close()
                console.log("******** CONSULTA TERMINADA ********")
            }



        }
    } catch (error) {
        console.error('Error al iniciar el navegador o realizar consultas:', error);
        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(eChaskiIntranet, 15000)
    }


}


async function Main() {
    carpetaRutaDescarga = await CrearDirectorioDescargas()
    await eChaskiIntranet()
}

Main()