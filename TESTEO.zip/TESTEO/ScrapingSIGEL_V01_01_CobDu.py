#enconding: utf-8
# =============================
# Importación de librerías necesarias para la automatización, manejo de archivos, imágenes y datos
# =============================
from selenium import webdriver # SOLO con selenium podemos usar driver para automatización web
from selenium.webdriver.support.ui import Select # Para manejar menús desplegables
from selenium.webdriver.common.keys import Keys # Para simular pulsaciones de teclas
from selenium.webdriver.common.action_chains import ActionChains # Para acciones avanzadas con el mouse/teclado
from selenium.webdriver.support.ui import WebDriverWait # Para esperas explícitas
from selenium.webdriver.support import expected_conditions as EC # Para condiciones de espera
from selenium.webdriver.common.by import By # Para localizar elementos
from selenium.common.exceptions import NoSuchElementException # Para manejar excepciones de elementos no encontrados
from getpass import getuser # Para obtener el usuario actual del sistema
# from datetime import date1
# from datetime import datetime1
# from PyPDF2 import PdfFileMerger
# import base64
import datetime # Para manejo de fechas y horas
import time # Para pausas y esperas
import os # Para operaciones del sistema operativo
import shutil # Para mover y eliminar archivos
# import pyperclip as clipboard
import pandas as pd # Para manejo de datos en Excel
import pyautogui as py # Para mostrar mensajes y diálogos al usuario
# import pyperclip as pyc
import constantes as cte # Archivo de constantes personalizadas
import json # Para manejo de datos en formato JSON
import openpyxl # Para manipulación avanzada de archivos Excel
# import numpy as np
from PIL import Image, ImageDraw, ImageFont # Para manipulación de imágenes y marcas de agua
# from datetime import datetime
from io import BytesIO # Para manejo de imágenes en memoria

# Implementación específica para Chrome
from selenium.webdriver.chrome.service import Service
import re # Para expresiones regulares


# ============================================================================== 
# Definición de funciones para el manejo del navegador Chrome
# ==============================================================================
# Esta función decide si el navegador se inicia en segundo plano (headless) o visible
# según la variable global 'inicio_diver'.
def IniciarGoogleChrome():
    if inicio_diver==0:
        IniciarGoogleChrome0(varInicial[1][0])
    else:
        IniciarGoogleChrome1(varInicial[1][0])
# ==============================================================================
# Inicializa Google Chrome en segundo plano (sin interfaz gráfica)
def IniciarGoogleChrome0(rtapp):  
    global driver # Variable global de navegador
    # Configuración para impresión en PDF y carpeta de descargas
    appState = {
    "recentDestinations": [
        {
            "id": "Save as PDF",
            "origin": "local",
            "account": ""
        }
    ],
    "mediaSize": {
        "name": "Pagina"
    },
    "selectedDestinationId": "Save as PDF",
    "version": 2  
    }
    download_path = rtapp + '\\' + 'Descargas' # Ruta donde se almacenan las descargas
    profile = {'printing.print_preview_sticky_settings.appState': json.dumps(appState),
               'savefile.default_directory': download_path }
    
    chrome_options = webdriver.ChromeOptions()
    # chrome_options.binary_location = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\new_chrome.exe"
    # chrome_options.binary_location = "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe"
    chrome_options.binary_location = varInicial[1][1] # Ruta personalizada de Chrome
    chrome_options.add_experimental_option('prefs', profile)
    chrome_options.add_argument('--kiosk-printing')
    chrome_options.add_argument('ignore-certificate-errors') # Ignora advertencias de certificados
    chrome_options.add_argument("--incognito")
    chrome_options.add_argument('--window-size=1024,768')
    chrome_options.add_argument("--hide-scrollbars") # Oculta barras de desplazamiento
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.page_load_strategy = 'normal' # Estrategia de carga de página
    chrome_options.add_argument("--headless") # Ejecuta Chrome en segundo plano
    chrome_options.add_argument('--log-level=3') # Reduce mensajes de advertencia
    path = rtapp +'\\chromedriver.exe'  # Ruta del ejecutable chromedriver
    executable_path=os.path.abspath(path) # Obtiene la ruta absoluta
    service_path = Service(executable_path)
    driver = webdriver.Chrome(service=service_path,options=chrome_options) # Inicia el navegador
    driver.maximize_window() # Maximiza la ventana (aunque esté en headless)
    return driver
# ======================================================================
#==============================================================================
# Procedimiento de Inicio de GoogleChrome Primer Plano
#==============================================================================
def IniciarGoogleChrome1(rtapp):  
    global driver # Variable global de navegador
    # Configuración para impresión en PDF y carpeta de descargas
    appState = {
    "recentDestinations": [
        {
            "id": "Save as PDF",
            "origin": "local",
            "account": ""
        }
    ],
    "mediaSize": {
        "name": "Pagina"
    },
    "selectedDestinationId": "Save as PDF",
    "version": 2  
    }
    download_path = rtapp + '\Descargas' # Ruta donde se almacenan las descargas
    profile = {'printing.print_preview_sticky_settings.appState': json.dumps(appState),
               'savefile.default_directory': download_path }
    
    chrome_options = webdriver.ChromeOptions()
    #chrome_options.binary_location = "C:\\Program Files (x86)\\Google\Chrome\\Application\\new_chrome.exe"
    chrome_options.binary_location = varInicial[1][1] # Ruta personalizada de Chrome
    chrome_options.add_experimental_option('prefs', profile)
    chrome_options.add_argument('--kiosk-printing')
    chrome_options.add_argument('ignore-certificate-errors') # Ignora ventanas no seguras por el certificado 
    chrome_options.add_argument("--incognito")
    #chrome_options.add_argument('--window-size=1024,768')
    chrome_options.add_argument("--hide-scrollbars") # Elimina la visulizacion de la barra de desplazamiento
    chrome_options.add_argument("start-maximized")
    chrome_options.add_argument("disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.page_load_strategy = 'normal' # Estrategia de carga de página
    #chrome_options.add_argument("--headless") # Inicia Chrome en segundo plano
    chrome_options.add_argument('--log-level=3') # Reduce mensajes de advertencia
    path = rtapp +'\\chromedriver.exe' # Ruta del ejecutable chromedriver
    executable_path=os.path.abspath(path) # Obtiene la ruta absoluta
    service_path = Service(executable_path)
    driver = webdriver.Chrome(service=service_path,options=chrome_options) # Inicia el navegador
    driver.maximize_window() # Maximiza la ventana
    return driver
#==============================================================================
# Cerrar el GoogleChrome
#==============================================================================
def CerrarGoogleChrome():#Cerrar GogleChrome
    driver.stop_client()#Deteniendo
    try:
        driver.close()#Cerrando el Chrome
    except:
        py.alert("Cerrando Robot")
    driver.quit()#Cerrando el Chrome
#==============================================================================
#==============================================================================
# Procedimientod e Inicio de Sesion.
# Se inicia Sesion  se cargan planos para el usuario y contraseña
#==============================================================================
def IniciarSesion():#Iniciar la sesion en el intranet y login
    print(f'-> Ruta del Chrome {varInicial[1][1]}')
    
    
    print("----> Proceso de Inicio de Sesion <----")
    rtapp1=varInicial [1][0]
    try:
        cont=0
        while cont<3:
            driver.refresh()
            try:
                driver.get("https://bpm.sunat.peru/ProcessPortal/login.jsp")#https://enlinea.sunarp.gob.pe/") #ventana para usuario y clave intranet
                cont=4
            except Exception as e: 
                print('Error en Ingreso de ' + str(cont))
                print(e)
                cont=cont+1
                    
        time.sleep(cte.TIME_3)#esperando
        path_usuario=rtapp1 + '\\usuario.txt'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
        abspath_usuario=os.path.abspath(path_usuario)#Ruta del archivo txt   
        with open (abspath_usuario) as Usuario: # USUARIO   
            for line in Usuario:  #Leyedo usuario intranet
                driver.find_element('name','j_username').send_keys(line) #Ingreso de usuario
        path_clave= rtapp1 + '\\clave.txt' #r'.\clave.txt'#Archivo tipo txt donde se encuentra la clave
        abspath_clave=os.path.abspath(path_clave)#Ruta donde se encuentra la clave
        with open (abspath_clave) as Clave: #Guarda CLAVE
            for line2 in Clave:    #Leyendo la clave
                driver.find_element('name','j_password').send_keys(line2) #Ingreso de clave
        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//*[@class='button ok']"))).click() #Boton de continuar
        #time.sleep(cte.TIME_3)#esperando
        cont=0
        while cont<3:
            try:
                if tipo_cuenta==1:
                    #btnpag1 = driver.find_element_by_xpath('//*[@title="A05 Administrar Expediente SIGEL"]')
                    btnpag1 =WebDriverWait(driver, 11).until(EC.presence_of_element_located((By.XPATH, '//*[@title="A05 Administrar Expediente SIGEL"]')))
                    #btnpag1 =WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '//*[@title="A05 Administrar Expediente SIGEL"]')))
                    driver.execute_script("arguments[0].click()", btnpag1)
                else:
                    #btnpag1=WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, '//*[@title="A05 Consultar Expedientes SIGEL"]')))
                    btnpag1=WebDriverWait(driver, 11).until(EC.presence_of_element_located((By.XPATH, '//*[@title="A05 Consultar Expedientes SIGEL"]')))
                    driver.execute_script("arguments[0].click()", btnpag1)
                cont=4
            except Exception as e: 
                print('Error en Ingreso de  ' + str(cont))
                print(e)
                cont=cont+1
                
    except Exception as e: 
        print('Error en Ingreso de  ' + str(cont))
        print(e)
#================================================================================
# Genera la carpeta general donde se almacenan los resultados de las búsquedas
# El nombre de la carpeta incluye el usuario y la fecha/hora para evitar duplicados
def capetaG():
    global nCarpetaP # Declara como variable global el nombre de la carpeta principal
    rtapp1=varInicial[1][0]
    fechaA=datetime.datetime.now() # Obtiene fecha y hora actual
    nCarpetaP=rtapp1 + '\\Resultado_' + getuser() + '_' + fechaA.strftime('%d_%m_%Y_%H_%M_%S') # Nombre de la carpeta
    try:
        os.mkdir(nCarpetaP) # Crea la carpeta
    except OSError as e:
        print (e.args) # Si ya existe, muestra el error
    return nCarpetaP

#================================================================================
# Mueve archivos descargados desde la carpeta Descargas a la carpeta de destino
# Además, actualiza el último valor de la lista valoresE02 con la cantidad de archivos movidos
def moverArchivo(rutaDest,valoresE02):
    a=len(valoresE02)
    rutaOrig=str(os.getcwd())
    rutaOrig=rutaOrig + '\\Descargas'
    archivosT01=os.listdir(rutaOrig)
    valoresE02[a-1]=valoresE02[a-1] + '|' + str(len(archivosT01))
    for arch in archivosT01:
        shutil.move(rutaOrig +'\\' + arch,rutaDest + '\\' + arch)
        
#================================================================================
# Elimina todos los archivos de la carpeta Descargas (limpieza de archivos fallidos)
def removerArchivo():
    rutaOrig=str(os.getcwd())
    rutaOrig=rutaOrig + '\\Descargas'
    archivosT01=os.listdir(rutaOrig)
    for arch in archivosT01:
        os.remove(rutaOrig +'\\' + arch)     
#==============================================================================
# Inserta una marca de agua con la fecha y hora actual en una imagen recibida en memoria
# Guarda la imagen resultante en la ruta de salida indicada
def inserMarcaAgua(input_image, output_image_path):
    fecha_hora_actual = datetime.datetime.now()
    watermark_text = "Captura realizada: " + str(fecha_hora_actual)
    original_image = Image.open(BytesIO(input_image))
    # Crear una copia de la imagen original
    image_with_watermark = original_image.copy()
    # Crear un objeto Draw para dibujar sobre la imagen
    draw = ImageDraw.Draw(image_with_watermark)
    # Especificar la fuente y el tamaño del texto
    font = ImageFont.truetype("arial.ttf", size=20)
    # Calcular el tamaño del texto
    bbox = draw.textbbox((0, 0), watermark_text, font=font)
    text_width, text_height = bbox[2] - bbox[0], bbox[3] - bbox[1]
    # Centrar el texto en la parte inferior de la imagen
    x = (original_image.width - text_width) // 2
    y = original_image.height - text_height - 10
    # Color del texto (azul oscuro)
    text_color = (0, 0, 139)
    # Dibujar el texto en la imagen
    draw.text((x, y), watermark_text, font=font, fill=text_color)
    # Fusionar la imagen original con la imagen que tiene la marca de agua
    watermarked_image = Image.blend(original_image, image_with_watermark, 0.5)
    # Guardar la imagen resultante
    watermarked_image.save(output_image_path)

#==============================================================================
# Función principal que recorre la base de contribuyentes y realiza las búsquedas en SIGEL
# Lee los datos desde un archivo Excel, ejecuta búsquedas por diferentes criterios y almacena los resultados
def generarAmb001():
    global estadoB01 # Variable de Estado
    rtapp1=varInicial[1][0] # Ruta de la carpeta Principal del aplicativo
    print(f'Ruta Principal del aplicativo {rtapp1}')

    print("----> Inicio de Lectura de Base Contribuyente <----")
    resultadoD=[] # Lista para almacenar resultados de búsqueda
    resultadoP=[] # Lista para almacenar procesos encontrados
    resultadoTP=[] # Lista para almacenar procesos detallados
    resultadoEstadoInf = []
    RutaBaseContribuyente = os.path.join(rtapp1, 'Base_Contribuyente.xlsx')
    excel_of=pd.ExcelFile(RutaBaseContribuyente) # Lee archivo excel
    hojaB=excel_of.parse('Base',dtype =str) # Lee la hoja que contiene datos de los contribuyentes a buscar
    excel_of.close()
    procesoR="" # Acumulador de procesos
    procesoRD="" # Acumulador de procesos detallados
    # Implementación 2024: para estado de información
    estadoInf=""
    colP=8
    carpeta=capetaG() # Crea carpeta de resultados
    indTB=1
    j= len(hojaB) # Cantidad de filas en el DataFrame hojaB
    cabBusqueda=list(hojaB) # Nombres de las columnas
    bandD=bool(0) # Bandera de control
    bandErr=bool(0) # Bandera de error
    try:
        for i in range(0,j): # Itera sobre cada contribuyente
            # driver.refresh()
            try:
                filaB=list(hojaB.iloc[i]) # Obtiene la fila actual como lista
                # Inicio de búsqueda para cada tipo de criterio
                indTB=1
                while indTB<4: # Realiza hasta 3 tipos de búsqueda por contribuyente
                    print("----> Busqueda de " + str(i+1) + "-" + str(indTB) + " de " + str(j) + " <----")
                    if bandErr:
                        print("reinicio de busqueda " + str(i+1) + "-" + str(indTB) + " de " + str(j) + " <----")
                        IniciarGoogleChrome() # Reinicia el navegador si hubo error
                        IniciarSesion() # Reinicia sesión
                    contaux1=1
                    # Verifica que el valor de búsqueda no sea vacío o inválido
                    if str(filaB[1+indTB])!='nan' and str(filaB[1+indTB])!='20000000000' and str(filaB[1+indTB])!='0':
                        while contaux1<4:
                            driver.switch_to.default_content() # Regresa al frame principal
                            print("Proceso busqueda P_1_1")
                            try:
                                # Selecciona el frame correcto según el tipo de cuenta
                                if tipo_cuenta==1: # Supervisor
                                    try:
                                        WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Step: Administrar Expediente SIGEL']")))
                                        WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Buscar Expedientes']")))
                                    except:
                                        try:
                                            WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//iframe[@title='A05 Consultar Expedientes SIGEL']")))
                                            WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//iframe[@title="Buscar Expedientes"]')))
                                        except:
                                            contaux1=contaux1+1 # Si falla, incrementa el contador para reintentar
                                            print("falla P_1_1 -->" + str(contaux1))
                                else: # Consulta
                                    try:
                                        WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//iframe[@title='A05 Consultar Expedientes SIGEL']")))
                                        WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, '//iframe[@title="Buscar Expedientes"]')))
                                    except:
                                        try:
                                            WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Step: Administrar Expediente SIGEL']")))
                                            WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Buscar Expedientes']")))
                                        except:
                                            contaux1=contaux1+1
                                            print("falla P_1_1 -->" + str(contaux1))
                                contaux1=6 # Sale del bucle si tiene éxito
                            except:
                                contaux1=contaux1+1 # Si falla, reintenta
                        print("Proceso busqueda P_1_1_2")  # Rellena los datos para la búsqueda
                        print(contaux1)
                        try:
                            # Según el tipo de búsqueda, ingresa el dato correspondiente
                            if indTB==3: # Búsqueda por nombre
                                nroDoc=str(hojaB.loc[i,"RUC_RRLL"])
                                indRUC=len(nroDoc)
                                if indRUC==11 and nroDoc[0]=='2':
                                    WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_4']"))).send_keys(str(hojaB.loc[i,"NOMBRE_RAZON_SOCIAL"]))
                                else:
                                    WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_3']"))).send_keys(str(hojaB.loc[i,"NOMBRE_RAZON_SOCIAL"]))
                                nombreArch=str(cabBusqueda[4]) + '_' + str(hojaB.loc[i,"NOMBRE_RAZON_SOCIAL"])
                            else:
                                WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_2']"))).send_keys(str(filaB[1+indTB]))
                                nombreArch=str(cabBusqueda[1+indTB]) + '_' + str(filaB[1+indTB])
                        except Exception as e:
                            print('Error en descarga Fila --- ' + str(i+1) + "-" + str(indTB) + " de " + str(j) + " <----")
                            print(e)
                            bandErr=bool(1)
                            CerrarGoogleChrome()
                            continue
                        print("Proceso busqueda P_1_2")
                        time.sleep(2) #Espera
                        nombreArch=str(hojaB.loc[i,"RUC"]) + '_' + nombreArch # Nombre del archivo
                        nombreArch = Limpiar_Caracteres(nombreArch)
                        #print(nombreArch)
                        
                        #Aquí
                        #print(f'Nombre Final del archivo {nombreArch}')
                        print("Proceso busqueda P_1_3")
                        #driver.save_screenshot(carpeta+'/'+nombreArch +'_inicio.png') 
                        screenshot_bytes = driver.get_screenshot_as_png()
                        
                        #Ruta_screenshot = os.path.join(carpeta, nombreArch, '_inicio.png')
                        inserMarcaAgua(screenshot_bytes, carpeta+'/'+nombreArch +'_inicio.png')
                        
                        WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='div_2_1_1_1_3_1_2']/button"))).click()  #click en boton Buscar
                        print("Proceso busqueda P_1_4") #Inidica inicio de espera de mensaje de confirmación se amplia de 11 a 30
                        try:#Verifica si existe mensaje  para confirmación
                            print("Proceso busqueda P_1_4_1-Espera mensaje de no se encontro")
                            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@class='modal-body']")))  #Verifica si existe mensaje de no se encontro resultado.
                            # Captura el texto del pop-up
                            mensaje_popup = driver.find_element(By.CLASS_NAME, 'modal-body').text
                            screenshot_bytes = driver.get_screenshot_as_png()
                            inserMarcaAgua(screenshot_bytes, carpeta+'/'+nombreArch +'_resultado.png')
                            
                            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@class='btn btn-danger']"))).click()  #click en boton ok
                            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_3']"))).clear()  #Borra valor ingresado
                            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_4']"))).clear()  #Borra valor ingresado
                            WebDriverWait(driver, 30).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='Text_div_2_1_1_1_1_1_2']"))).clear()  #Borra valor ingresado
                            if mensaje_popup.strip() == "No se encontraron resultados":
                                resultadoB = "No se encontró"
                            else:
                                resultadoB = mensaje_popup
                        except:
                            print("Proceso busqueda P_1_4_2-Proceso Encontrado")
                            #driver.save_screenshot(carpeta+'/'+nombreArch +'_resultado_1.png')
                            screenshot_bytes = driver.get_screenshot_as_png()
                            inserMarcaAgua(screenshot_bytes, carpeta+'/'+nombreArch +'_resultado_1.png')
                            
                            driver.switch_to.default_content() #Regresa al frame principal.
                            if tipo_cuenta==1: #ubica la tabla  que contiene el resultado
                                WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Step: Administrar Expediente SIGEL']")))  #Cambio de iframe
                                WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Buscar Expedientes']"))) #Cambio de iframe
                            else:
                                WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//iframe[@title='A05 Consultar Expedientes SIGEL']")))  #Cambio de iframe
                                WebDriverWait(driver, 30).until(EC.frame_to_be_available_and_switch_to_it((By.XPATH, "//*[@title='Buscar Expedientes']"))) #Cambio de iframe
                            print("Proceso busqueda P_1_4_3")
                            element=WebDriverWait(driver, 30).until(EC.presence_of_element_located((By.XPATH, "//*[@id='div_1_1_1']/div[2]/div[2]/div/table/thead/tr/th[20]")))#Elemento de sentencia
                            driver.execute_script("arguments[0].scrollIntoView();", element) #mover al elemento donde de sentencia
                            time.sleep(1)#cte.TIME_5) #Espera
                            #driver.save_screenshot(carpeta+'/'+nombreArch +'_resultado_2.png')
                            screenshot_bytes = driver.get_screenshot_as_png()
                            inserMarcaAgua(screenshot_bytes, carpeta+'/'+nombreArch +'_resultado_2.png')
                            
                            print("Proceso busqueda P_1_4_4") # obtención de datos de la tabla de resultado
                            # Obtiene la tabla de resultados y recorre cada fila para extraer la información relevante
                            table2=driver.find_element(By.XPATH,"//*[@id='div_1_1_1']/div[2]/div[2]/div/table/tbody") # Ubica el cuerpo de la tabla
                            rowsTable2=table2.find_elements(By.TAG_NAME,'tr') # Crea una lista de filas
                            for l in range(0,len(rowsTable2)):
                                colT= rowsTable2[l].find_elements(By.TAG_NAME,'td') # Crea la lista de columnas
                                colT1=colT[2].find_elements(By.TAG_NAME,'p') # Extrae el contenido de la columna 3
                                cotT2=colT[3].find_elements(By.TAG_NAME,'p') # Extrae el contenido de la columna 4
                                # Implementación 2024: estado de información
                                cotT7 = colT[7].find_elements(By.TAG_NAME,'p')
                                procesoR= procesoR + str(colT1[0].text) + '|' # Acumula el texto de la columna 3
                                procesoRD= procesoRD + str(cotT2[0].text) + '|' # Acumula el texto de la columna 4
                                estadoInf = estadoInf + str(cotT7[0].text) + '|' # Acumula el estado
                            print("Proceso busqueda P_1_4_5") # Retorno a menú de búsqueda
                            # Cierra el cuadro de resultados y regresa al menú principal
                            WebDriverWait(driver, 11).until(EC.element_to_be_clickable((By.XPATH, "//*[@id='div_2_1_2_1_3']/button"))).click()
                            driver.switch_to.default_content() # Vuelve el foco al frame principal
                            if tipo_cuenta==1:
                                time.sleep(1) # Espera
                                btnpag1 = driver.find_element(By.XPATH,'//*[@title="A05 Administrar Expediente SIGEL"]')
                                driver.execute_script("arguments[0].click()", btnpag1)
                                time.sleep(1) # Espera
                            else:
                                time.sleep(1) # Espera
                                btnpag1 = driver.find_element(By.XPATH,'//*[@title="A05 Consultar Expedientes SIGEL"]')
                                driver.execute_script("arguments[0].click()", btnpag1)
                                time.sleep(1) # Espera
                            resultadoB="Si se encontró"
                    else:
                        resultadoB="Valor Vacío"
                    # Almacena el resultado de la búsqueda y los procesos encontrados
                    print("Proceso busqueda P_1_5")
                    if indTB==1:
                        resultadoD.append([resultadoB])
                        if 'procesoR' in locals() or procesoR ==bool(1):
                            resultadoP.append(procesoR)
                            resultadoTP.append(procesoRD)
                            resultadoEstadoInf.append(estadoInf)
                            procesoR=''
                            procesoRD=''
                            estadoInf=''
                        else:
                            resultadoP.append('')
                            resultadoTP.append('')
                            resultadoEstadoInf.append('')
                    else:
                        resultadoD[i].append(resultadoB)
                        if 'procesoR' in locals()  or procesoR ==bool(1):
                            resultadoP[i]= resultadoP[i] + ";" + procesoR
                            resultadoTP[i]= resultadoTP[i] + ";" + procesoRD
                            resultadoEstadoInf[i] = resultadoEstadoInf[i] + ";" + estadoInf
                            procesoR=''
                            procesoRD=''
                            estadoInf=''
                        else:
                            resultadoP[i]= resultadoP[i] + ";" + ""
                            resultadoTP[i]= resultadoTP[i] + ";" + ""
                            resultadoEstadoInf[i] = resultadoEstadoInf[i]+ ";" + ""
                    bandErr=bool(0)
                    indTB=indTB+1                    
                # Al finalizar las búsquedas para un contribuyente, actualiza el Excel con los resultados
                z=len(resultadoD)
                print('Actualizar Excel' + '--' + str(z))
                excel_document = openpyxl.load_workbook(rtapp1 +'\\Base_Contribuyente.xlsx') # Accede al Excel de búsqueda
                sheet = excel_document['Base']
                try: 
                    for j in range(0,z):
                        sheet.cell(j+2,9).value=resultadoD[j][0]
                        sheet.cell(j+2,10).value=resultadoD[j][1]
                        sheet.cell(j+2,11).value=resultadoD[j][2]
                        sheet.cell(j+2,7).value=resultadoP[j]
                        sheet.cell(j+2,8).value=resultadoTP[j]
                        sheet.cell(j+2,6).value=resultadoEstadoInf[j]
                except Exception as e: 
                    print('Error en carga a excel Fila --- ' + str(j) )
                    print(e)
                RutaBaseContribuyenteResultado = os.path.join(rtapp1, "Base_Contribuyent_Resultado.xlsx")
                excel_document.save(RutaBaseContribuyenteResultado)
                excel_document.close() 
            except Exception as e: 
                print('Error en descarga Fila --- ' + str(i+1) )
                print(e)
    except Exception as e: 
        print('Error en descarga Fila --- ' + str(i+1) )
        print(e)
    # Al finalizar todo el proceso, actualiza el Excel con los resultados finales
    z=len(resultadoD)
    print('Actualizar Excel' + '--' + str(z))
    excel_document = openpyxl.load_workbook(rtapp1 +'\\Base_Contribuyente.xlsx') # Accede al Excel de búsqueda
    sheet = excel_document['Base']
    try: 
        for j in range(0,z):
            sheet.cell(j+2,9).value=resultadoD[j][0]
            sheet.cell(j+2,10).value=resultadoD[j][1]
            sheet.cell(j+2,11).value=resultadoD[j][2]
            sheet.cell(j+2,7).value=resultadoP[j]
            sheet.cell(j+2,8).value=resultadoTP[j]
            sheet.cell(j+2,6).value=resultadoEstadoInf[j]
    except Exception as e: 
        print('Error en carga a excel Fila --- ' + str(j) )
        print(e)
    RutaBaseContribuyenteResultado = os.path.join(rtapp1, "Base_Contribuyent_Resultado.xlsx")
    excel_document.save(RutaBaseContribuyenteResultado)
    excel_document.close() 
    print(resultadoD)
    # Muestra mensaje de finalización y cierra el navegador
    py.alert("Proceso Terminado ",timeout=45800)
    CerrarGoogleChrome()
        
              
#==============================================================================
#==============================================================================
# Función para obtener los parámetros de inicio desde un archivo externo
# Lee la ruta del aplicativo y otros parámetros desde 'VariablesInicio.txt'
def ParametrosInicio():
    global varInicial
    varInicial =[['Ruta del Aplicativo'],['']]
    varInicial[1][0]=os.getcwd() 
    path_varini=varInicial[1][0]+ '\\VariablesInicio.txt'  # Archivo con los parámetros de inicio
    i=1
    j=0
    if not os.path.exists(path_varini):
        print("no existe")
        # Si no existe el archivo, ajusta la ruta para buscar en el directorio superior
        while i>0:
            i=varInicial[1][0].find("\\",i)
            if i!=-1:
                j=i
            i=i+1
        varInicial[1][0]=varInicial[1][0][0:j]
        path_varini=varInicial[1][0]+ '\\VariablesInicio.txt'
    abspath_usuario=os.path.abspath(path_varini) # Ruta absoluta del archivo
    with open (abspath_usuario) as Usuario: # Lee el archivo de parámetros
        for line in Usuario:
            valoresAux= line[0:len(line)-1].split('|')
            varInicial[0].append(valoresAux[0]) # Nombre del parámetro
            varInicial[1].append(valoresAux[1]) # Valor del parámetro
#==============================================================================
# Pregunta al usuario si desea ejecutar el navegador en segundo plano (headless)
def navegar01():
    global inicio_diver
    OPT_V_SI= "SÍ" # Botones.
    OPT_V_NO= "NO" # Botones.
    opt1 = py.confirm(
        "**************************************************"+'\n'+   
        " ¿Desea iniciar el navegador en segundo plano?" +'\n'+      
        "**************************************************"+'\n',
        "====> Importante <====",
        [OPT_V_SI, OPT_V_NO])
    
    if opt1== OPT_V_NO:
        inicio_diver=1
    elif opt1== OPT_V_SI:
        inicio_diver=0
    else:
        inicio_diver=0
    return inicio_diver
#==============================================================================
# Pregunta al usuario si la cuenta es de tipo Supervisor o Consulta
def TipoCuenta():
    global tipo_cuenta
    OPT_V_SI= "SÍ" # Botones.
    OPT_V_NO= "NO" # Botones.
    opt1 = py.confirm(
        "**************************************************"+'\n'+   
        " ¿la Cuenta es de Supervisor?" +'\n'+      
        "**************************************************"+'\n',
        "====> Importante <====",
        [OPT_V_SI, OPT_V_NO])
    
    if opt1== OPT_V_NO:
        tipo_cuenta=0
    elif opt1== OPT_V_SI:
        tipo_cuenta=1
    else:
        tipo_cuenta=0
    return tipo_cuenta
#==============================================================================

#==============================================================================
# Función que inicia el proceso completo: selecciona tipo de cuenta, modo de navegador, inicia Chrome y sesión, y ejecuta la búsqueda principal
def LevantandoProcesoInicio():
    #time.sleep(5) #Espera
    global FechaHoraInicio # Variable global para registrar el inicio
    TipoCuenta() # Pregunta si la cuenta es de Supervisor
    navegar01() # Pregunta si el navegador será en segundo plano
    IniciarGoogleChrome() # Inicia el navegador Chrome
    IniciarSesion() # Realiza el login en SIGEL
    generarAmb001() # Ejecuta la función principal de búsqueda

#==============================================================================
# Menú de inicio del aplicativo, muestra opciones al usuario y lanza el proceso principal o cierra el programa
def MenuDeInicio():
    #########   Declarando Constantes ##################   
    OPT_CLOSE = "SÍ, CERRAR" # Botón para cerrar
    OPT_ASIGNAR_SIGEL = 'INICIAR BUSQUEDA' # Botón para iniciar búsqueda
    opt = py.confirm(
        "**************************************************************"+'\n'+   
        "                Bienvenido al Robot SIGEL" +'\n'+      
        "**************************************************************"+'\n'+                                                            
        "Pre - condiciones:" +'\n' + '\n'+
        "1.- El usuario y contraseña de SIGEL debe encontrarse en los archivos usuario.txt y clave.txt." +'\n'+'\n'+
        "2.- La plantilla de búsqueda de contribuyente  debe contener información referente a los representantes legales."+ '\n'+'\n'+
        "3.- Los campos deben estar en formato Texto.",
        "Ejecutando Aplicativo SIGEL",
        [OPT_CLOSE,
         OPT_ASIGNAR_SIGEL])

    if opt == OPT_CLOSE: # Si el usuario elige cerrar
        py.alert("Cerrando el aplicativo SIGEL")
    elif opt == OPT_ASIGNAR_SIGEL:    # Si elige iniciar búsqueda
        LevantandoProcesoInicio() # Inicia el proceso principal

#==============================================================================
# Limpia caracteres no válidos de los nombres de archivos para evitar errores en Windows
def Limpiar_Caracteres(NombreRazonSocial):
    nombre_limpio = re.sub(r'[\/:?"<>|]',' ',NombreRazonSocial)
    return nombre_limpio

#==============================================================================
# Función principal que llama a las diversas funciones para la ejecución de los procesos
def main():
    py.alert("Ejecutando ROBOT SIGEL ",timeout=800) # Mensaje de inicio
    ParametrosInicio() # Carga parámetros de inicio
    MenuDeInicio() # Muestra el menú principal

if __name__ == "__main__":
    main()
