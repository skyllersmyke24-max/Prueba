
import time
from selenium import webdriver
from selenium.webdriver.support.ui import Select
import os
from selenium.webdriver.common.by import By
from datetime import date 
import pandas as pd
import PySimpleGUI as sg
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


df = pd.DataFrame()
hoy=date.today() 
temp = [] 

ini=str(hoy.strftime('%d/%m/%Y'))

sg.theme('Black')
layout=[[sg.Text('INGRESAR FECHA INICIO  :',justification='center'),sg.InputText(default_text=ini,key='-fecinico-',size=(18, 1))],
        [sg.Text('INGRESAR FECHA FINAL  :',justification='center'),sg.InputText(default_text=ini,key='-fecfin-',size=(18, 1))],
        [sg.Button('INICIAR EJECUCIÓN',size=(40,1))]]
window=sg.Window('PY-SCRAPING INTRANET-NOTIFICACIONES', layout)
event, values = window.read()
window.close()



print("INICIANDO EL PROGRAMA")
path= os.getcwd()
chrome_options = Options()
chrome_options.headless = True
driver=webdriver.Chrome(options=chrome_options) 
driver.get("http://intranet/cl-at-iamenu/menuS01Alias")
usuario_intranet = open(path+"\\usuario.txt", "r")
usuario_intranet=usuario_intranet.read()
contrasena_intranet = open(path+"\\contraseña.txt", "r")
contrasena_intranet=contrasena_intranet.read()
driver.find_element("name", "cuenta").send_keys(usuario_intranet)
driver.find_element("name", "password").send_keys(contrasena_intranet)
driver.find_elements(By.XPATH, "/html/body/table/tbody/tr/td[1]/div[2]/form/table/tbody/tr/td/table[2]/tbody/tr/td/table/tbody/tr[3]/td/input")[0].click()
driver.maximize_window()
time.sleep(3)
driver.get('http://intranet/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=5:5.52.1&nm=1')
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='nivel2Cuerpo_10']")))
driver.find_elements(By.XPATH, "//*[@id='nivel2Cuerpo_10']")[0].click()
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='nivel3_5_52_1_2']")))
driver.find_elements(By.XPATH, "//*[@id='nivel3_5_52_1_2']")[0].click()
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='nivel4_5_52_1_21']")))
driver.find_elements(By.XPATH, "//*[@id='nivel4_5_52_1_21']")[0].click()
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CSS_SELECTOR,  "#iDivApplication > iframe")))
iframe=driver.find_element(By.CSS_SELECTOR, "#iDivApplication > iframe")
driver.switch_to.frame(iframe)
driver.switch_to.frame("det")
driver.find_element(By.XPATH, "//select[@id='dependencia']/option[@value='0021                ']").click()
driver.find_element(By.XPATH, "//select[@id='selTipoProceso']/option[@value='01']").click()
driver.find_element(By.XPATH, "//*[@id='fecPedidoDesde']").send_keys(values['-fecinico-'])
driver.find_element(By.XPATH, "//*[@id='fecPedidoHasta']").send_keys(values['-fecfin-'])

for j in range(70, 150):

   
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//select[@id='selTipoDocumento']")))
    selectEle  = Select(driver.find_element(By.XPATH, "//select[@id='selTipoDocumento']"))
    selectEle.select_by_index(j)
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='btnConsultar']")))
    driver.find_elements(By.XPATH, "//*[@id='btnConsultar']")[0].click()
    #driver.find_elements(By.XPATH, "//*[@id='btnExportarExcel']")[0].click()
    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//*[@id='tblSeguimientoPedido_paginate']/span")))
    Element = driver.find_element(By.XPATH,"//*[@id='tblSeguimientoPedido_paginate']/span").text
    Total_Pages=len(Element)
    for p in range (Total_Pages):
        table = driver.find_elements(By.XPATH, '//table[@id="tblSeguimientoPedido"]/tbody/tr')
        for row in table[:]:
           temp.append({'Nro Pedido':row.find_elements(By.TAG_NAME, "td")[0].text, 
                         'Dependencia':row.find_elements(By.TAG_NAME, "td")[1].text,
                         'Tipo Documento':row.find_elements(By.TAG_NAME, "td")[2].text,
                         'Area Solicitante':row.find_elements(By.TAG_NAME, "td")[3].text,
                         'Estado':row.find_elements(By.TAG_NAME, "td")[4].text,
                         'Cantidad de documentos solicitados':row.find_elements(By.TAG_NAME, "td")[5].text,
                         'Fecha pedido':row.find_elements(By.TAG_NAME, "td")[6].text
                         })
           print(temp)
        if len(Element)>1:
            driver.find_element(By.XPATH, "//*[@id='tblSeguimientoPedido_next']").click()      
            df = pd.DataFrame(temp)
        else:
            df = pd.DataFrame(temp)
df.to_excel(path+"\\scraping.xlsx")
driver.close()
print("FINALIZO EL PROGRAMA")
sg.theme('DarkGreen')
layout = [ [sg.Text('          El Robot ha concluido su proceso de manera satisfactoria.Gracias!!!      '  )],
          [sg.Button('OK',size=(58,2))]]
window = sg.Window('PY-SCRAPING INTRANET-NOTIFICACIONES', layout)
event, valor = window.read()
window.close()

   