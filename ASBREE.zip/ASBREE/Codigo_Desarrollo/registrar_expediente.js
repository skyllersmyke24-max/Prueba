//Guia Teclado https://stackoverflow.com/questions/46442253/pressing-enter-button-in-puppeteer

const puppeteer = require('puppeteer')
const selector = require('./selectorRegistrarExpediente.json')
const ExcelFileManager = require('./excelService')
const loadUserAccountFile = require('./leerCredenciales')
const getChromeExecutablePath = require('./rutaChrome')
const path = require('path')
const fs = require('fs')

async function RegistrarExpediente() {

    let browser
    const TIEMPO_REINICIO_NAVEGADOR = 15000

    try {

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            slowMo: 50,
            args: ['--start-maximized'],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await RegistrarExpediente();
            });
        }

        const URLIntranet = "https://intranet.sunat.peru/cl-at-iamenu/"
        const URLSIEV = "https://intranet.sunat.peru/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=3:3.3.7"

        const tiempoEspera = 5000
        const TIEMPO_ESPERA_DOCUMENTOS = 10000
        const SIEV_ASBRE = "SIEV_ASBRE"
        const paginaRegistro = "REGISTRO"
        const mensajeExpedienteAsginado = "Expediente Asignado"
        const columnaRecActual = 1
        const columnaNumeroRUC = 2
        const columnaRC = 3
        const columnaResultado = 4
        const tipoDocumentoRC = "007 - R. Coactiva"
        const nombreRepositorioPDF = "RepositorioPDF"
        const mensajeRCNoRepostorio = "La RC no se encuentra en el RepositorioPDF"
        const mensajeRCNoProcesadaSIEV = "Revisar la RC manualmente"
        const mensajeRCSubidaConExito = "La RC a sido registrada con éxito"

        const rutaArchivoUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')
        const rutaArchivoContrasena = path.resolve(process.cwd(), 'Credenciales', 'contraseña.txt')

        const textoUsuario = await loadUserAccountFile(rutaArchivoUsuario)
        const textoPassword = await loadUserAccountFile(rutaArchivoContrasena)

        const page = await browser.newPage()

        await page.goto(URLIntranet)

        const campoUsuario = await page.waitForSelector(selector.campo_usuario)

        await campoUsuario.type(textoUsuario)

        const campoContraseña = await page.waitForSelector(selector.campo_contraseña)

        await campoContraseña.type(textoPassword)

        const boton_iniciar_sesion = await page.waitForSelector(selector.boton_iniciar_sesion)

        await boton_iniciar_sesion.click()

        //Esperamos 5 segundos para consultar en el SIEV

        const excelAsignarExpediente = new ExcelFileManager()

        // await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), 'asignar_expediente')

        await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), SIEV_ASBRE)

        const indiceLimite = excelAsignarExpediente.obtenerNumeroDeFilas(paginaRegistro)

        console.log(indiceLimite)

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        await page.goto(URLSIEV)

        let frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

        const documentosInternos = await frameMenu.waitForSelector(selector.opcion_documentos_internos)

        await documentosInternos.click()

        let registroDocumentosInternos = await frameMenu.waitForSelector(selector.opcion_registro_de_documentos_internos)

        await registroDocumentosInternos.click()

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        // page.frames().map(frame => console.log('frame url ', frame.url()))

        let listaFrames = page.frames().map(frame => frame.url())

        let filtroframeDocumentosInternos = listaFrames.find(frame => frame.includes('docinternos') ? frame : false)

        let frameDet = await page.waitForFrame(async frame => { return frame.url() === filtroframeDocumentosInternos })


        const rutaRepositorioPdf = path.resolve(process.cwd(), nombreRepositorioPDF)

        for (let indiceActual = 2; indiceActual <= indiceLimite; indiceActual++) {

            // console.log('N° consulta ' + indiceActual + ' de ' + indiceLimite)
            console.log(`N° consulta ${indiceActual - 1} de ${indiceLimite - 1}`)

            const contenidoRecActual = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaRecActual)
            const contenidoNumeroRUC = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaNumeroRUC)
            const contenidoRC = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaRC)
            const contenidoResultado = await excelAsignarExpediente.ObtenerValorCelda(paginaRegistro, indiceActual, columnaResultado)

            const validarResultado = contenidoResultado ? contenidoResultado : false

            if (validarResultado) {
                console.log('Siguiente Consulta')
                console.clear()
                continue
            }

            const selectorTipoExpediente = await frameDet.waitForSelector(selector.select_tipo_expediente, { waitUntil: "networkidle0" })

            await selectorTipoExpediente.type('Origen')

            const campoNumeroExpediente = await frameDet.waitForSelector(selector.campo_numero_expediente, { waitUntil: "networkidle0" })

            await campoNumeroExpediente.type(contenidoRecActual.toString())

            const botonConsultar = await frameDet.waitForSelector(selector.boton_consultar, { waitUntil: "networkidle0" })

            await botonConsultar.click()

            let validarLaExistenciaDelExpediente

            try {

                validarLaExistenciaDelExpediente = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_ESPERA_DOCUMENTOS, visible: true }) ? false : null

            } catch (e) {

                validarLaExistenciaDelExpediente = true

            }

            if (!validarLaExistenciaDelExpediente) {

                const mensajeCasoExistenciaExpediente = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })


                // console.log('')-

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeCasoExistenciaExpediente)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)

                await botonLimpiarCampos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)


                continue

            }


            const opcionConsultarExpediente = await frameDet.waitForSelector(selector.opcion_expediente_virtual)

            await opcionConsultarExpediente.click()

            // await frameDet.waitForSelector(selector.opcion_anadir_documento)

            const botonAnadirDocumento = await frameDet.waitForSelector(selector.opcion_anadir_documento)

            // console.log(botonAnadirDocumento)

            await botonAnadirDocumento.click()

            // await frameDet.$eval(selector.opcion_anadir_documento, Element => Element.click())

            // page.frames().map(frame => console.log('frame url ', frame.url()))

            // const listaFrames = page.frames().map(frame => frame.url())

            // const filtroframeDocumentosInternos = listaFrames.find(frame => frame.includes('docinternos') ? frame : false)

            // const frameDocumentosInternos = await page.waitForFrame(async frame => { return frame.url() === filtroframeDocumentosInternos })

            const selectorGrupoDocumentos = await frameDet.waitForSelector(selector.select_tipo_documento)

            await selectorGrupoDocumentos.type(tipoDocumentoRC)

            const campoNumeroRC = await frameDet.waitForSelector(selector.campo_numero_RC)

            await campoNumeroRC.type(contenidoRC.toString())

            await page.keyboard.press('Tab')

            let validarLaExistenciaDeLaRC

            try {

                validarLaExistenciaDeLaRC = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: 20000, visible: true }) ? false : null

            } catch (e) {

                validarLaExistenciaDeLaRC = true

            }

            if (!validarLaExistenciaDeLaRC) {

                const mensajeExistenciaRC = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })

                console.log(mensajeExistenciaRC)

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeExistenciaRC)

                const botonCancelarArchivosAdjuntos = await frameDet.waitForSelector(selector.boton_cancelar_caso_doc_no_existe)
                await botonCancelarArchivosAdjuntos.click()

                // frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

                // registroDocumentosInternos = await frameMenu.waitForSelector(selector.opcion_registro_de_documentos_internos)

                // await registroDocumentosInternos.click()

                // await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

                // page.frames().map(frame => console.log('frame url ', frame.url()))

                // listaFrameDet = page.frames().map(frame => frame.url())

                // numeroElementosListaFrame = listaFrameDet.length

                // frameDet = await page.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)

                frameDet = await NuevaConsultaRegistro(page)

                continue

            }

            const nombreRCPdf = `${contenidoNumeroRUC.toString()}_${contenidoRC.toString()}.pdf`

            const rutaRCPdf = path.resolve(rutaRepositorioPdf, nombreRCPdf)

            const validacionDocumentoEnRepositorio = await new Promise((resolve) => {

                const validarExistenciaDocumento = fs.existsSync(rutaRCPdf)

                if (!validarExistenciaDocumento) {
                    resolve(validarExistenciaDocumento)
                }

                resolve(validarExistenciaDocumento)
            })

            console.log('validacion ' + validacionDocumentoEnRepositorio)

            if (!validacionDocumentoEnRepositorio) {

                console.log(`La RC ${nombreRCPdf} no está almacenada en el RepositorioPDF`)

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeRCNoRepostorio)

                // const botonCancelarArchivosAdjuntos = await frameDet.waitForSelector(selector.boton_cancelar_archivos_adjuntos)
                // await botonCancelarArchivosAdjuntos.click()

                // const botonSalirArchivosAdjuntos = await frameDet.waitForSelector(selector.boton_salir_archivos_ajuntos)
                // await botonSalirArchivosAdjuntos.click()

                // const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)
                // await botonLimpiarCampos.click()

                // frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

                // registroDocumentosInternos = await frameMenu.waitForSelector(selector.opcion_registro_de_documentos_internos)

                // await registroDocumentosInternos.click()

                // await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

                // page.frames().map(frame => console.log('frame url ', frame.url()))

                // listaFrameDet = page.frames().map(frame => frame.url())

                // numeroElementosListaFrame = listaFrameDet.length

                // frameDet = await page.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)

                frameDet = await NuevaConsultaRegistro(page)

                continue
            }

            const botonElegirArchivo = await frameDet.waitForSelector(selector.boton_elegir_archivo)

            // console.log(botonElegirArchivo)

            await botonElegirArchivo.uploadFile(rutaRCPdf)

            const botonAdjuntarArchivo = await frameDet.waitForSelector(selector.boton_adjuntar_archivo)

            await botonAdjuntarArchivo.click()

            // await frameDocumentosInternos.evaluate(() => document.querySelector("button[onclick='adjuntarArchivo()']").click())

            let validarDocumentoEsteEnElRepositorio

            try {

                validarDocumentoEsteEnElRepositorio = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_ESPERA_DOCUMENTOS, visible: true }) ? false : null

            } catch (e) {

                validarDocumentoEsteEnElRepositorio = true

            }

            if (!validarDocumentoEsteEnElRepositorio) {

                const mensajeDocumentoAdjunto = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })

                console.log(mensajeDocumentoAdjunto)

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeDocumentoAdjunto)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                // const botonCancelarArchivosAdjuntos = await frameDet.waitForSelector(selector.boton_cancelar_archivos_adjuntos)
                // await botonCancelarArchivosAdjuntos.click()

                // const botonSalirArchivosAdjuntos = await frameDet.waitForSelector(selector.boton_salir_archivos_ajuntos)
                // await botonSalirArchivosAdjuntos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)

                frameDet = await NuevaConsultaRegistro(page)

                // const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)
                // await botonLimpiarCampos.click()

                continue
            }

            const botonSubirDocumentos = await frameDet.waitForSelector(selector.boton_subir_documentos)
            await botonSubirDocumentos.click()

            try {

                const botonConfirmarSubirDocumentos = await frameDet.waitForSelector(selector.boton_confirmar_subir_documentos_adjutnos)
                await botonConfirmarSubirDocumentos.click()

            } catch (e) {

                excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeRCNoProcesadaSIEV)

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)


                frameDet = await NuevaConsultaRegistro(page)

                continue
            }

            excelAsignarExpediente.EscribirValorCelda(paginaRegistro, indiceActual, columnaResultado, mensajeRCSubidaConExito)

            // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

            await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)


            frameDet = await NuevaConsultaRegistro(page)


        }

        await browser.close()
        console.log('Consulta finalizada')

    } catch (error) {
        console.error('Error al iniciar el navegador o realizar consultas:', error);
        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(RegistrarExpediente, TIEMPO_REINICIO_NAVEGADOR);
    }
}

async function NuevaConsultaRegistro(pagina_principal) {

    const tiempoEspera = 5000

    const frameMenu = await pagina_principal.waitForFrame(async frame => { return frame.name() === "menu" })

    const registroDocumentosInternos = await frameMenu.waitForSelector(selector.opcion_registro_de_documentos_internos)

    await registroDocumentosInternos.click()

    await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

    // pagina_principal.frames().map(frame => console.log('frame url ', frame.url()))

    // const listaFrameDet = pagina_principal.frames().map(frame => frame.url())

    // const numeroElementosListaFrame = listaFrameDet.length

    // const frameDet = await pagina_principal.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

    const listaFrames = pagina_principal.frames().map(frame => frame.url())

    const filtroframeDocumentosInternos = listaFrames.find(frame => frame.includes('docinternos') ? frame : false)

    const frameDet = await pagina_principal.waitForFrame(async frame => { return frame.url() === filtroframeDocumentosInternos })

    return frameDet

}



RegistrarExpediente()
