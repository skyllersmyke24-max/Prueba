const puppeteer = require('puppeteer')
const selector = require('./selectorIntranet.json')
const ExcelFileManager = require('./excelService')
const loadUserAccountFile = require('./leerCredenciales')
const getChromeExecutablePath = require('./rutaChrome')
const path = require('path')
const { exec } = require('child_process');

async function AsignarExpediente() {

    let browser
    const TIEMPO_REINICIO_NAVEGADOR = 15000

    try {

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            slowMo: 50,
            args: ['--start-maximized'],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await AsignarExpediente();
            });
        }

        const URLIntranet = "https://intranet.sunat.peru/cl-at-iamenu/"
        const URLSIEV = "https://intranet.sunat.peru/cl-at-iamenu/menuS03Alias?accion=invocarPrograma&programa=3:3.3.7"

        const tiempoEspera = 5000
        const TIEMPO_AVISO = 8000
        const paginaAsignacion = "ASIGNACION"
        const mensajeExpedienteAsginado = "Expediente Asignado"
        const columnaExpediente = 1
        const columnaNumeroRegistro = 2
        const columnaConsulta = 3
        const mensajeMotivoUsuario = "REGISTRAR DOCUMENTOS"
        const SIEV_ASBRE = "SIEV_ASBRE"
        const mensajeMotivoPruebas = "PROCESO DE MEJORA APP ASBRE"

        const rutaArchivoUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')
        const rutaArchivoContrasena = path.resolve(process.cwd(), 'Credenciales', 'contraseña.txt')

        const textoUsuario = await loadUserAccountFile(rutaArchivoUsuario)
        const textoPassword = await loadUserAccountFile(rutaArchivoContrasena)

        const page = await browser.newPage()

        await page.goto(URLIntranet)

        const campoUsuario = await page.waitForSelector(selector.campo_usuario)

        await campoUsuario.type(textoUsuario)

        const campoContraseña = await page.waitForSelector(selector.campo_contraseña)

        await campoContraseña.type(textoPassword)

        const boton_iniciar_sesion = await page.waitForSelector(selector.boton_iniciar_sesion)

        await boton_iniciar_sesion.click()

        //Esperamos 5 segundos para consultar en el SIEV

        const excelAsignarExpediente = new ExcelFileManager()

        // await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), 'asignar_expediente') SIEV_ASBRE

        await excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), SIEV_ASBRE)

        const indiceLimite = excelAsignarExpediente.obtenerNumeroDeFilas(paginaAsignacion)

        console.log(indiceLimite)

        // excelAsignarExpediente.AbrirDocumentoExcel(process.cwd(), 'asignar_expediente')

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        await page.goto(URLSIEV)

        let frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

        const asignarResponsables = await frameMenu.waitForSelector(selector.asignacion_de_responsables)

        await asignarResponsables.click()

        let asignarResponsable = await frameMenu.waitForSelector(selector.asignar_responsable)

        await asignarResponsable.click()

        await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

        let listaFrameDet = page.frames().map(frame => frame.url())

        let numeroElementosListaFrame = listaFrameDet.length

        let frameDet = await page.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

        for (let indiceActual = 2; indiceActual <= indiceLimite; indiceActual++) {

            // console.log('N° consulta ' + indiceActual + ' de ' + indiceLimite)
            console.log(`Consulta ${indiceActual - 1} de ${indiceLimite - 1}`)

            const contenidoExpediente = await excelAsignarExpediente.ObtenerValorCelda(paginaAsignacion, indiceActual, columnaExpediente)
            const contenidoNumeroRegistro = await excelAsignarExpediente.ObtenerValorCelda(paginaAsignacion, indiceActual, columnaNumeroRegistro)
            const contenidoConsulta = await excelAsignarExpediente.ObtenerValorCelda(paginaAsignacion, indiceActual, columnaConsulta)

            const validarContenido = contenidoConsulta ? contenidoConsulta : false

            if (validarContenido) {
                console.log('-> Siguiente Consulta')
                console.clear()
                continue
            }

            const selectorTipoExpediente = await frameDet.waitForSelector(selector.select_tipo_expediente)

            await selectorTipoExpediente.type('Origen')

            const campoNumeroExpediente = await frameDet.waitForSelector(selector.campo_numero_expediente)

            await campoNumeroExpediente.type(contenidoExpediente.toString())

            // await frameDet.$eval(selector.boton_buscar_expediente, Element => Element.click())

            const botonBuscarExpediente = await frameDet.waitForSelector(selector.boton_buscar_expediente, { waitUntil: "networkidle0" })

            await botonBuscarExpediente.click()

            let mensajeAviso

            try {

                mensajeAviso = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_AVISO, visible: true }) ? false : false

            } catch (e) {

                mensajeAviso = true

            }

            if (!mensajeAviso) {

                const contenidoMensaje = await frameDet.evaluate(() => {
                    mensaje = document.querySelector('#dlgMsj')
                    return mensaje ? mensaje.innerText : null
                })

                console.log('--> ', contenidoMensaje)

                excelAsignarExpediente.EscribirValorCelda(paginaAsignacion, indiceActual, columnaConsulta, contenidoMensaje)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)

                await botonLimpiarCampos.click()

                const botonAceptarLimpiarCampos = await frameDet.waitForSelector(selector.boton_aceptar_limpiar_campos)

                await botonAceptarLimpiarCampos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)

                continue

            }

            const campoNumeroRegistro = await frameDet.waitForSelector(selector.campo_numero_registro)

            await campoNumeroRegistro.type(contenidoNumeroRegistro.toString())

            const botonBuscarRegistro = await frameDet.waitForSelector(selector.boton_buscar_registro)

            await botonBuscarRegistro.click()

            let validarTextoNumeroRegistro

            try {

                validarTextoNumeroRegistro = await frameDet.waitForSelector(selector.mensaje_aviso, { timeout: TIEMPO_AVISO, visible: true }) ? false : null

            } catch (e) {

                validarTextoNumeroRegistro = true

            }

            if (!validarTextoNumeroRegistro) {
                const mensajeRegistro = await frameDet.evaluate(() => {
                    mensaje = document.querySelector("#dlgMsj")
                    return mensaje ? mensaje.innerText : null
                })

                console.log('--> ', mensajeRegistro)

                excelAsignarExpediente.EscribirValorCelda(paginaAsignacion, indiceActual, columnaConsulta, mensajeRegistro)

                const botonAceptarAlertaMensaje = await frameDet.waitForSelector(selector.boton_aceptar_mensaje_aviso)

                await botonAceptarAlertaMensaje.click()

                const botonLimpiarCampos = await frameDet.waitForSelector(selector.boton_limpiar_campos)

                await botonLimpiarCampos.click()

                const botonAceptarLimpiarCampos = await frameDet.waitForSelector(selector.boton_aceptar_limpiar_campos)

                await botonAceptarLimpiarCampos.click()

                // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

                await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)

                continue
            }

            const marcarCasilla = await frameDet.waitForSelector(selector.marcar_casilla, { waitUntil: "networkidle0" })

            await marcarCasilla.click()

            const campoMotivo = await frameDet.waitForSelector(selector.campo_motivo, { waitUntil: "networkidle0" })

            // await campoMotivo.type("PROCESO DE MEJORA APP ASBRE")


            await campoMotivo.type(mensajeMotivoUsuario)

            const botonAgregar = await frameDet.waitForSelector(selector.boton_agregar, { waitUntil: "networkidle0" })

            await botonAgregar.click()

            // await frameDet.$eval(selector.boton_agregar, (elemento => elemento.click()))

            // await frameDet.$(selector.boton_guardar_cambios, Element=>Element.click())

            const botonGuardarCambios = await frameDet.waitForSelector(selector.boton_guardar_cambios, { waitUntil: 'networkidle0' })

            // await frameDet.$eval(selector.boton_guardar_cambios, (elemento => elemento.click()))

            await botonGuardarCambios.click()

            const botonAceptarAsignacion = await frameDet.waitForSelector(selector.boton_aceptar_asignacion)

            await botonAceptarAsignacion.click()

            // await page.frames().map((frame) => console.log('frame name ' + frame.name()))

            frameMenu = await page.waitForFrame(async frame => { return frame.name() === "menu" })

            asignarResponsable = await frameMenu.waitForSelector(selector.asignar_responsable)

            await asignarResponsable.click()

            await new Promise((resolve) => setTimeout(resolve, tiempoEspera))

            // await page.frames().map((frame) => console.log('frame url ' + frame.url()))

            listaFrameDet = page.frames().map(frame => frame.url())

            numeroElementosListaFrame = listaFrameDet.length

            frameDet = await page.waitForFrame(async frame => { return frame.url() === listaFrameDet[numeroElementosListaFrame - 1] })

            excelAsignarExpediente.EscribirValorCelda(paginaAsignacion, indiceActual, columnaConsulta, mensajeExpedienteAsginado)

            console.log('--> ', mensajeExpedienteAsginado)

            // await excelAsignarExpediente.GuardarExcel(process.cwd(), 'asignar_expediente')

            await excelAsignarExpediente.GuardarExcel(process.cwd(), SIEV_ASBRE)
        }

        await browser.close()
        console.log('**Consulta finalizada**')

    } catch (error) {
        console.error('Error al iniciar el navegador o realizar consultas:', error);
        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(AsignarExpediente, TIEMPO_REINICIO_NAVEGADOR);
    }

}

// const parametrosPython = process.argv.slice(2);

// console.log('Valores ',usuario_intranet)
// const usuario_intranet = parametrosPython[0]
// const contraseña_intranet = process.argv.slice[3];
// const visibilidad_navegador = process.argv.slice[4]
AsignarExpediente()
// AsignarExpediente(usuario_intranet[0], usuario_intranet[1], usuario_intranet[2])
