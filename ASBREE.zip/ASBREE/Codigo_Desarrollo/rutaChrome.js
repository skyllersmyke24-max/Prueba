const fsp = require('fs/promises')

async function getChromeExecutablePath() {
    const pathA = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
    const pathB = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe';

    try {
        const pathAExists = await fsp.access(pathA).then(() => true).catch(() => false);
        return pathAExists ? pathA : pathB;
    } catch (error) {
        console.error('Error al encontrar la ruta:', error);
        return null;
    }
}

module.exports = getChromeExecutablePath