const fs = require('fs/promises')
const pdf = require('pdf-parse');

async function ObtenerLiquidacionMemo(pdfPath) {

    try {

        const dataBuffer = await fs.readFile(pdfPath)
        const pdfData = await pdf(dataBuffer)
        const text = pdfData.text

        // console.log(text)

        if (text) {

            // Buscar tanto 'Cobranza' como variantes de 'LC' en el texto, en orden de aparición (barrido de arriba hacia abajo)
            // El patrón permite espacios alrededor de guiones y acepta última parte de 3 a 6 dígitos.
            // Si la última parte tiene solo 3 dígitos, se completa con '000' al inicio.
            const regexLiquidacion = /(?:Cobranza\b(?:[\s:\.\-]*N(?:°|º)?)?[\s:\.\-]*|LC\b(?:\s*[-:]|\s*N(?:°|º)?\s*[-:]|\s+))\s*(\d{3})\s*-\s*(\d{2,4})\s*-\s*(\d{3,6})/ig;

            const coincidencias = [...text.matchAll(regexLiquidacion)]

            if (!coincidencias.length) {
                return false
            }

            const [primerMatch] = coincidencias
            const codigoAduana = primerMatch[1].trim()
            let anio = primerMatch[2].trim().replace(/\s/g, '')
            const ultimoSegmento = primerMatch[3].trim().replace(/\s/g, '')

            // Normalizar el año: si tiene 2 dígitos, anteponer "20".
            if (anio.length === 2) {
                anio = `20${anio}`
            }

            // Normalizar el último segmento a 6 dígitos (rellenar con ceros al inicio si tiene menos de 6)
            const ultimoSegmentoNormalizado = ultimoSegmento.padStart(6, '0')

            const numeroLiquidacionValidada = `${codigoAduana}-${anio}-${ultimoSegmentoNormalizado}`

            return numeroLiquidacionValidada
        }

    } catch (error) {

        console.log('No se encontro coincidencia')

        return false

    }
}

module.exports = ObtenerLiquidacionMemo;


// const datafile = 'Memo.pdf'
// const datafile = 'nuevo_caso.pdf'
// const datafile = 'rec_extensa1.pdf'
// const datafile = 'test.pdf'
// const datafile = 'primerFiltro.pdf'
// const datafile = 'filtro.pdf'
// const datafile = "Analisis.pdf"


// async function basic(){

//     const Resultados = await ObtenerLiquidacionMemo(datafile);

//     // console.log(Resultados.length)

//     console.log(Resultados)

//     // await fs.unlink(datafile);
// }

// basic()

