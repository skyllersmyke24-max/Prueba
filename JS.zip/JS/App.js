const puppeteer = require('puppeteer')
const selectorIntranet = require('./loginIntranet.json')
const selectoreChaski = require('./eChaski.json')

const ExcelService = require('./excelService')
const ExtraerDatosPdf = require('./echaskiModelo')
const getChromeExecutablePath = require('./rutaChrome')
const CrearDirectorioDescargas = require('./directorioResultado')
const obtenerRutaDocumentoPdf = require('./validarDocumentoPdf')
const loadUserAccountFile = require('./leerCredenciales')
const obtenerlc = require('./validarlc')

const path = require('path')
const fs = require('fs/promises')

let carpetaRutaDescarga
const RUTA_BASE_PDF = 'D:\\Data\\MEMOS ADUANA\\2026\\ARCHIVOS PDF - MEMOS DEUDA ADUANERA'
const MESES_ANIO = ['ENERO','FEBRERO','MARZO','ABRIL','MAYO','JUNIO','JULIO','AGOSTO','SEPTIEMBRE','OCTUBRE','NOVIEMBRE','DICIEMBRE']

const limpiarNombreCarpeta = (valor) => {
    if (!valor) return 'DESCONOCIDO'
    return valor.toString().replace(/[<>:"/\\|?*\x00-\x1F]+/g, '').trim() || 'DESCONOCIDO'
}

const obtenerUltimosDosDigitosDocumento = (documento) => {
    if (!documento) return '00'
    const digitos = documento.toString().replace(/\D/g, '')
    return digitos.length >= 2 ? digitos.slice(-2) : '00'
}

const construirRutaPdfClasificada = (documento, numeroExpediente) => {
    const fecha = new Date()
    const mes = MESES_ANIO[fecha.getMonth()] || 'MES_DESCONOCIDO'
    const carpetaDocumento = limpiarNombreCarpeta(documento)
    const carpetaExpediente = limpiarNombreCarpeta(numeroExpediente || 'SIN_EXPEDIENTE')
    const prefijoDoc = obtenerUltimosDosDigitosDocumento(carpetaDocumento)
    return path.join(RUTA_BASE_PDF, mes, prefijoDoc, carpetaDocumento, carpetaExpediente)
}

const moverPdfAlaRutaClasificada = async (rutaOrigen, documento, numeroExpediente) => {
    const rutaDestinoCarpeta = construirRutaPdfClasificada(documento, numeroExpediente)
    await fs.mkdir(rutaDestinoCarpeta, { recursive: true })

    const nombreArchivo = path.basename(rutaOrigen)
    let rutaDestinoArchivo = path.join(rutaDestinoCarpeta, nombreArchivo)
    let contador = 1

    while (true) {
        try {
            await fs.access(rutaDestinoArchivo)
            const extension = path.extname(nombreArchivo)
            const base = path.basename(nombreArchivo, extension)
            rutaDestinoArchivo = path.join(rutaDestinoCarpeta, `${base}(${contador})${extension}`)
            contador++
        } catch (error) {
            break
        }
    }

    await fs.rename(rutaOrigen, rutaDestinoArchivo)
    return rutaDestinoArchivo
}

async function eChaskiIntranet() {

    let browser

    const botLog = (action, details = null) => {
        try {
            const time = new Date().toISOString()
            if (details) {
                if (typeof details === 'string') {
                    console.log(`[BOT] ${time} - ${action} - ${details}`)
                } else {
                    console.log(`[BOT] ${time} - ${action} - ${JSON.stringify(details)}`)
                }
            } else {
                console.log(`[BOT] ${time} - ${action}`)
            }
        } catch (e) {
            // No bloquear la ejecución por un fallo en logging
        }
    }

    try {

        botLog('Inicio eChaskiIntranet')


        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            slowMo: 50,
            args: ['--start-maximized'],
            executablePath: exectutableChromeNavegador
        })

        botLog('Browser launched', exectutableChromeNavegador)

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                botLog('Browser disconnected, reiniciando')
                await eChaskiIntranet();
            });
        }

        //Encabezados Temporales
        const EncabeazadosConsultaEChaski = [
            { header: 'NUMERO CONSULTA', key: 'numero_consulta', width: 4 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento', width: 17 },
            { header: 'NUMERO DOCUMENTO', key: 'numero_documento', width: 25 },
            { header: 'FECHA GENERACIÓN', key: 'fecha_generacion', width: 18 },
            { header: 'DERIVADO POR', key: 'derivador_por', width: 35 },
            { header: 'FECHA ULT. DERIVACIÓN', key: 'fecha_ult_derivacion', width: 21 },
            { header: 'ASUNTO', key: 'asunto', width: 56 },
            { header: 'ESTADO', key: 'estado', width: 9 },
            { header: 'REC ENCONTRADA', key: 'rec_encontrada', width: 16 },
            { header: 'RUTA', key: 'ruta', width: 80 }
        ]

        const EncabezadosConsultaREC = [
            { header: 'NUMERO CONSULTA', key: 'numero_consulta', width: 4 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento', width: 17 },
            { header: 'NUMERO DOCUMENTO', key: 'numero_documento', width: 25 },
            { header: 'FECHA GENERACIÓN', key: 'fecha_generacion', width: 18 },
            { header: 'DERIVADO POR', key: 'derivador_por', width: 35 },
            { header: 'FECHA ULT. DERIVACIÓN', key: 'fecha_ult_derivacion', width: 21 },
            { header: 'ASUNTO', key: 'asunto', width: 56 },
            { header: 'ESTADO', key: 'estado', width: 9 },
            { header: 'CODIGO ADUANA', key: 'codigo_aduana', width: 10 },
            { header: 'AÑO', key: 'anio', width: 4 },
            { header: 'NÚMERO LIQUIDACIÓN', key: 'numero_liquidacion', width: 20 },
            { header: 'NÚMERO LIQUIDACIÓN COMPLETO', key: 'numero_liquidacion_unico', width: 30 },
            { header: 'NÚMERO EXPEDIENTE', key: 'numero_expediente', width: 19 },
            { header: 'TIPO DOCUMENTO', key: 'tipo_documento_rec', width: 16 },
            { header: 'NÚMERO DOCUMENTO', key: 'numero_documento_rec', width: 20 },
            { header: 'RAZÓN SOCIAL', key: 'razon_social', width: 41 },
            { header: 'RUTA', key: 'ruta', width: 80 }
        ]
        console.log("******** CONSULTA Echaski - MEMORÁNDUM ********")
        botLog('Pantalla inicial mostrada')

        const page = await browser.newPage()

        botLog('Nueva pestaña creada')

        botLog('Navegando a Intranet', selectorIntranet.URLIntranet)
        await page.goto(selectorIntranet.URLIntranet)

        const rutaArchivoUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')
        const rutaArchivoContrasena = path.resolve(process.cwd(), 'Credenciales', 'contraseña.txt')
        const textoUsuario = await loadUserAccountFile(rutaArchivoUsuario)
        const textoPassword = await loadUserAccountFile(rutaArchivoContrasena)

        console.log("Digitando Usuario ...")
        botLog('Typing usuario')

        const campoUsuario = await page.waitForSelector(selectorIntranet.campoUsuario, { waitUntil: "networkidle0" })

        await campoUsuario.type(textoUsuario)

        console.log("Digitando Contraseña ...")
        botLog('Typing contraseña')

        const campoContraseña = await page.waitForSelector(selectorIntranet.campoClave, { waitUntil: "networkidle0" })

        await campoContraseña.type(textoPassword)

        console.log("Iniciando Sesión ...")
        botLog('Click login')

        const botonIniciarSesion = await page.waitForSelector(selectorIntranet.botonIniciarSesion, { waitUntil: "networkidle0" })

        await botonIniciarSesion.click()
        botLog('Botón iniciar sesión pulsado')

        await new Promise((resolve) => setTimeout(resolve, 3000))
        botLog('Delay post-login')

        const excelResultados = new ExcelService()

        let indiceConsulta

        const validarExcel = await excelResultados.AbrirDocumentoExcel(carpetaRutaDescarga, 'RESULTADO_CONSULTA_ECHASKI')

        if (validarExcel) {

            // console.log(`Valida excel: True`)

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_ECHASKI', EncabeazadosConsultaEChaski)

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_REC', EncabezadosConsultaREC)

            indiceConsulta = excelResultados.ObtenerUnaCeldaUltimaFila('CONSULTA_ECHASKI', 'A')


        } else {
            // console.log(`Valida excel: False`)

            excelResultados.AgregarHojaExcel('CONSULTA_ECHASKI')

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_ECHASKI', EncabeazadosConsultaEChaski)

            excelResultados.AgregarHojaExcel('CONSULTA_REC')

            excelResultados.AgregarEncabezadosHojaExcel('CONSULTA_REC', EncabezadosConsultaREC)

            indiceConsulta = 0

        }

        botLog('Navegando a eChaski', selectoreChaski.URLeChaski)
        await page.goto(selectoreChaski.URLeChaski)

        // Enable CDP
        const client = await page.target().createCDPSession();

        botLog('Configurando descarga', carpetaRutaDescarga)
        await client.send('Page.setDownloadBehavior', {
            behavior: 'allow',
            downloadPath: carpetaRutaDescarga
        });

        const opcionSelecionarMiBandeja = await page.waitForSelector(selectoreChaski.SeleccionarMiBandeja, { waitUntil: "networkidle0" })

        botLog('Seleccionando Mi Bandeja')
        await opcionSelecionarMiBandeja.click()

        const opcionSelecionarBandejaDocumentos = await page.waitForSelector(selectoreChaski.SeleccionarBandejaDocumentos, { waitUntil: "networkidle0" })

        botLog('Seleccionando Bandeja Documentos')
        await opcionSelecionarBandejaDocumentos.click()

        await new Promise((resolve) => setTimeout(resolve, 5000))

        //Vamos a capturar los frames presentes en la plataforma web

        let framesDet = await page.waitForFrame(async frame => { return frame.name() === selectoreChaski.FrameDet })
        botLog('Frame principal detectado', selectoreChaski.FrameDet)

        const opcionMostrarRegistros = await framesDet.waitForSelector('select[name="tblSolicitudGenerada_length"]')

        botLog('Ajustando cantidad de registros a mostrar a 100')
        await opcionMostrarRegistros.type('100')

        await framesDet.waitForSelector(selectoreChaski.ListadoDeDocumentosPendientes)

        const documentosAdjuntos = await framesDet.$$(selectoreChaski.ListadoDeDocumentosPendientes)
        botLog('Listado de documentos obtenidos', { count: documentosAdjuntos.length })

        //console.log(`Número total de consultas ${documentosAdjuntos}`)

        for (const [index, documentoAdjunto] of documentosAdjuntos.entries()) {

            console.log(`-> Numero de consulta ${index + 1} de ${documentosAdjuntos.length} `)

            if (index >= indiceConsulta) {

                botLog('Procesando documento', { index: index + 1, total: documentosAdjuntos.length })

                let resultadoConsulta = {}

                const documento = await documentoAdjunto.evaluate((elemento) => {
                    const tipoDocumento = elemento.querySelector("td:nth-child(2) > p")
                    const numeroDocumento = elemento.querySelector("td:nth-child(3) > a")
                    const fechaGeneracion = elemento.querySelector("td:nth-child(4)")
                    const derivadoPor = elemento.querySelector("td:nth-child(5) > p")
                    const fechaUltimaDerivacion = elemento.querySelector("td.centered.sorting_1")
                    const asunto = elemento.querySelector("td:nth-child(7) > p")
                    const estado = elemento.querySelector("td:nth-child(8)")

                    //const numeroDocumento = elemento.querySelector(selectoreChaski.NumeroDocumento)

                    return {
                        tipoDocumento: tipoDocumento ? tipoDocumento.innerText : null,
                        numeroDocumento: numeroDocumento ? numeroDocumento.innerText : null,
                        fechaGeneracion: fechaGeneracion ? fechaGeneracion.innerText : null,
                        derivadoPor: derivadoPor ? derivadoPor.innerText : null,
                        fechaUltimaDerivacion: fechaUltimaDerivacion ? fechaUltimaDerivacion.innerText : null,
                        asunto: asunto ? asunto.getAttribute('data-content') : null,
                        estado: estado ? estado.innerText : null
                    }
                })

                resultadoConsulta = {
                    numero_consulta: index + 1,
                    tipo_documento: documento.tipoDocumento,
                    numero_documento: documento.numeroDocumento,
                    fecha_generacion: documento.fechaGeneracion,
                    derivador_por: documento.derivadoPor,
                    fecha_ult_derivacion: documento.fechaUltimaDerivacion,
                    asunto: documento.asunto,
                    estado: documento.estado,
                }

                // Base de carpeta para esta consulta: usar siempre el número de documento
                // de la consulta cuando esté disponible para que todos los PDFs
                // de la misma consulta terminen en la misma carpeta.
                const documentoConsultaBase = limpiarNombreCarpeta(resultadoConsulta.numero_documento || null)

                // SE ACEPTA EL CASO FIRMADO
                const CASO_ESTADO_FIRMADO = "FIRMADO"
                const CASO_ESTADO_REVISION = "EN REVISIÓN"
                const CASO_ESTADO_SEGUIMIENTO = "EN SEGUIMIENTO"

                // const archivoAdjunto = await documentoAdjunto.waitForSelector(selectoreChaski.ArchivoAdjunto)

                // await archivoAdjunto.click()

                botLog('Abriendo sección de archivo adjunto', { documento: index + 1 })
                await documentoAdjunto.$eval(selectoreChaski.ArchivoAdjunto, elemento => elemento.click())
                botLog('Sección de archivo adjunto abierta', { documento: index + 1 })

                // Esperar a que el modal se cargue completamente
                await new Promise((resolve) => setTimeout(resolve, 2000))

                let documentosAdjuntoSeg
                let intentos = 0
                const maxIntentos = 3

                while (!documentosAdjuntoSeg && intentos < maxIntentos) {
                    try {
                        documentosAdjuntoSeg = await framesDet.waitForSelector("#tabs > li:nth-child(2) > a", { visible: true, timeout: 8000 })
                        botLog('Pestaña de documentos encontrada')
                    } catch (e) {
                        intentos++
                        botLog('Reintentando espera de pestaña de documentos', { intento: intentos, max: maxIntentos })
                        if (intentos < maxIntentos) {
                            await new Promise((resolve) => setTimeout(resolve, 2000))
                        } else {
                            throw e
                        }
                    }
                }

                botLog('Cambiando a pestaña de documentos adjuntos')
                await framesDet.evaluate((elemento) => elemento.click(), documentosAdjuntoSeg)
                botLog('Pestaña de documentos adjuntos seleccionada')

                // Esperar a que la pestaña se cargue
                await new Promise((resolve) => setTimeout(resolve, 1500))

                // Futura implementacion de reconocmiento

                // let validarNumeroRegistro

                // try{

                //     validarNumeroRegistro = await framesDet.waitForSelector(botonListaFilas, {visible:true, timeout:5000})

                //     const botonCantidadRegistros = await framesDet.waitForSelector(botonListaFilas)

                //     await botonCantidadRegistros.click()

                //     await framesDet.waitForSelector(RutasDeLasFilas)

                //     const elementosArreglo = await framesDet.$$(RutasDeLasFilas)

                //     console.log(elementosArreglo)



                // }catch(e){

                //     validarNumeroRegistro = false

                // }

                let numeroLc
                let rutaDocumentoPdfFirmado = null

                await framesDet.waitForSelector(selectoreChaski.ListaDocumentosAdjuntos)

                const tablaDocumentosAdjuntos = await framesDet.$$(selectoreChaski.ListaDocumentosAdjuntos)

                // console.log("Tabla de documentos adjuntos : ", tablaDocumentosAdjuntos)

                // console.log(tablaDocumentosAdjuntos.length)

                for (const filaDocumentoAdjunto of tablaDocumentosAdjuntos) {

                    const clipVerDocumento = await filaDocumentoAdjunto.$("a[aria-label='Ver']")

                    //console.log(index, '|', clipVerDocumento)


                    if (clipVerDocumento) {

                        botLog('Abriendo vista de documento (Ver)')
                        await filaDocumentoAdjunto.$eval("a[aria-label='Ver']", elemento => elemento.click())
                        botLog('Vista de documento abierta')

                        await new Promise((resolve) => setTimeout(resolve, 5000))

                        await framesDet.waitForSelector("#tblDocumentosSeguimPopup > tbody > tr")

                        const tablaDocumentosAdjuntos2 = await framesDet.$$("#tblDocumentosSeguimPopup > tbody > tr")
                        botLog('Filas en popup de seguimiento obtenidas', { count: tablaDocumentosAdjuntos2.length })

                        for (const filaDescargaDocumento of tablaDocumentosAdjuntos2) {

                            const textoREC = await filaDescargaDocumento.evaluate((elemento) => {
                                // const descripcion = elemento.querySelector('td:nth-child(1)')
                                const texto = elemento.querySelector('td:nth-child(1)')
                                const nombreDocumento = elemento.querySelector('td:nth-child(2)')
                                return {
                                    texto: texto ? texto.innerText : null,
                                    nombreDocumento: nombreDocumento ? nombreDocumento.innerText : null
                                }
                            })

                            console.log(textoREC.texto)

                            const nombreLower = textoREC.nombreDocumento ? textoREC.nombreDocumento.toLowerCase().trim() : ''
                            const textoLower = textoREC.texto ? textoREC.texto.toLowerCase().trim() : ''

                            // Determinar si es PDF
                            const esPdf = nombreLower.includes('.pdf') || textoLower.includes('.pdf')

                            // Excluir archivos NOT_REC explícitamente
                            const nombreEsNotRec = nombreLower.includes('not_rec') || nombreLower.includes('not-rec')

                            // Detectar indicios de REC o documento firmado: revisar tanto la descripción como el nombre de archivo (case-insensitive)
                            const nombreIndicaRec = nombreLower.includes('rec') || nombreLower.startsWith('rec_') || nombreLower.startsWith('rec-')
                            const textoIndicaRec = textoLower.includes('rec') || textoLower.includes('firmado') || textoLower.includes('resolución') || textoLower.includes('constancia')

                            if (esPdf && !nombreEsNotRec && (nombreIndicaRec || textoIndicaRec)) {

                                const botonDescargar = await filaDescargaDocumento.waitForSelector('td:nth-child(4) > a')
                                botLog('Iniciando descarga de documento', textoREC.nombreDocumento)
                                await botonDescargar.click()

                                // Monitor download progress
                                client.on('Page.downloadProgress', (event) => {
                                    if (event.state === 'completed') {
                                        console.log('Download completed');
                                        botLog('Download completed', textoREC.nombreDocumento)
                                    }
                                });

                                let rutaDocumentoPdf = await obtenerRutaDocumentoPdf(carpetaRutaDescarga);
                                botLog('Ruta de documento obtenido', rutaDocumentoPdf)

                                let rutaPdfClasificada = null
                                let consulta_rec = {}
                                let diccionarioMemo = {}
                                let consultaLc

                                if (textoREC.texto.toLowerCase().trim().includes('firmado')) {
                                    rutaDocumentoPdfFirmado = rutaDocumentoPdf

                                    botLog('Extrayendo LC desde PDF (firmado)')
                                    numeroLc = await obtenerlc(rutaDocumentoPdf)
                                    botLog('LC extraída', numeroLc)

                                    consultaLc = true

                                    botLog('Manteniendo PDF descargado (firmado)')

                                } else {

                                    consultaLc = false

                                    resultadoConsulta = {
                                        ...resultadoConsulta,
                                        "rec_encontrada": "No"
                                    }

                                    botLog('Documento no firmado, no se obtuvo LC')
                                }

                                console.log('El valor de la LC es', numeroLc)

                                const debeExtraerMemo = nombreLower.includes('rec')
                                    || textoLower.includes('rec')
                                    || textoLower.includes('resolución')
                                    || textoLower.includes('constancia')
                                    || nombreLower.startsWith('rec_')
                                    || nombreLower.startsWith('rec-')

                                if (debeExtraerMemo) {
                                    botLog('Extrayendo datos del Memo desde PDF', rutaDocumentoPdf)
                                    const informacionMemo = await ExtraerDatosPdf(rutaDocumentoPdf, numeroLc);
                                    botLog('Resultado extracción Memo', { found: !!informacionMemo })

                                    console.log(`resultado Memo: ${informacionMemo}`)

                                    if (informacionMemo) {

                                        console.log('--> REC encontrada')

                                        resultadoConsulta = {
                                            ...resultadoConsulta,
                                            "rec_encontrada": "Sí"
                                        }

                                        console.log('---> Analizando Documento')
                                        botLog('Analizando información del memo')

                                        if (resultadoConsulta["rec_encontrada"] == "Sí") {
                                            for (const datoMemo of informacionMemo) {

                                                diccionarioMemo["codigo_aduana"] = datoMemo["codigoAduana"]
                                                diccionarioMemo["anio"] = datoMemo["anio"]
                                                diccionarioMemo["numero_liquidacion"] = datoMemo["numeroLiquidacion"]
                                                diccionarioMemo["numero_liquidacion_unico"] = datoMemo["numeroLiquidacionUnico"]
                                                diccionarioMemo["numero_expediente"] = datoMemo["numeroExpediente"]
                                                diccionarioMemo["tipo_documento_rec"] = datoMemo["tipoDocumento"]
                                                diccionarioMemo["numero_documento_rec"] = datoMemo["numeroDocumento"]
                                                diccionarioMemo["razon_social"] = datoMemo["razonSocial"]

                                                const documentoParaRutaMemo = documentoConsultaBase || datoMemo["numeroDocumento"] || resultadoConsulta.numero_documento || path.basename(rutaDocumentoPdf, '.pdf')
                                                const rutaDocumentoDestinoRec = await moverPdfAlaRutaClasificada(rutaDocumentoPdf, documentoParaRutaMemo, datoMemo["numeroExpediente"])
                                                diccionarioMemo["ruta"] = rutaDocumentoDestinoRec

                                                if (rutaDocumentoPdfFirmado) {
                                                    const rutaDocumentoDestinoFirmado = await moverPdfAlaRutaClasificada(rutaDocumentoPdfFirmado, documentoParaRutaMemo, datoMemo["numeroExpediente"])
                                                    rutaDocumentoPdfFirmado = null
                                                    resultadoConsulta = {
                                                        ...resultadoConsulta,
                                                        ruta: rutaDocumentoDestinoFirmado
                                                    }
                                                }

                                                consulta_rec = {
                                                    ...resultadoConsulta,
                                                    ...diccionarioMemo
                                                }

                                                botLog('Agregando fila en hoja CONSULTA_REC', consulta_rec)
                                                excelResultados.AgregarFilaHojaExcel('CONSULTA_REC', consulta_rec)
                                            }

                                        }


                                    } else {

                                        console.log('--> REC no encontrada')

                                        resultadoConsulta = {
                                            ...resultadoConsulta,
                                            "rec_encontrada": "No"
                                        }
                                        botLog('REC no encontrada en PDF')
                                    }

                                }

                            }

                        }

                        // Si hay documento firmado pero no fue movido (REC no encontrada), moverlo al directorio clasificado
                        if (rutaDocumentoPdfFirmado && rutaDocumentoPdfFirmado.includes(carpetaRutaDescarga)) {
                            try {
                                const documentoParaRutaFirmado = documentoConsultaBase || resultadoConsulta.numero_documento || path.basename(rutaDocumentoPdfFirmado, '.pdf')
                                const rutaDocumentoDestinoFirmadoFallback = await moverPdfAlaRutaClasificada(rutaDocumentoPdfFirmado, documentoParaRutaFirmado, null)
                                // Actualizar rutaDocumentoPdf para que posteriores renames usen la ubicación correcta
                                rutaDocumentoPdf = rutaDocumentoDestinoFirmadoFallback
                                // Marcar que el firmado ya fue movido
                                rutaDocumentoPdfFirmado = null
                                resultadoConsulta = {
                                    ...resultadoConsulta,
                                    ruta: rutaDocumentoDestinoFirmadoFallback
                                }
                                botLog('PDF firmado movido a ruta clasificada', rutaDocumentoDestinoFirmadoFallback)
                            } catch (error) {
                                botLog('Error moviendo PDF firmado a ruta clasificada', error.message)
                            }
                        }

                        // Descargar documentos generados y moverlos a la misma carpeta de consulta.
                        try {
                            await framesDet.waitForSelector(selectoreChaski.TablaEnRevision, { timeout: 2000 })
                            const filasGenerados = await framesDet.$$(selectoreChaski.TablaEnRevision)
                            if (filasGenerados && filasGenerados.length > 0) {
                                for (const filaGen of filasGenerados) {
                                    try {
                                        const nombreGen = await filaGen.evaluate((el) => {
                                            const nodo = el.querySelector('td:nth-child(2)')
                                            return nodo ? nodo.innerText : el.innerText
                                        })
                                        const nombreLowerGen = nombreGen ? nombreGen.toLowerCase().trim() : ''
                                        const esPdfGen = nombreLowerGen.includes('.pdf')
                                        if (esPdfGen) {
                                            const botonDescargarGen = await filaGen.$('td:nth-child(4) > a') || await filaGen.$('a[download]') || await filaGen.$('a')
                                            if (botonDescargarGen) {
                                                botLog('Iniciando descarga (Generado)', nombreGen)
                                                await botonDescargarGen.click()
                                                const rutaPdfGen = await obtenerRutaDocumentoPdf(carpetaRutaDescarga)
                                                const nombreParaRutaGen = documentoConsultaBase || path.basename(rutaPdfGen, '.pdf')
                                                try {
                                                    const rutaDestinoGen = await moverPdfAlaRutaClasificada(rutaPdfGen, nombreParaRutaGen, null)
                                                    botLog('Documento generado movido', rutaDestinoGen)
                                                } catch (e) {
                                                    botLog('Error moviendo documento generado', e.message)
                                                }
                                            }
                                        }
                                    } catch (e) {
                                        // Ignorar errores individuales de fila generada
                                    }
                                }
                            }
                        } catch (e) {
                            // No hay tabla de generados o no accesible, continuar sin fallo
                        }

                        const botonCerrrarDocumentosAdjuntos = await framesDet.waitForSelector('::-p-xpath(//*[@id="divDocumentosSeguim"]/div[2]/div/div[1]/button)')

                        await botonCerrrarDocumentosAdjuntos.click()
                        
                        // Esperar a que el modal de documentos se cierre
                        await new Promise((resolve) => setTimeout(resolve, 1000))
                    }

                }

                botLog('Agregando fila en CONSULTA_ECHASKI', resultadoConsulta)
                excelResultados.AgregarFilaHojaExcel('CONSULTA_ECHASKI', resultadoConsulta)

                botLog('Guardando archivo Excel de resultados')
                await excelResultados.GuardarExcel(carpetaRutaDescarga, 'RESULTADO_CONSULTA_ECHASKI')

                botLog('Cerrando modal de adjuntos')
                const botonCerrarAdjuntos = await framesDet.waitForSelector("::-p-xpath(//*[@id='divAdjuntoResol']/div[2]/div/div[1]/button)", { timeout: 5000 })
                await botonCerrarAdjuntos.click()
                
                // Esperar a que el modal se cierre completamente antes de continuar con el siguiente documento
                await new Promise((resolve) => setTimeout(resolve, 2000))

                if (index + 1 == documentosAdjuntos.length) {
                    botLog('Último documento procesado, cerrando navegador')
                    await browser.close()
                    console.log("******** CONSULTA TERMINADA ********")
                }


            } else {
                console.log('Siguiente Consulta')
                console.clear()
            }

            if (index + 1 == documentosAdjuntos.length) {
                botLog('Último documento en lista, cerrando navegador')
                await browser.close()
                console.log("******** CONSULTA TERMINADA ********")
            }



        }
    } catch (error) {
        console.error('Error al iniciar el navegador o realizar consultas:', error);
        const errorMessage = error && error.message ? error.message : String(error)
        if (typeof botLog === 'function') {
            botLog('Error en eChaskiIntranet', errorMessage)
        } else {
            console.log(`[BOT] ERROR - ${errorMessage}`)
        }
        if (browser) {
            if (typeof botLog === 'function') {
                botLog('Cerrando navegador por error')
            }
            await browser.close();
        }
        if (typeof botLog === 'function') {
            botLog('Reintentando eChaskiIntranet en 15s')
        } else {
            console.log('[BOT] Reintentando eChaskiIntranet en 15s')
        }
        // Reintenta después de 15 segundos
        setTimeout(eChaskiIntranet, 15000)
    }


}


async function Main() {
    carpetaRutaDescarga = await CrearDirectorioDescargas()
    await eChaskiIntranet()
}

Main()
