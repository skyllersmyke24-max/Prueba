const fs = require('fs/promises');
const path = require('path');

async function obtenerRutaDocumentoPdf(carpetaRutaDescarga) {
    // const rutaDocumentoPdf = path.join(carpetaRutaDescarga, nombreDocumento);
    try {

        let estado = false
        let tiempoAcumulado = 0 //segundos de espera
        let tiempoEspera = 5000

        while (estado == false) {
            await new Promise(resolve => setTimeout(resolve, tiempoEspera));
            tiempoAcumulado += tiempoEspera

            // Leer el contenido de la carpeta
            const archivos = await fs.readdir(carpetaRutaDescarga);

            // Encontrar todos los archivos PDF
            const archivosPdf = archivos.filter(archivo => path.extname(archivo).toLowerCase() === '.pdf');

            if (archivosPdf.length) {
                // Seleccionar el PDF más reciente por fecha de modificación
                let archivoMasReciente = null;
                let fechaMasReciente = 0;

                for (const archivo of archivosPdf) {
                    const rutaArchivo = path.join(carpetaRutaDescarga, archivo);
                    const stats = await fs.stat(rutaArchivo);
                    const mtimeMs = stats.mtimeMs;

                    if (!archivoMasReciente || mtimeMs > fechaMasReciente) {
                        archivoMasReciente = archivo;
                        fechaMasReciente = mtimeMs;
                    }
                }

                const rutaDocumentoPdf = path.join(carpetaRutaDescarga, archivoMasReciente);
                estado = true
                return rutaDocumentoPdf
            }

            if (tiempoAcumulado >= 180000) { // 3 minutos
                throw new Error('Tiempo de espera acumulado excedido. Cerrando el navegador.');
            }
        }



    } catch (error) {
        console.error('---> Error al renombrar y mover el documento:', error);
    }


}

module.exports = obtenerRutaDocumentoPdf