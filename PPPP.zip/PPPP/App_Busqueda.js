const puppeteer = require('puppeteer')

const Exceljs = require('exceljs')

const fs = require('fs').promises

const readline = require('readline')

//Modulo para llama archivos del sistema
const os = require('os')

const path = require('path')
const { descargarPorArea, CrearDirectorioDescargas } = require('./App_Predial')

// ================================================================================
// FUNCIONES AUXILIARES PARA GESTIÓN DE RESULTADOS
// ================================================================================

function generarNombreCarpeta() {
    const usuario = os.userInfo().username;
    const equipo = os.hostname();
    const ahora = new Date();
    
    const dia = String(ahora.getDate()).padStart(2, '0');
    const mes = String(ahora.getMonth() + 1).padStart(2, '0');
    const año = ahora.getFullYear();
    const horas = String(ahora.getHours()).padStart(2, '0');
    const minutos = String(ahora.getMinutes()).padStart(2, '0');
    const segundos = String(ahora.getSeconds()).padStart(2, '0');
    
    return `${usuario}_${equipo}_${dia}D_${mes}M_${año}_${horas}H_${minutos}M_${segundos}S`;
}

async function crearCarpetaResultados() {
    const nombreCarpeta = generarNombreCarpeta();
    const rutaCarpeta = path.resolve(process.cwd(), '..', nombreCarpeta);
    
    try {
        await fs.mkdir(rutaCarpeta, { recursive: true });
        console.log(`Carpeta de resultados creada: ${rutaCarpeta}`);
        return rutaCarpeta;
    } catch (error) {
        console.error(`Error creando carpeta de resultados: ${error.message}`);
        throw error;
    }
}

function limpiarTexto(texto) {
    return String(texto || '')
        .replace(/_x000d_|_X000D_|_x000A_|_X000A_/gi, ' ')
        .replace(/\r|\n|\t/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

async function crearCarpetaCaps(rutaCarpetaResultados) {
    const rutaCaps = path.resolve(rutaCarpetaResultados, 'caps');
    try {
        await fs.mkdir(rutaCaps, { recursive: true });
        console.log(`Carpeta de capturas creada: ${rutaCaps}`);
        return rutaCaps;
    } catch (error) {
        console.error(`Error creando carpeta caps: ${error.message}`);
        throw error;
    }
}

async function guardarCapturaPdf(page, rutaCaps, valorRUC) {
    const nombreBase = String(valorRUC).replace(/[^a-zA-Z0-9_-]/g, '_') || 'resultado';
    const rutaPdf = path.join(rutaCaps, `${nombreBase}.pdf`);
    try {
        await page.evaluate(() => {
            const hideSelectors = [
                'header',
                'footer',
                '.ant-layout-sider',
                '.ant-layout-header',
                '.ant-layout-footer',
                '.sidenav',
                '.topbar',
                '.sunarp-logo',
                '.logo',
                '.toolbar',
                '.site-layout-background',
                '.ant-menu',
                '.ant-layout-content > .ant-row'
            ];
            window.__puppeteerHiddenElements = [];
            hideSelectors.forEach(selector => {
                document.querySelectorAll(selector).forEach(el => {
                    window.__puppeteerHiddenElements.push({ element: el, display: el.style.display });
                    el.style.display = 'none';
                });
            });
            document.documentElement.style.margin = '0';
            document.documentElement.style.padding = '0';
            document.body.style.margin = '0';
            document.body.style.padding = '0';
            window.scrollTo(0, 0);
        });

        await page.pdf({
            path: rutaPdf,
            format: 'A4',
            landscape: true,
            scale: 0.45,
            printBackground: true,
            margin: { top: 0, bottom: 0, left: 0, right: 0 }
        });

        await page.evaluate(() => {
            if (window.__puppeteerHiddenElements) {
                window.__puppeteerHiddenElements.forEach(item => {
                    if (item && item.element) {
                        item.element.style.display = item.display || '';
                    }
                });
                delete window.__puppeteerHiddenElements;
            }
        });

        console.log(`Captura PDF guardada: ${rutaPdf}`);
    } catch (error) {
        console.error(`Error al guardar PDF para ${valorRUC}: ${error.message}`);
    }
    return rutaPdf;
}

async function extraerNombreElemento(page, selector) {
    try {
        const texto = await page.$eval(selector, elem => elem.textContent || '');
        const numeros = texto.match(/\d+/);
        return numeros ? parseInt(numeros[0]) : 0;
    } catch (error) {
        console.log(`Elemento no encontrado: ${selector}`);
        return 0;
    }
}

async function extraerDatosTabla(page) {
    try {
        const filas = await page.$$eval('tr.ant-table-row', rows => {
            const limpiar = texto => String(texto || '').replace(/\r|\n|\t/g, ' ').replace(/\s+/g, ' ').trim();
            return rows.map(row => {
                const celdas = row.querySelectorAll('td.ant-table-cell');
                const datosArray = Array.from(celdas).map(celda => limpiar(celda.textContent));
                return datosArray;
            }).filter(fila => fila.some(c => c && c.length > 0));
        });
        return filas;
    } catch (error) {
        console.log(`Error extrayendo datos de tabla: ${error.message}`);
        return [];
    }
}

function obtenerLetraColumnaExcel(indice) {
    let letra = '';
    let numero = indice;
    while (numero >= 0) {
        letra = String.fromCharCode(65 + (numero % 26)) + letra;
        numero = Math.floor(numero / 26) - 1;
    }
    return letra;
}

async function crearExcelResultados(rutaCarpeta, datosBase, datosCoincidencias) {
    const workbook = new Exceljs.Workbook();
    
    // Hoja 1: Base
    const hojaBase = workbook.addWorksheet('Base');
    hojaBase.columns = [
        { key: 'ruc', width: 15 },
        { key: 'nombre', width: 30 },
        { key: 'nombreBusqueda', width: 30 },
        { key: 'tipoSocial', width: 20 },
        { key: 'partida', width: 15 },
        { key: 'zona', width: 15 },
        { key: 'estado', width: 15 }
    ];
    hojaBase.addRow(['RUC', 'NOMBRE', 'NOMBRE DE BUSQUEDA', 'TIPO SOCIAL', 'NRO. PARTIDA', 'ZONAR', 'ESTADO']);
    hojaBase.getRow(1).font = { bold: true, size: 12 };
    hojaBase.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD3D3D3' } };
    hojaBase.autoFilter = 'A1:G1';
    
    datosBase.forEach(fila => {
        hojaBase.addRow(fila);
    });
    
    // Hoja 2: Coincidencias
    const hojaCoincidencias = workbook.addWorksheet('Coincidencias');
    const datosCoincidenciasFiltrados = datosCoincidencias.filter(fila => fila.some(c => c && c.trim().length > 0));
    const maxColumnasCoincidencias = Math.max(14, datosCoincidenciasFiltrados.reduce((max, fila) => Math.max(max, fila.length), 0));
    const columnasCoincidencias = Array.from({ length: maxColumnasCoincidencias }, (_, index) => {
        const anchoPredeterminado = [15, 20, 15, 15, 10, 10, 25, 25, 30, 20, 15, 40, 15, 15][index] || 20;
        return { key: `col${index + 1}`, width: anchoPredeterminado };
    });
    hojaCoincidencias.columns = columnasCoincidencias;
    hojaCoincidencias.addRow(columnasCoincidencias.map((_, index) => `COLUMNA ${index + 1}`));
    hojaCoincidencias.getRow(1).font = { bold: true, size: 12 };
    hojaCoincidencias.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD3D3D3' } };
    hojaCoincidencias.autoFilter = `A1:${obtenerLetraColumnaExcel(maxColumnasCoincidencias - 1)}1`;
    
    datosCoincidenciasFiltrados.forEach(fila => {
        const fobj = {};
        fila.forEach((valor, index) => {
            fobj[`col${index + 1}`] = valor;
        });
        hojaCoincidencias.addRow(fobj);
    });
    
    const rutaArchivo = path.join(rutaCarpeta, 'Resultado_Contribuyente.xlsx');
    await workbook.xlsx.writeFile(rutaArchivo);
    console.log(`Excel generado: ${rutaArchivo}`);
    
    return rutaArchivo;
}

async function desactivarCheckboxInactivosPredial(page, esPersonaNatural) {
    try {
        console.log('Desactivando checkbox "inactivos" para Predial...');
        const checkboxes = await page.$$('input[type="checkbox"][name="inactivos"]');
        const index = esPersonaNatural ? 0 : 1;

        if (checkboxes.length > index) {
            const checkbox = checkboxes[index];
            const checked = await (await checkbox.getProperty('checked')).jsonValue();
            if (checked) {
                await checkbox.click();
            }
            console.log(`Checkbox inactivos ${esPersonaNatural ? 'persona natural' : 'persona juridica'} desactivado`);
        } else {
            console.log('No se encontró el checkbox inactivos esperado para predial');
        }
    } catch (error) {
        console.log('Error al desactivar checkbox inactivos en predial:', error.message);
    }
    await new Promise(resolve => setTimeout(resolve, 500));
}

async function configurarDescargasEnPagina(page, rutaDescargas) {
    await fs.mkdir(rutaDescargas, { recursive: true });
    const client = await page.target().createCDPSession();
    await client.send('Page.setDownloadBehavior', {
        behavior: 'allow',
        downloadPath: path.resolve(rutaDescargas)
    });
}

async function seleccionarMenuLateral(page, texto) {
    const selector = `::-p-xpath(//app-main//app-sidenav-menu2//span[contains(translate(normalize-space(.), 'ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚ', 'abcdefghijklmnopqrstuvwxyzáéíóú'), "${texto.toLowerCase()}")])`;
    await page.waitForSelector(selector, { waitUntil: 'networkidle0', timeout: 300000 });
    await page.$eval(selector, elem => elem.click());
}

async function descargarPredialDesdeBusqueda(page, zonaR, nroPartida) {
    await seleccionarMenuLateral(page, 'partida');

    const oficina = String(zonaR || '').trim().toLowerCase();
    const partida = String(nroPartida || '').trim().toLowerCase();

    if (!oficina || !partida) {
        return 'sin datos para descarga';
    }

    const OficinaRegistral = await page.waitForSelector(
        '::-p-xpath(//nz-form-item/nz-form-control/div/div/nz-select/nz-select-top-control/nz-select-search/input)',
        { waitUntil: 'networkidle0', timeout: 300000 }
    );
    await OficinaRegistral.type(oficina);
    await page.keyboard.press('Enter');

    if (/[a-zA-Z]/.test(partida)) {
        await SeleccionarSarp(page);
    }

    await page.$eval("input[type='radio']", elem => elem.click());
    const campoNumero = await page.waitForSelector('input[name="numero"]', { waitUntil: 'networkidle0', timeout: 300000 });
    await campoNumero.type(partida);
    await page.keyboard.press('Enter');
    await page.$eval('button[type="submit"]', elem => elem.click());

    try {
        await page.waitForSelector('::-p-xpath(//nz-modal-confirm-container/div/div/div/div/div[1]/span/span)', { visible: true, timeout: 10000 });
        return 'no encontrado';
    } catch (_) {
        // Sin modal de no encontrado: continuar.
    }

    try {
        const btnSolicitud = await page.waitForSelector('nz-content > div:nth-child(6) > button.ant-btn.ant-btn-primary', { timeout: 15000 });
        await btnSolicitud.click();
    } catch (_) {
        // Si no aparece, continuar con el flujo.
    }

    const btnVerAsientos = await page.waitForSelector("button[title='Ver Asientos']", { waitUntil: 'networkidle0', timeout: 300000 });
    await btnVerAsientos.click();

    const selectorTodasLasPaginas = /[a-zA-Z]/.test(partida)
        ? 'app-radio-buttom-custom nz-radio-group > label:nth-child(1)'
        : 'nz-radio-group > label:nth-child(1) > span.ant-radio > input';
    const btnTodasLasPaginas = await page.waitForSelector(selectorTodasLasPaginas, { waitUntil: 'networkidle0', timeout: 300000 });
    await btnTodasLasPaginas.click();

    const btnCalcularMonto = await page.waitForSelector(
        'app-consulta-partidas > nz-content > nz-spin > div > app-ver-asientos > div.montos > div:nth-child(3) > button',
        { waitUntil: 'networkidle0', timeout: 300000 }
    );
    await btnCalcularMonto.click();

    const btnContinuar = await page.waitForSelector(
        'app-ver-asientos > app-button-triple2 > div > div:nth-child(2) > app-button > div > div > button',
        { waitUntil: 'networkidle0', timeout: 300000 }
    );
    await btnContinuar.click();

    const btnDescargarBoleta = await page.waitForSelector("button[class='ant-btn ant-btn-primary']", { waitUntil: 'networkidle0', timeout: 300000 });
    await btnDescargarBoleta.click();

    await new Promise(resolve => setTimeout(resolve, 5000));
    return 'encontrado';
}

async function descargarPorAreaDesdeBusqueda(page, area, zonaR, nroPartida) {
    if (area === 'predial') {
        return descargarPredialDesdeBusqueda(page, zonaR, nroPartida);
    }
    if (area === 'juridica') {
        return 'pendiente juridica';
    }
    if (area === 'vehicular') {
        return 'pendiente vehicular';
    }
    return 'area no soportada';
}

async function SeleccionarSarp(page) {
    try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        const selectorDropdown = 'app-select-custom nz-select-top-control';
        let dropdownCertificado = await page.$(selectorDropdown);

        if (!dropdownCertificado) {
            return;
        }

        await dropdownCertificado.click();
        await new Promise(resolve => setTimeout(resolve, 1000));

        try {
            const opcionSarp = await page.waitForSelector('::-p-xpath(//nz-option-item[@title="FIR.DIGITAL-CERT. LITERAL - SARP"])', { timeout: 10000 });
            await opcionSarp.click();
            return;
        } catch (_) {
            const opcionSarpText = await page.waitForSelector('::-p-xpath(//nz-option-item[contains(., "SARP")])', { timeout: 10000 });
            await opcionSarpText.click();
        }
    } catch (_) {
        // Continuar sin bloquear flujo.
    }
}

// ================================================================================
// MENÚ INTERACTIVO PRINCIPAL - BOT_SUNARP
// ================================================================================

async function mostrarMenuPrincipal() {
    console.clear()
    console.log('╔════════════════════════════════════════════════════════════════╗')
    console.log('║                    BOT_SUNARP v1.0                             ║')
    console.log('║           Sistema Automatizado de Consultas SUNARP             ║')
    console.log('╚════════════════════════════════════════════════════════════════╝\n')

    console.log('────────────────────────────────────────────────────────────────')
    console.log('OPCIONES DISPONIBLES:')
    console.log('────────────────────────────────────────────────────────────────\n')
    console.log('  1) BUSQUEDA')
    
    console.log('  2) DESCARGA')
    
    console.log('  3) CARGAR DATA')
    
    console.log('  4) CERRAR')
    console.log('────────────────────────────────────────────────────────────────\n')

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    const opcion = await new Promise(resolve => {
        rl.question('Ingrese el número de la opción (1-4): ', answer => {
            rl.close()
            resolve(answer.trim())
        })
    })

    switch (opcion) {
        case '1':
            await manejarBusqueda()
            break
        case '2':
            await manejarDescarga()
            break
        case '3':
            await manejarCargarData()
            break
        case '4':
            await manejarCerrar()
            break
        default:
            console.log('\n Opción no válida. Por favor ingrese un número entre 1 y 4.\n')
            await new Promise(resolve => setTimeout(resolve, 2000))
            await mostrarMenuPrincipal()
    }
}

async function manejarBusqueda() {
    console.clear()
    console.log('╔════════════════════════════════════════════════════════════════╗')
    console.log('║                    MÓDULO DE BÚSQUEDA                          ║')
    console.log('╚════════════════════════════════════════════════════════════════╝\n')

    console.log('────────────────────────────────────────────────────────────────')
    console.log('SELECCIONE ÁREA REGISTRAL:')
    console.log('────────────────────────────────────────────────────────────────\n')
    
    console.log('  1) Propiedad Inmueble Predial')
    
    console.log('  2) Personas Jurídicas')
    
    console.log('  3) Propiedad Vehicular')
    
    console.log('  0) Volver al menú principal\n')
    console.log('────────────────────────────────────────────────────────────────\n')

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    const opcion = await new Promise(resolve => {
        rl.question('Ingrese el número de la opción (0-3): ', answer => {
            rl.close()
            resolve(answer.trim())
        })
    })

    let area
    switch (opcion) {
        case '1':
            area = 'predial'
            break
        case '2':
            area = 'juridica'
            break
        case '3':
            area = 'vehicular'
            break
        case '0':
            await mostrarMenuPrincipal()
            return
        default:
            console.log('\n Opción no válida.\n')
            await new Promise(resolve => setTimeout(resolve, 2000))
            await manejarBusqueda()
            return
    }

    console.log('\n Iniciando búsqueda...\n')

    try {
        await BusquedaGeneral(area)

        console.log('\n────────────────────────────────────────────────────────────────')
        console.log('BÚSQUEDA COMPLETADA')
        console.log('────────────────────────────────────────────────────────────────\n')

        const rl2 = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })

        const accion = await new Promise(resolve => {
            console.log('1) Nueva búsqueda')
            console.log('2) Volver al menú principal\n')
            rl2.question('Ingrese su opción (1-2): ', answer => {
                rl2.close()
                resolve(answer.trim())
            })
        })

        if (accion === '1') {
            await manejarBusqueda()
        } else {
            await mostrarMenuPrincipal()
        }

    } catch (error) {
        console.error('\n Error durante la búsqueda:', error.message)
        
        const rl3 = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        })

        const reintentar = await new Promise(resolve => {
            rl3.question('\n¿Desea reintentar? (s/n): ', answer => {
                rl3.close()
                resolve(answer.trim().toLowerCase())
            })
        })

        if (reintentar === 's') {
            await manejarBusqueda()
        } else {
            await mostrarMenuPrincipal()
        }
    }
}

async function manejarDescarga() {
    console.clear()
    console.log('╔════════════════════════════════════════════════════════════════╗')
    console.log('║                   MÓDULO DE DESCARGA                           ║')
    console.log('╚════════════════════════════════════════════════════════════════╝\n')

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    console.log('Seleccione área registral para descarga:')
    console.log('  1) Propiedad Inmueble Predial')
    console.log('  2) Personas Jurídicas (pendiente)')
    console.log('  3) Propiedad Vehicular (pendiente)')
    console.log('  0) Volver al menú principal\n')

    const opcion = await new Promise(resolve => {
        rl.question('Ingrese el número de la opción (0-3): ', answer => {
            rl.close()
            resolve(answer.trim())
        })
    })

    if (opcion === '0') {
        await mostrarMenuPrincipal()
        return
    }

    if (opcion === '2' || opcion === '3') {
        console.log('\nÁrea aún pendiente de implementación.\n')
        await new Promise(resolve => setTimeout(resolve, 1500))
        await mostrarMenuPrincipal()
        return
    }

    if (opcion !== '1') {
        console.log('\nOpción no válida.\n')
        await new Promise(resolve => setTimeout(resolve, 1500))
        await mostrarMenuPrincipal()
        return
    }

    try {
        await CrearDirectorioDescargas()
        await descargarPorArea('predial')
    } catch (error) {
        console.error('\nError durante la descarga:', error.message)
    }

    await mostrarMenuPrincipal()
}

async function manejarCargarData() {
    console.clear()
    console.log('╔════════════════════════════════════════════════════════════════╗')
    console.log('║                  MÓDULO CARGAR DATA                            ║')
    console.log('╚════════════════════════════════════════════════════════════════╝\n')

    console.log('  MÓDULO EN DESARROLLO')
    console.log('═══════════════════════════════════════════════════════════════════\n')
    console.log('Este módulo permite cargar datos masivos desde diferentes fuentes:\n')
    console.log('Funcionalidades planeadas:')
    console.log('  • Importar desde CSV')
    console.log('  • Importar desde Excel')
    console.log('  • Validar formato de datos')
    console.log('  • Detectar duplicados')
    console.log('  • Cargar en Base_Contribuyente.xlsx\n')
    console.log('Estado:  No implementado aún\n')
    console.log('═══════════════════════════════════════════════════════════════════\n')

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    await new Promise(resolve => {
        rl.question('Presione Enter para volver al menú principal...', () => {
            rl.close()
            resolve()
        })
    })

    await mostrarMenuPrincipal()
}

async function manejarCerrar() {
    console.clear()
    console.log('╔════════════════════════════════════════════════════════════════╗')
    console.log('║                  CERRANDO BOT_SUNARP                           ║')
    console.log('╚════════════════════════════════════════════════════════════════╝\n')

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    const confirmar = await new Promise(resolve => {
        rl.question('¿Desea salir del bot? (s/n): ', answer => {
            rl.close()
            resolve(answer.trim().toLowerCase())
        })
    })

    if (confirmar === 's') {
        console.log('\n Gracias por usar BOT_SUNARP. ¡Hasta luego!\n')
        process.exit(0)
    } else {
        await mostrarMenuPrincipal()
    }
}

async function seleccionarAreaRegistral() {
    const opciones = [
        { key: '1', label: 'Propiedad Inmueble Predial', value: 'predial' },
        { key: '2', label: 'Personas Jurídicas', value: 'juridica' },
        { key: '3', label: 'Propiedad Vehicular', value: 'vehicular' }
    ]

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    })

    console.log('Seleccione el área registral:')
    opciones.forEach(opt => console.log(` ${opt.key}) ${opt.label}`))

    const seleccion = await new Promise(resolve => {
        rl.question('Ingrese el número de la opción: ', answer => {
            rl.close()
            resolve(answer.trim())
        })
    })

    const opcion = opciones.find(opt => opt.key === seleccion)
    if (!opcion) {
        console.log('Opción inválida. Se seleccionará Personas Jurídicas por defecto.')
        return 'juridica'
    }

    return opcion.value
}

async function BusquedaGeneral(areaRegistralPredefinida = null) {

    let browser
    let rutaCarpetaResultados
    let areaRegistralSeleccionada
    const datosBase = [];
    const datosCoincidencias = [];
    
    try {

        // Si viene del menú, usar el área predefinida; si no, solicitar
        areaRegistralSeleccionada = areaRegistralPredefinida || await seleccionarAreaRegistral()
        const areaOptions = {
            predial: { title: 'Propiedad Inmueble Predial', label: 'Propiedad Inmueble Predial' },
            juridica: { title: 'Personas Juridicas', label: 'Personas Jurídicas' },
            vehicular: { title: 'Propiedad Vehicular', label: 'Propiedad Vehicular' }
        }
        const areaConfig = areaOptions[areaRegistralSeleccionada]

        console.log(`Área registral seleccionada: ${areaConfig.label}`)

        // Crear carpeta de resultados
        rutaCarpetaResultados = await crearCarpetaResultados()
        const rutaCaps = await crearCarpetaCaps(rutaCarpetaResultados)
        const rutaDescargas = path.resolve(rutaCarpetaResultados, 'descargas')

        const exectutableChromeNavegador = await getChromeExecutablePath()

        browser = await puppeteer.launch({
            headless: false, //Permite que el navegador sea visible
            slowMo: 100, //Simulacro la escritura
            defaultViewport: false,
            args: [
                '--start-maximized', //Permite utilizar el navegador en pantalla completa
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-infobars',
                '--disable-blink-features=AutomationControlled'
            ],
            executablePath: exectutableChromeNavegador
        })

        //Permite ejecutar el navegador nuevamente a partir de un cierre inesperado
        if (!browser || !browser.isConnected()) {
            browser = await puppeteer.launch();
            browser.on('disconnected', async () => {
                console.log('El navegador se ha cerrado. Reiniciando...');
                await BusquedaGeneral();
            });
        }

        const page = await browser.newPage()
        await configurarDescargasEnPagina(page, rutaDescargas)

        const RutaUsuario = path.resolve(process.cwd(), 'Credenciales', 'usuario.txt')

        const RutaContraseña = path.resolve(process.cwd(), 'Credenciales', 'contrasena.txt')

        const contenidoUsuario = await loadUserAccountFile(RutaUsuario)

        const contenidioContraseña = await loadUserAccountFile(RutaContraseña)

        const RutaArchivoExcel = path.resolve(process.cwd(), 'Data', 'Base_Contribuyente.xlsx')

        console.log('************ APP - SUNARP BÚSQUEDA GENERAL ************')

        // ================================================================================
        // FASE 0: LEER EXCEL Y PREPARAR ITERACIÓN
        // ================================================================================

        const NumeroTotalFilas = await FilasTotalesExcel(RutaArchivoExcel)

        // ================================================================================
        // FASE 1: AUTENTICACIÓN
        // ================================================================================

        await page.goto('https://sprl.sunarp.gob.pe/sprl/ingreso', { waitUntil: "networkidle0", timeout: 300000 })

        console.log('Navegando a SUNARP...')

        // Cerrar modal de bienvenida si existe
        try {
            const sidSunarp = await page.waitForSelector('button[aria-label="Close"]', { waitUntil: "networkidle0", timeout: 20000 })
            if (sidSunarp) {
                await page.keyboard.press('Escape')
            }
        } catch (error) {
            console.log('Modal no encontrado o ya cerrado')
            await page.keyboard.press('Escape')
        }

        // Click en botón "Ingresar"
        const btnIngresar = await page.waitForSelector('nz-form-control > div > div > div > button', { waitUntil: "networkidle0", timeout: 300000 })

        await btnIngresar.click()

        console.log(`Digitando Usuario...`)

        const usuario = await page.waitForSelector('input[name="username"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await usuario.type(contenidoUsuario)

        console.log(`Digitando Contraseña...`)

        const contraseña = await page.waitForSelector('input[name="password"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await contraseña.type(contenidioContraseña)

        console.log(`Iniciando Sesión...`)

        const btnInciarSesion = await page.waitForSelector('button[class="btn"]', { waitUntil: 'networkidle0', timeout: 300000 })

        await btnInciarSesion.click()

        // ================================================================================
        // FASE 2: SELECCIONAR BÚSQUEDA POR ÍNDICE
        // ================================================================================

        console.log('Seleccionando Búsqueda por Índice...')

        await page.waitForSelector('::-p-xpath(//app-main/nz-layout/nz-layout/nz-sider/div/app-sidenav-menu2/ul/li[1]/div[2]/ul/li/span[contains(text(),"Búsqueda")])', { waitUntil: 'networkidle0', timeout: 300000 })

        await page.$eval('::-p-xpath(//app-main/nz-layout/nz-layout/nz-sider/div/app-sidenav-menu2/ul/li[1]/div[2]/ul/li/span[contains(text(),"Búsqueda")])', elem => elem.click())

        // ================================================================================
        // FASE 3: SELECCIONAR TODAS LAS ZONAS REGISTRALES
        // ================================================================================

        console.log('Seleccionando todas las zonas registrales...')

        await page.waitForSelector('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > nz-transfer-list:nth-child(1) > div.ant-transfer-list-header > label', { waitUntil: 'networkidle0', timeout: 300000 })

        await page.$eval('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > nz-transfer-list:nth-child(1) > div.ant-transfer-list-header > label', elem => elem.click())

        console.log('Confirmar selección de zonas...')

        await page.$eval('body > app-root > app-main > nz-layout > nz-layout > nz-content > app-busqueda-por-nombre-titular > div > div.card-list-body > div > div > nz-spin > div > div.ng-star-inserted > span > span > nz-card.ant-card.ant-card-bordered.ng-star-inserted > div > div > nz-transfer > div > button:nth-child(2)', elem => elem.click())

        console.log('Esperando a que se carguen los formularios...')
        
        await new Promise(resolve => setTimeout(resolve, 3000))

        // ================================================================================
        // FASE 4 y 5: ITERAR POR CADA FILA DEL EXCEL
        // ================================================================================

        for (let indice = 2; indice <= NumeroTotalFilas; indice++) {

            console.log(`----> Número de Búsqueda ${indice - 1} de ${NumeroTotalFilas - 1} <----`)

            // Leer datos del Excel
            let valorRUC = await CapturarValorExcel(RutaArchivoExcel, indice, 'A')
            let valorNombre = await CapturarValorExcel(RutaArchivoExcel, indice, 'B')
            let valorNombreBusqueda = await CapturarValorExcel(RutaArchivoExcel, indice, 'C')
            let valorTipoSocial = await CapturarValorExcel(RutaArchivoExcel, indice, 'D')

            valorRUC = limpiarTexto(valorRUC).toUpperCase()
            valorNombre = limpiarTexto(valorNombre).toUpperCase()
            valorNombreBusqueda = limpiarTexto(valorNombreBusqueda).toUpperCase()
            valorTipoSocial = limpiarTexto(valorTipoSocial).toUpperCase()

            console.log(`RUC: ${valorRUC}, Nombre Búsqueda: ${valorNombreBusqueda}, Tipo: ${valorTipoSocial}`)

            // ================================================================================
            // SELECCIONAR ÁREA REGISTRAL SEGÚN LA OPCIÓN ELEGIDA AL INICIO
            // ================================================================================

            const selectorFinal = `::-p-xpath(//nz-option-item[@title="${areaConfig.title}"])`
            const areaRegistralNombre = areaConfig.label

            if (areaRegistralSeleccionada !== 'predial') {
                console.log(`Seleccionando área registral: ${areaRegistralNombre}...`)

                // Esperar el dropdown y seleccionar
                await page.waitForSelector('app-busqueda-por-nombre-titular nz-select nz-select-top-control', { waitUntil: 'networkidle0', timeout: 300000 })
                await page.$eval('app-busqueda-por-nombre-titular nz-select nz-select-top-control', elem => elem.click())

                await new Promise(resolve => setTimeout(resolve, 1000))

                // Seleccionar la opción
                await page.waitForSelector(selectorFinal, { waitUntil: 'networkidle0', timeout: 300000 })
                await page.$eval(selectorFinal, elem => elem.click())

                console.log('Área registral seleccionada')
                await new Promise(resolve => setTimeout(resolve, 1500))
            } else {
                console.log('Área registral Predial ya está seleccionada por defecto. Se conserva la selección actual.');
                // Nota: esta selección no es necesaria actualmente para Predial,
                // pero se mantiene como referencia/comentario para uso futuro.
            }

            // ================================================================================
            // DETECTAR TIPO DE BÚSQUEDA Y LLENAR FORMULARIO
            // ================================================================================

            const esPersonaNatural = valorNombreBusqueda.includes('|')

            if (esPersonaNatural) {
                console.log('-> Detectado: PERSONA NATURAL')

                // Desactivar inactivos primero solo en Predial
                if (areaRegistralSeleccionada === 'predial') {
                    await desactivarCheckboxInactivosPredial(page, esPersonaNatural);
                }

                // Dividir el nombre
                const partes = valorNombreBusqueda.split('|')
                const apePat = partes[0].trim()
                const apeMat = partes[1].trim()
                const nombres = partes[2].trim()

                console.log(`Ape Paterno: ${apePat}, Ape Materno: ${apeMat}, Nombres: ${nombres}`)

                // Seleccionar selectores según área registral elegida
                const selectorApePat = 'input[name="apellidoPaterno"]'
                const selectorApeMat = 'input[name="apellidoMaterno"]'
                const selectorNombres = 'input[name="nombres"]'

                // Llenar campos de persona natural
                console.log(`← Iniciando digitación en campo: apellidoPaterno`)
                const campoApePat = await page.waitForSelector(selectorApePat, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoApePat.click()
                await campoApePat.type(apePat)
                console.log(`    Digitación completada: "${apePat}"`)

                console.log(`← Iniciando digitación en campo: apellidoMaterno`)
                const campoApeMat = await page.waitForSelector(selectorApeMat, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoApeMat.click()
                await campoApeMat.type(apeMat)
                console.log(`    Digitación completada: "${apeMat}"`)

                console.log(`← Iniciando digitación en campo: nombres`)
                const campoNombres = await page.waitForSelector(selectorNombres, { waitUntil: 'networkidle0', timeout: 300000 })
                await campoNombres.click()
                await campoNombres.type(nombres)
                console.log(`    Digitación completada: "${nombres}"`)

                // Presionar TAB + ENTER para buscar
                console.log('Presionando TAB + ENTER para Buscar (Persona Natural)...')
                await page.keyboard.press('Tab')
                await page.keyboard.press('Enter')

            } else {
                console.log('-> Detectado: PERSONA JURÍDICA / RAZÓN SOCIAL')

                const razonSocial = valorNombreBusqueda

                console.log(`Razón Social: ${razonSocial}`)

                // Seleccionar el input de razón social según el área registral elegida
                const selectorRazonSocial = 'input[name="razonSocial"]'

                // Llenar campo de razón social
                if (areaRegistralSeleccionada === 'juridica') {
                    // Para jurídicas: usar el SEGUNDO input[name="razonSocial"]
                    const camposRazonSocial = await page.$$(selectorRazonSocial)
                    console.log(`← Iniciando digitación en campo: razonSocial (segundo input)`)
                    if (camposRazonSocial.length > 1) {
                        await camposRazonSocial[1].click()
                        await camposRazonSocial[1].type(razonSocial)
                        console.log(`    Digitación completada en el segundo input`)
                    } else {
                        console.error('No se encontró el segundo campo de razón social')
                    }

                    // Presionar TAB + TAB + ENTER para buscar
                    console.log('Presionando TAB + TAB + ENTER para Buscar (Persona Jurídica)...')
                    await page.keyboard.press('Tab')
                    await page.keyboard.press('Tab')
                    await page.keyboard.press('Enter')
                } else {
                    // Para predial y vehicular: usar el primer input[name="razonSocial"]
                    console.log(`← Iniciando digitación en campo: razonSocial`)
                    const campoRazonSocial = await page.waitForSelector(selectorRazonSocial, { waitUntil: 'networkidle0', timeout: 300000 })
                    await campoRazonSocial.click()
                    await campoRazonSocial.type(razonSocial)
                    console.log(`    Digitación completada`)

                    if (areaRegistralSeleccionada === 'predial') {
                        await desactivarCheckboxInactivosPredial(page, esPersonaNatural);
                        console.log(`Presionando TAB + ENTER para Buscar (${areaConfig.label} Predial)...`)
                        await page.keyboard.press('Tab')
                        await page.keyboard.press('Enter')
                    } else {
                        // Para vehicular u otras áreas: usar TAB + TAB + ENTER
                        console.log(`Presionando TAB + TAB + ENTER para Buscar (${areaConfig.label})...`)
                        await page.keyboard.press('Tab')
                        await page.keyboard.press('Tab')
                        await page.keyboard.press('Enter')
                    }
                }

            }

            console.log('Búsqueda completada, esperando resultados...')

            // ================================================================================
            // FASE 6: ESPERAR RESULTADOS Y EXTRAER DATOS
            // ================================================================================

            await new Promise(resolve => setTimeout(resolve, 3000))
            await guardarCapturaPdf(page, rutaCaps, valorRUC)

            // Extraer el número de coincidencias usando XPath específico
            let numCoincidencias = 0;
            try {
                const textoCoincidencias = await page.$eval(
                    '::-p-xpath(//span[contains(text(), "Total de registros encontrados")])',
                    elem => elem.textContent || ''
                );
                const numeros = textoCoincidencias.match(/\d+/);
                numCoincidencias = numeros ? parseInt(numeros[0]) : 0;
            } catch (error) {
                console.log(`XPath específico no encontrado, intentando selector genérico...`);
                numCoincidencias = await extraerNombreElemento(page, 'nz-list-item span.ant-typography');
            }
            console.log(`Coincidencias encontradas: ${numCoincidencias}`);

            let nroPartida = '';
            let zonaR = '';
            let estadoFila = '';
            let saltoPorDescarga = false;

            if (numCoincidencias === 0) {
                nroPartida = 'SIN PARTIDA';
                zonaR = '';
                estadoFila = 'no encontrado';
            } else {
                const datosTabla = await extraerDatosTabla(page);
                if (datosTabla.length > 0) {
                    zonaR = datosTabla[0][1] || '';
                    nroPartida = datosTabla[0][2] || '';
                    datosTabla.forEach(fila => datosCoincidencias.push(fila));
                }
                if (numCoincidencias > 1) {
                    nroPartida = String(numCoincidencias);
                    zonaR = '';
                    estadoFila = '2+ coincidencias';
                } else if (numCoincidencias === 1) {
                    estadoFila = await descargarPorAreaDesdeBusqueda(page, areaRegistralSeleccionada, zonaR, nroPartida);
                    saltoPorDescarga = true;
                }
            }

            // Agregar fila a la hoja Base
            datosBase.push({
                ruc: valorRUC,
                nombre: valorNombre,
                nombreBusqueda: valorNombreBusqueda,
                tipoSocial: valorTipoSocial,
                partida: nroPartida,
                zona: zonaR,
                estado: estadoFila
            });

            // ================================================================================
            // FASE 7: REGRESAR AL FORMULARIO
            // ================================================================================

            if (saltoPorDescarga) {
                await seleccionarMenuLateral(page, 'Búsqueda');
                await new Promise(resolve => setTimeout(resolve, 2000));
            } else {
                console.log('Presionando botón Regresar...')

                try {
                    // Buscar el botón por el texto "Regresar" usando XPath
                    const btnRegresar = await page.$('::-p-xpath(//button[contains(span, "Regresar")] | //button[contains(., "Regresar")])');
                    
                    if (btnRegresar) {
                        await btnRegresar.click();
                        console.log('Botón Regresar presionado');
                    } else {
                        // Alternativa: buscar por icono y clase
                        await page.evaluate(() => {
                            const buttons = document.querySelectorAll('button.ant-btn.ant-btn-primary');
                            for (let btn of buttons) {
                                if (btn.textContent.includes('Regresar')) {
                                    btn.click();
                                    break;
                                }
                            }
                        });
                        console.log('Botón Regresar presionado (alternativa)');
                    }

                    await new Promise(resolve => setTimeout(resolve, 2000));
                } catch (error) {
                    console.log(`Error al presionar Regresar: ${error.message}`);
                }
            }

            if (indice == NumeroTotalFilas) {
                console.log('---> El Proceso a Finalizado Con Éxito <---')
                
                // Guardar el Excel con los resultados
                await crearExcelResultados(rutaCarpetaResultados, datosBase, datosCoincidencias)
                
                await browser.close()
            }
        }

    } catch (error) {
        console.error('Error al iniciar el navegador o realizar búsquedas:', error);
        // Cierra el navegador si hay un error
        if (browser) {
            await browser.close();
        }
        // Reintenta después de 15 segundos
        setTimeout(BusquedaGeneral, 15000);
    }

}

async function FilasTotalesExcel(ArchivoExcel) {

    const workbook = new Exceljs.Workbook();

    try {
        await workbook.xlsx.readFile(ArchivoExcel)
    } catch (error) {
        console.error(`Error leyendo archivo Excel: ${ArchivoExcel}`, error.message);
        throw error;
    }

    let obtenerNumeroFilas = 0;

    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
        console.error('No se pudo obtener la hoja de trabajo del archivo Excel');
        throw new Error('Worksheet undefined');
    }

    worksheet.eachRow((row) => {

        if (row.hasValues) {
            obtenerNumeroFilas++;
        }
    })

    return obtenerNumeroFilas
}

async function CapturarValorExcel(ArchivoExcel, indiceFila, LetraVertical) {

    const workbook = new Exceljs.Workbook();

    try {
        await workbook.xlsx.readFile(ArchivoExcel)
    } catch (error) {
        console.error(`Error leyendo archivo Excel: ${ArchivoExcel}`, error.message);
        throw error;
    }

    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
        console.error('No se pudo obtener la hoja de trabajo del archivo Excel');
        throw new Error('Worksheet undefined');
    }

    return worksheet.getCell(`${LetraVertical}${indiceFila}`).value

}

async function getChromeExecutablePath() {
    const pathA = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
    const pathB = 'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe';

    try {
        const pathAExists = await fs.access(pathA).then(() => true).catch(() => false);
        return pathAExists ? pathA : pathB;
    } catch (error) {
        console.error('Error al encontrar la ruta:', error);
        return null;
    }
}

async function loadUserAccountFile(archivoUsuario) {
    try {
        const textoUserAccount = await fs.readFile(archivoUsuario, 'utf-8');
        return textoUserAccount;
    } catch (error) {
        console.error('Error al leer el archivo:', error);
        return null;
    }
}

async function main() {
    await mostrarMenuPrincipal()
}

main()
